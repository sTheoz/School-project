<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{ URL::asset('css/Header.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Footer.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Container.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/ParaData.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Forms.css') }}">
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
        @include('base/header')
        @php
            $group_data = App\Models\Group::getGroupByID($groupID);
        @endphp
        <form class="was-validated" action="/groups/changeGroup" method="POST" enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="hidden" name="group_id" value="{{$group_data[0]->id}}">
            <div class="container pt-5 mt-3">
                <section class="text-center">
                    <div class="card flex-md-row mb-4 box-shadow h-md-250">
                        <div class="card-body d-flex flex-column align-items-start">
                            <label for="group_name">Nom :</label>
                            <input class="form-control" type="text" name="group_name" value="{{$group_data[0]->name}}">
                            <div class="mb-1 text-muted">{{App\Models\Group_member::countUsersOfGroup($group_data[0]->id)}} Membres</div>
                            <br>
                            <p class="card-text mb-auto text-left">
                                Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un impr
                            </p>
                            <br>
                            Groupe géré par :
                            <select class="form-control" name="responsible">
                                <option value="{{$group_data[0]->responsible}}" default>{{App\Models\Users::getSomethingOfUser("name",$group_data[0]->responsible)[0]->name}}</option>
                                @foreach(DB::table('group_member')->where('id_group', $group_data[0]->id)->where('id_user','!=',$group_data[0]->responsible)->get() as $all_users)
                                    <option value="{{$all_users->id_user}}">{{ DB::table('users')->select('name')->where('id', $all_users->id_user)->get()[0]->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <img class="card-img-right flex-auto d-none d-md-block" src="https://vignette.wikia.nocookie.net/logopedia/images/a/a3/Unknown-1500557211.png/revision/latest/scale-to-width-down/480?cb=20170720132651" alt="Image du groupe ou cercle" style="width: 250px; height: 250px;">
                    </div>
                </section>
                @if(session('success') != NULL)
                    <div id="success_message"><br>{{ session('success') }}<br></div>
                @elseif(session('error') != NULL)
                    <div id="error_message"><br>{{ session('error') }}<br></div>
                @endif
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h3 class="text-center">Membres à rajouter :</h3>
                            <hr>
                            <table class="w-100 text-center">
                                <tr>
                                    <th>Ajouter</th>
                                    <th>Utilisateur</th>
                                </tr>
                                @php $count=0 @endphp
                                @foreach(DB::table('users')->select('name','id')->whereIn('id',App\Models\Group_member::getNonUsersOfGroup($group_data[0]->id))->orderBy('name','asc')->get() as $all_users)
                                    <tr>
                                        <td>
                                            <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-addMembers" name="users_to_add[]" value="{{$all_users->id}}">
                                                <label class="custom-control-label" for="checkbox{{$count}}-addMembers"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <label for="checkbox{{$count}}-addMembers">{{$all_users->name}}</label>
                                        </td>
                                    </tr>
                                    @php $count++ @endphp
                                @endforeach
                            </table>
                        </div>
                        <div class="col-md-4">
                            <h3 class="text-center">Membres à supprimer :</h3>
                            <hr>
                            <table class="w-100 text-center">
                                <tr>
                                    <th>Supprimer</th>
                                    <th>Utilisateur</th>
                                </tr>
                                @php $count=0 @endphp
                                @foreach(DB::table('group_member')->where('id_group', $group_data[0]->id)->where('id_user','!=',Auth::user()->id)->get() as $all_users)
                                    <tr>
                                        <td>
                                            <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-deleteMembers" name="users_to_delete[]" value="{{$all_users->id_user}}">
                                                <label class="custom-control-label" for="checkbox{{$count}}-deleteMembers"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <label for="checkbox{{$count}}-deleteMembers">{{ DB::table('users')->select('name')->where('id', $all_users->id_user)->get()[0]->name }}</label>
                                        </td>
                                    </tr>
                                    @php $count++ @endphp
                                @endforeach
                            </table>
                        </div>
                        <div class="col-md-4">
                            <h3 class="text-center">Description :</h3>
                            <hr>
                            <textarea class="form-control w-100" name="description" minlength="2" maxlength="200" style="height:300px;" required>{{ $group_data[0]->description }}</textarea>
                        </div>
                    </div>
                </div>
            </div>
            @if(!$group_data[0]->is_group)
                <input class="btn btn-primary mx-auto m-2 d-block w-50" type="submit" value="Modifier le cercle">
            @else
                <input class="btn btn-primary mx-auto m-2 d-block w-50" type="submit" value="Modifier le groupe">
            @endif
        </form>
    </body>
</html>