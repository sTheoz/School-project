<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <a class="navbar-brand" href="/">IUT<span>Drive</span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample03">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="/">Accueil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/user/profile">Mon Profil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://trello.com/b/jrMI35P2/drive" target="_blank">Trello</a>
        </li>
        @if(Auth::check())
            <li class="nav-item">
                <a class="nav-link text-danger font-weight-bold" href="/auth/disconnection">Deconnexion</a>
            </li>
        @else
            <li class="nav-item">
                <a class="nav-link text-primary font-weight-bold" href="login">Connexion</a>
            </li>
        @endif
        {{--
        @if(Auth::check())
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mon profil</a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
                <a type="button" class="dropdown-item">
                    Mes groupes <span class="badge badge-light">{{App\Models\Group_member::countGroupOfUserByID(Auth::user()->id)}}</span>
                </a>
                <a type="button" class="dropdown-item">
                    Mes cercles <span class="badge badge-light">4</span>
                </a>
            </div>
            </li>
        @endif
        --}}
      </ul>
        <form class="form-inline my-2 my-md-0" action="searchFile" method="post">
        {{csrf_field()}}
        <input type="hidden" name="_token" value="gFHkoesSvjTZRcJobuqQLDf7YUde9K3pxgkPPzXy">
        <div class="input-group">
            <div class="input-group-prepend">
                <select class="rounded-left" data-trigger="Acheter" name="fileType">
                    <option value="default" disabled selected hidden>Catégories</option>
                    <option href="index.php/Sales&amp;type=Fichiers" class="parent_category">Fichiers</option>
                    <option href="index.php/Sales&amp;type=Dossiers" class="child_category">Dossiers</option>
                </select>
            </div>
            <input type="search" class="form-control" name="fileName" placeholder="Je cherche..." aria-label="Search" minlength="5" maxlength="200" required="">
            <div class="input-group-append">
                <button class="input-group-text"><i class="fas fa-search"></i></button>
            </div>
        </div>
    </form>
    </div>
  </nav>
{{-----------------------------------------
<header class="header-search mt-5 pt-5">
    <div class="header-limiter">
        <h1><a href="/">IUT<span>Drive</span></a></h1>
        <nav>
            <a href="/">Accueil</a>
            <a href="https://trello.com/b/jrMI35P2/drive" target="_blank">Trello</a>
        </nav>
        <div class="twice-phone">
            <form action="searchFile" method="post">
                {{ csrf_field() }}
                <div class="inner-form">
                    <div class="input-field first-wrap">
                        <div class="input-select">
                        <select data-trigger="Acheter" name="fileType">
                            <option value="Dossiers" selected>Dossiers</option>
                            <option value="Fichiers">Fichiers</option>
                        </select>
                    </div>
                </div>
                <div class="input-field second-wrap">
                    <input id="search" name="fileName" type="text" placeholder="Je cherche..." required/>
                </div>
                <div class="input-field third-wrap">
                <a>
                        <button class="btn-search" type="submit">
                        <svg class="svg-inline--fa fa-search fa-w-16" aria-hidden="true" data-prefix="fas" data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                        </svg>
                        </button>
                    </a>
                </div>
            </form>
            </div>
        </div>
            @if($user = Auth::user())
                <div class="header-user-menu">
                    <img src="{{ $user->image }}" alt="{{ $user->name }}"/>
                    <ul>
                        <li><a href="/user/profile">Profil</a></li>
                        <li><a href="/user/groups">Mes groupes</a></li>
                        <li><a href="/user/circles">Mes cercles</a></li>
                        <li><a href="/auth/disconnection" class="highlight">Deconnexion</a></li>
                    </ul>
                </div>
            @else
                <ul>
                    <li><a href="login">Connexion</a></li>
                    <li><a href="register">Inscription</a></li>
                </ul> 
            @endif
    </div>
</header>
-----------------------------------------}}