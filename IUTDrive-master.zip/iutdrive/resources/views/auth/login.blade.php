<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IUTDrive - Connexion</title>
        <link rel="shortcut icon" href="{{{ asset('favicon.ico') }}}">
        @include('base/includeBootstrap')
    </head>
    <body class="text-center" style="background-image: url(https://img.freepik.com/free-photo/abstract-polygonal-space-low-poly-dark-background-3d-rendering_7247-223.jpg?size=626&amp;ext=jpg);background-size: cover;">
        <div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
            <main role="main" class="inner cover">
                <div class="container pt-5 mt-5">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                                <form class="was-validated form-signin text-center" action="{{ route('login') }}" method="POST">
                                    @csrf
                                    <div class="w-75 mx-auto p-2 bg-light rounded">
                                        <img class="mb-4" src="https://lucas-naveteur.fr/Artemis/public/Logo.png" alt="" width="150" height="150">
                                        <h1 class="h3 mb-3 font-weight-normal">Veuillez vous connecter à IUTDrive</h1>
                                        {{----}}
                                        <div class="col">
                                            <label class="d-block text-center" for="validationServer01">Adresse mail</label>
                                            <input id="email" type="email" class="form-control w-50 mx-auto form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" min="10" max="200" required autofocus>
                                            @if ($errors->has('email'))
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $errors->first('email') }}</strong>
                                                </span>
                                            @else
                                                <div class="invalid-feedback text-center">
                                                    L'adresse mail doit contenir entre 10 et 200 caractères
                                                </div>
                                                <div class="valid-feedback text-center">
                                                    L'adresse mail semble être conforme
                                                </div>
                                            @endif
                                        </div>
                                        <div class="col">
                                            <label class="d-block text-center" for="validationServer01">Mot de passe</label>
                                            <input id="password" type="password" class="form-control w-50 mx-auto form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" min="10" max="75" required>
                                            @if ($errors->has('password'))
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $errors->first('password') }}</strong>
                                                </span>
                                            @else
                                                <div class="invalid-feedback text-center">
                                                    Le mot de passe doit contenir entre 10 et 75 caractères
                                                </div>
                                                <div class="valid-feedback text-center">
                                                    Le mot de passe semble conforme
                                                </div>
                                            @endif
                                        </div>
                                        {{----}}
                                        <div class="custom-control custom-radio mr-sm-2 ml-3 mb-3 mt-3">
                                            <input class="custom-control-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                            <label class="custom-control-label text-primary" for="remember">Se souvenir de moi</label>
                                        </div>
                                        <button class="btn btn-lg btn-primary btn-block w-50 mx-auto" type="submit">Se connecter</button>

                                        @if (Route::has('password.request'))
                                            <a class="btn btn-link" href="{{ route('password.request') }}">
                                                {{ __('Vous avez oublier votre mot de passe ?') }}
                                            </a>
                                        @endif
                                        {{--<p class="mt-5 mb-3 text-muted">© 2017-2018</p>--}}
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </body>

</html>
