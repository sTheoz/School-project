<?
if(!empty($_GET["id"])){
    $name = DB::table('register')->select('path','name')->where('id',$_GET["id"])->get();
    if($name!=0){
        header("Content-type: application/force-download");
        header("Content-Length: ".filesize($name[0]->path.$name[0]->name);
        header("Content-Disposition: attachment; filename=".basename($name[0]->path.$name[0]->name));
        readfile($row->path);
    }
}
?>