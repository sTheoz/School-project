<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">-->
        <link rel="stylesheet" href="{{ URL::asset('css/Header.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Footer.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Container.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Explorator.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/w3.css') }}">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
        <title>IUTDrive</title>
        <script>
        function clickModal(){
            document.getElementById('addFichier').style.display='block';
        }
        function clickNoModal(){
            document.getElementById('addFichier').style.display='none';
        }
        </script>

    </head>
    <body>
        @include('base/header')
        <div class="Container">
            <div class="Explorator">
                <h3>Explorateur</h3>
                <div class="E_Folder">
                        @php
                            $count_files = 0; //Variable pour faire marcher la suppresion de fichier et de repertoires
                            if(isset($_GET['directory'])){
                                $baseurl="/srv/http/Drive/storage/app/public/";
                            }else{
                                $baseurl="/srv/http/Drive/storage/app/public";
                            }
                            if(!isset($_GET['directory'])){
                                $path=$baseurl;
                            }else{
                                $path=$baseurl.$_GET['directory'];
                            }
                            $current_link = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
                            try{
                                $arrayR=array();
                                $arrayF=array();
                                //Pour chaque fichiers ou dossiers détectés dans le repertoire de path
                                foreach (new DirectoryIterator($path) as $fileInfo) {
                                    //Si le fichier est ./ ou ../ ou qu'il commence par un '.' (Fichier caché) on ne l'affiche pas
                                    if($fileInfo->isDot() || (substr($fileInfo->getFilename(),0,1) == '.')) continue;
                                    if(is_dir($path."/".$fileInfo->getFilename())){
                                        //Si c'est un repertoire, on l'affiche en tant que repertoire
                                        //echo '<img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png">'.$fileInfo->getFilename().'<br>';
                                        $arrayR[]=$fileInfo->getFilename();
                                    }
                                }
                                sort($arrayR);
                                foreach ($arrayR as $nom) {
                                    echo '<img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png">'.$nom.'<br>';
                                }
                                
                                foreach (new DirectoryIterator($path) as $fileInfo) {
                                    //Si le fichier est ./ ou ../ ou qu'il commence par un '.' (Fichier caché) on ne l'affiche pas
                                    if($fileInfo->isDot() || (substr($fileInfo->getFilename(),0,1) == '.')) continue;
                                    if(is_dir($path."/".$fileInfo->getFilename())){
                                        }else{
                                        //Sinon c'est un fichier donc on l'affiche en tant que fichier en regardant son extension pour afficher une image correspondante en appelant un fonction de controlleur
                                        echo '<div class="E_File">';
                                        app('App\Http\Controllers\HomeController')->fileExtension($fileInfo->getExtension(),$fileInfo->getFilename());
                                        echo '<a href=/srv/http/Drive/storage/app/public/aaa>'.$fileInfo->getFilename().'</a></div>';
                                    }
                                }
                                /*sort($arrayF);
                                foreach ($arrayF as $nom) {
                                    echo '<div class="E_File">';
                                    app('App\Http\Controllers\HomeController')->fileExtension($fileInfo->getExtension(),$fileInfo->getFilename());
                                }
                                */
                            }catch (Exception $hi){
                                //Si il n'y a ni dossiers, ni répertoires
                                echo "<h3><i class='fas fa-exclamation-triangle'></i>Nothing to print<i class='fas fa-exclamation-triangle'></i></h3>".$hi;
                            }
                        @endphp
                    <!-- Changer l'image si fichier php,txt,java ou autre -->
                </div>
                <!-- SI CONNECTÉ -->
                @if($user = Auth::user())
                <div class="E_GroupList">
                    <!-- Je dois sélectionner tous les groupes auxquels appartiennent l'utilisateur en utilisant l'id du groupe et l'id de l'utilisateur-->
                    @php
                        $loop = App\Models\Group_member::getUserGroupMember(auth()->user()->id);
                        $count = 0;
                    @endphp
                    @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
                        @if($count == 0)
                        <h3>Vos groupes :</h3><br>
                        @endif
                        @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,"grp") as $group)
                            <a href="/groups/?group={{ $group->id }}" class="E_Group"><img src="{{ $group->image }}"> {{ $group->name }}</a>
                            <br>
                        @endforeach
                        @php
                            $count++;
                        @endphp
                        <!-- FAIRE LA MEME POUR LES CERCLES -->
                    @endforeach
                    @php $count=0; @endphp
                    @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
                        @if($count == 0)
                            <h3>Vos cercles :</h3><br>
                        @endif
                        @php $count++ @endphp
                        @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,"cer") as $circle)
                            <a href="/circles/?circle={{ $circle->id }}" class="E_Group"><img src="{{ $circle->image }}"> {{ $circle->name }}</a>
                            <br>
                        @endforeach
                    @endforeach
                </div>
                @endif
            </div>
            <!-- Division principale avec les fichiers -->
            <div class="Content">
                @if(session('success') != NULL)
                    <div id="success_message"><br>{{ session('success') }}<br></div>
                @elseif(session('error') != NULL)
                    <div id="error_message"><br>{{ session('error') }}<br></div>
                @endif
            <h3>Votre recherche pour les {{ $_POST['fileType'] }} contenant : "{{ $_POST['fileName'] }}"</h3>
            @if($user = Auth::user())
            <br>
                Connecté en tant que {{ $user->name }}<br>
            @endif
                <div id="addFichier"  class="w3-modal">
                    <div class="w3-modal-content" style="top:20%;opacity:0.94;">     
                        <div class="w3-container">
                            <span onclick="clickNoModal()" class="w3-button w3-display-topright">&times;</span>
                            <form action="addFile" method="POST" enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <p>Veuillez choisir le fichier à ajouter (Max 19Mo)</p>
                                <input type="file" name="file"/>
                                @if(!isset($_GET['directory']))
                                    <input type="hidden" name="path" value="/"/>
                                @else
                                    <input type="hidden" name="path" value=""/>
                                @endif
                                <br><br>
                                <input type="submit"/>
                            </form>
                            <br>
                    </div>
                </div>



                </div>
                <div class="Container_files">
                    <div class="files" style="display: inherit;flex-wrap: inherit;">
                        
                            @php
                            try{
                                $cpt=0;
                                foreach ($filesFromSearchBar as $fileInfo) {
                                    $filename = substr($fileInfo, strrpos($fileInfo, 'searchBarWelcome?directory=') + strlen('searchBarWelcome?directory='));
                                    $filepath = "http://" . $_SERVER['SERVER_NAME']."/storage/".$filename.'/';
                                            //Si c'est un répertoire
                                            if (\strpos($filename, '/') !== false) {
                                                echo "</div>";
                                                echo "<u>Répertoire : ".substr($filename, 0, strrpos( $filename, '/') )."</u>";
                                                echo "<div class='strange'>";
                                                echo '<div class="information">';
                                                echo '<a class="image" title="'.$filename.'" href="'.$filepath.'">';
                                                    app('App\Http\Controllers\HomeController')->fileExtension(substr($filename, strrpos($filename, '.') + 1),$filename);
                                                echo '</a>';
                                                //echo '<a class="nom" title="'.$filename.'" href="'.$filepath.'"><br>'.$substr($filename, strrpos($filename, '/') + 1).'</a>';
                                                echo "<br><a class='nom' title='".$filename."' href='".$filepath."'>".substr($filename, strrpos($filename, '/') + 1)."</a>";
                                                echo "</div>";
                                            //Si c'est un fichier
                                            }else{
                                                if($cpt==0){
                                                    echo "<u>Racine du serveur :</u><br>";
                                                    echo "<div class='strange'>";
                                                }
                                                echo '<div class="information">';
                                                //If user has write access
                                                if(Auth::check()){
                                                    $count_files++;
                                                    echo '<form action="deleteFolder" id="deleteFileForm'.$count_files.'" method="POST">';
                                                        echo csrf_field();
                                                        echo '<input type="hidden" name="filename" value="'.$filepath.'">';
                                                            echo '<button class="button_delete" type="submit" form="deleteFileForm'.$count_files.'" value="Submit">';
                                                        echo '</button>';
                                                    echo '</form>';
                                                }
                                                    echo '<a class="image" title="'.$filename.'" href="'.$filepath.'">';
                                                        app('App\Http\Controllers\HomeController')->fileExtension(substr($filename, strrpos($filename, '.') + 1),$filename);
                                                    echo "</a>";
                                                    echo '<a class="nom" title="'.$filename.'" href="'.$filepath.'"><br>'.$filename.'</a>';
                                                echo '</div>';
                                            }
                                        $cpt++;
                                }
                                echo "</div>";
                                echo "</div>";
                                echo "</div>";
                            }catch (Exception $hi){
                                        echo '</div>';
                                echo "<h1><i class='fas fa-exclamation-triangle'></i>Nothing to print<i class='fas fa-exclamation-triangle'></i></h1>";
                            }
                            @endphp
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('footer')</body>
</html>
