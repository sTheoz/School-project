<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
        @include('base/header')
    {{----}}    
    @php
        echo storage_path(('10M'));
        echo "<br>";
        echo '/storage/10M';
    @endphp
    {{----}}
        <div class="container-fluid">
            <div class="row">
                <!-- Cette partie correspond à l'explorateur qui se trouve sur la gauche de la page -->
                <div class="col-md-2 d-none d-md-block bg-light sidebar">
                    <h3 class="text-center">Explorateur</h3>
                    <div class="p-2">
                        <table>
                            <tbody>
                            @php
                                $count_files = 0; //Variable pour faire marcher la suppresion de fichier et de repertoires
                                if(isset($_GET['directory'])){
                                    $baseurl="/srv/http/Drive/storage/app/public/";
                                    $directory = $_GET['directory'];
                                }else{
                                    $baseurl="/srv/http/Drive/storage/app/public";
                                    $directory = "/";
                                }if(!isset($_GET['directory'])){
                                    $path=$baseurl;
                                }else{
                                    $path=$baseurl.$_GET['directory'];
                                }
                                $current_link = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
                                try{
                                    //Création des tableaux afin de les triers alphabétiquement plus tard
                                    $arrayR=array();
                                    $arrayF=array();
                                    //Pour chaque fichiers ou dossiers détectés dans le repertoire de path
                                    foreach (new DirectoryIterator($path) as $fileInfo){
                                        //Si le fichier est ./ ou ../ ou qu'il commence par un '.' (Fichier caché) on ne l'affiche pas
                                        if($fileInfo->isDot() || (substr($fileInfo->getFilename(),0,1) == '.')) continue;
                                        if(is_dir($path."/".$fileInfo->getFilename())){
                                            //Si c'est un repertoire, on l'affiche en tant que repertoire
                                            $arrayR[]=$fileInfo->getFilename();
                                        }
                                    }
                                    //Trie et met le nom des répertoires dans l'explorateur
                                    sort($arrayR);
                                    foreach ($arrayR as $nom){
                                        echo "<tr>";
                                            echo "<th scope='row'>";
                                                echo '<img height="25" width="25" src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png">';
                                            echo "</th>";       
                                            echo '<td>&nbsp;'.$nom.'</td>';
                                        echo "</tr>";
                                    }
                                    // On stock tous les noms de fichiers dans un tableau                        
                                    foreach (new DirectoryIterator($path) as $fileInfo) {
                                        //Si le fichier est ./ ou ../ ou qu'il commence par un '.' (Fichier caché) on ne l'affiche pas
                                        if($fileInfo->isDot() || (substr($fileInfo->getFilename(),0,1) == '.')) continue;
                                        if(is_dir($path."/".$fileInfo->getFilename())){

                                        }else{
                                            $arrayF[]=$fileInfo->getFilename();
                                            //Sinon c'est un fichier donc on l'affiche en tant que fichier en regardant son extension pour afficher une image correspondante en appelant un fonction de controlleur
                                        }
                                    }
                                    // On trie dans l'ordre alphabétique et on affiche les fichiers en forme d'image et de lien                  
                                    sort($arrayF);
                                    foreach ($arrayF as $nom) {
                                        echo "<tr>";
                                            echo "<th scope='row'>";
                                                app('App\Http\Controllers\HomeController')->fileExtensionForExplorator( substr(strrchr($nom, "."),1),$nom);
                                            echo "</th>";       
                                            echo '<td><a href="'.$current_link.$nom.'">&nbsp;'.$nom.'</a></td>';
                                        echo "</tr>";
                                    }
                                }catch (Exception $hi){
                                    //Si il n'y a ni dossiers, ni répertoires
                                    echo "<h3><i class='fas fa-exclamation-triangle'></i>Rien à afficher<i class='fas fa-exclamation-triangle'></i></h3>".$hi;
                                }
                            @endphp
                            <!-- Changer l'image si fichier php,txt,java ou autre -->
                            </tbody>
                        </table>
                    </div>
                    <!-- SI CONNECTÉ -->
                    <!-- Si un utilisateur est connecté alors on regarde s'il fait parti de groupe et de cercle puis on les affiche -->
                    @if($user = Auth::user())
                    <div class="">
                        <!-- Je dois sélectionner tous les groupes auxquels appartiennent l'utilisateur en utilisant l'id du groupe et l'id de l'utilisateur-->
                        @php
                            $count = 0;
                        @endphp
                        @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
                            @if($count == 0)
                                <h3 class="text-center">Vos groupes :</h3><br>
                            @endif
                            <table>
                                <tbody>
                                    <tr>
                                        @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,"grp") as $group)
                                            <th scope="row">
                                                <img class="rounded-circle" height="25" width="25" src="{{ $group->image }}">
                                            </th>
                                            <td><a href="/groups/?group={{ $group->id }}">&nbsp;{{ $group->name }}</a></td>
                                        @endforeach
                                    </tr>
                                </tbody>
                            </table>
                            @php
                                $count++;
                            @endphp
                            <!-- FAIRE LA MEME POUR LES CERCLES -->
                        @endforeach
                        @php $count=0; @endphp
                        @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
                            @if($count == 0)
                                <h3 class="text-center">Vos cercles :</h3><br>
                            @endif
                            @php $count++ @endphp
                            <table>
                                <tbody>
                                    <tr>
                                        @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,"cer") as $circle)
                                            <th scope="row">
                                                <img class="rounded-circle" height="25" width="25" src="{{ $circle->image }}">
                                            </th>
                                            <td><a href="/groups/?group={{ $group->id }}">&nbsp;{{ $circle->name }}</a></td>
                                        @endforeach
                                    </tr>
                                </tbody>
                            </table>
                        @endforeach
                    </div>
                    @endif
                </div>
                <!-- Division principale, au centre de la page, avec les fichiers et dossiers -->
                <div class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
                    @include('base/message')
                    @if($path == "/srv/http/Drive/storage/app/public")
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                Répertoire :&nbsp;<li class="breadcrumb-item active" aria-current="page"><a class="path-nav" href="{{URL::current()}}">Accueil</a></li>
                            </ol>
                        </nav>
                    @else
                        @php $tags = explode('/',$_GET['directory']); @endphp
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                @php $postkey = ""; @endphp Répertoire :&nbsp;
                                <li class="breadcrumb-item active" aria-current="page"><a class="path-nav" href="{{URL::current()}}">Accueil</a></li>
                                @foreach($tags as $key)
                                    @php $postkey = ltrim($postkey."/".$key, '/'); @endphp
                                        <li class="breadcrumb-item active" aria-current="page"><a class="path-nav" href="?directory={{$postkey}}">{{$key}}</a></li>
                                @endforeach
                            </ol>
                        </nav>
                    @endif
                    @if($user = Auth::user())
                        <div>
                            <p>Bonjour <a href="/user/profile"><strong><u>{{ $user->name }}</u></strong></a></p>
                            <button type="button" class="btn" data-toggle="modal" data-target="#addFichier">
                                    <img height="25" width="25" src="https://www.freeiconspng.com/uploads/add-1-icon--flatastic-1-iconset--custom-icon-design-0.png">
                            </button>
                            @include('modals/ajoutFichier')
                            <button type="button" class="btn" data-toggle="modal" data-target="#addDossier">
                                <img height="25" width="25" src="storage/.images/icones/addDossier.png">
                            </button>
                            @include('modals/ajoutDossier')
                        </div>
                    @endif
                    <!-- Division principale contenant les fichiers et dossiers -->
                    <div class="row">     
                        @if($path=="/srv/http/Drive/storage/app/public")
                        @else
                        <!-- Case du retour au dossier précédant -->
                            <div class="col-1 text-center text-truncate mb-3" id="dossier">
                                @if(is_dir($path."/".$fileInfo->getFilename()))
                                    <a href="{{substr($current_link, 0, strrpos( $current_link, '/'))}}">
                                        <img height="50" width="50" src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png"/>
                                    </a>
                                    <a class="d-block" href="{{substr($current_link, 0, strrpos( $current_link, '/'))}}">
                                        <i class="fas fa-backward"></i>
                                    </a>
                                @endif
                            </div>
                        @endif
                        @foreach ($arrayR as $name)
                            <div class="col-1 text-center text-truncate mb-3" id="dossier">
                                {{-- If user has write access --}}
                                @php $count_files++; @endphp
                                <form action="deleteFolder" id="deleteFileForm{{$count_files}}" method="POST">
                                    {{csrf_field()}}
                                    <input type="hidden" name="filename" value="{{$path}}/{{$name}}">
                                    <button class="position-absolute btn p-0" type="submit" form="deleteFileForm{{$count_files}}" value="Submit">
                                        <img height="20" width="20" src="http://mytourdumonde.net/wp-content/uploads/Croix-rouge-erreur.png">
                                    </button>
                                    @if(isset($_GET['directory']))
                                        <a href="{{$current_link}}/{{$name}}"><img height="50" width="50" src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png"/></a>
                                        <a class="nom" href="{{$current_link}}/{{$name}}"><br>{{$name}}</a>
                                        <input type="hidden" name="actual_directory" value="{{$_GET['directory']}}" >
                                    @else
                                    <a href="{{$current_link}}?directory={{$name}}"><img height="50" width="50" src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png"/></a>
                                    <a class="nom" href="{{$current_link}}?directory={{$name}}"><br>{{$name}}</a>
                                    @endif
                                </form>
                            </div>                            
                        @endforeach
                        @foreach ($arrayF as $nom)
                            <div class="col-1 text-center text-truncate mb-3" id="fichier">
                                @if(Auth::check())
                                    @php $count_files++; @endphp
                                    <form action="deleteFile" id="deleteFileForm{{$count_files}}" method="POST">
                                        {{csrf_field()}}
                                        @if(isset($_GET['directory']))
                                            <input type="hidden" name="filename" value="/srv/http/Drive/storage/app/public/{{$_GET['directory']}}/{{$nom}}">
                                        @else
                                            <input type="hidden" name="filename" value="/srv/http/Drive/storage/app/public/{{$nom}}">
                                        @endif
                                        @if(isset($_GET['directory']))
                                            <a download title="{{$nom}}" href="http://37.58.131.231/storage/{{$_GET['directory']}}/{{$nom}}">
                                        @else
                                            <a download title="{{$nom}}" href="http://37.58.131.231/storage/{{$nom}}">
                                        @endif
                                        <button class="position-absolute btn p-0" type="submit" form="deleteFileForm{{$count_files}}" value="Submit">
                                            <img height="20" width="20" src="http://mytourdumonde.net/wp-content/uploads/Croix-rouge-erreur.png">
                                        </button>
                                    </form>
                                @endif
                                @php app('App\Http\Controllers\HomeController')->fileExtension(substr(strrchr($nom, "."),1),$nom); @endphp
                                </a>
                                @if(isset($_GET['directory']))
                                    <a download title="{{$nom}}" href="http://37.58.131.231/storage/{{$_GET['directory']}}/{{$nom}}">
                                @else
                                    <a download title="{{$nom}}" href="http://37.58.131.231/storage/{{$nom}}">
                                @endif
                                {{$nom}}</a>
                            </div>
                        @endforeach
                    </div>
                    <!--  Fenêtre du bas avec les utilisateurs ayant accès au répertoire courant --> 
                    <div class="bg-light text-black rounded p-2">
                        Liste des utilisateurs ayant accès à ce répertoire :
                        {{App\Models\Rights::getAccessListForDirectory("public/")}}
                        <div class="">
                            @if(isset($_GET['directory']))
                                @for ($i=0; $i<substr_count('/'.$_GET['directory'], '/'); $i++)
                                    @php
                                        if($i==0){
                                            $parent = dirname('/'.$_GET['directory']);
                                        }else{
                                            $parent = dirname($parent);
                                        }
                                    @endphp
                                    @foreach (App\Models\Users::getAllUsers() as $user_access)
                                        @if(App\Models\Rights::hasRightUser($user_access->id, $parent) > 0)
                                            <a href='#'><img src='{{ App\Models\Users::getUserByID($user_access->id)[0]->image }}' title='{{ App\Models\Users::getUserByID($user_access->id)[0]->image }}'/></a>
                                        @endif
                                    @endforeach
                                @endfor
                                {{-- THE END IS NEAR --}}
                            @else
                                @php $i=0; @endphp
                                @foreach (App\Models\Rights::getPermissionRacine() as $user_access)
                                    <a href="#"><img src="{{ App\Models\Users::getAllUsers($user_access->id_user)[$i]->image }}" title="{{ App\Models\Users::getAllUsers($user_access->id_user)[$i]->name }}"/></a>  
                                    @php $i++; @endphp                            
                                @endforeach
                            @endif                           
                        </div>
                        @php
                            if(Auth::check()){
                                $tst = App\Models\Rights::hasRightUser(auth()->user()->id, "public/test.jpg");
                                if($tst == 1){
                                    echo "Lecture sur : "."public/test.jpg";
                                }else if($tst == 2){
                                    echo "Ecriture sur : "."public/test.jpg";
                                }else{
                                    echo "Rien usr : "."public/test.jpg";
                                }
                            }
                        @endphp
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>