@if(session('success') != NULL)
    <div class="alert alert-success" role="alert">
        {{ session('success') }}
    </div>
@elseif(session('error') != NULL)
    <div class="alert alert-danger" role="alert">
        {{ session('error') }}
    </div>
@endif