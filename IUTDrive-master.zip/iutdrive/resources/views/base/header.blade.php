<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top text-center">
    <a class="navbar-brand" href="/">IUT<span>Drive</span></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample03">
        <ul class="navbar-nav mr-auto">
                @if(url()->current() == URL::to('/'))
                    <li class="nav-item active">
                @else
                    <li class="nav-item">
                @endif
            <a class="nav-link" href="/">Accueil</a>
            </li>
            @if(Auth::check())
                @if(strpos(url()->current(),'profile'))
                    <li class="nav-item active">
                @else
                    <li class="nav-item">
                @endif
                    <a class="nav-link" href="/user/profile">Profil</a>
                </li>
                @if(strpos(url()->current(),'user/groups'))
                    <li class="nav-item active">
                @else
                    <li class="nav-item">
                @endif
                    <a class="nav-link" href="/user/groups">Groupes <span class="badge badge-secondary">{{App\Models\Group_member::countGroupOfUserByID(Auth::user()->id)}}</span></a>
                </li>
                @if(strpos(url()->current(),'user/circles'))
                    <li class="nav-item active">
                @else
                    <li class="nav-item">
                @endif
                    <a class="nav-link" href="/user/circles">Cercles <span class="badge badge-secondary">{{App\Models\Group_member::countCircleOfUserByID(Auth::user()->id)}}</span></a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="https://trello.com/b/jrMI35P2/drive" target="_blank">Trello</a>
                </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger font-weight-bold" href="/auth/disconnection">Deconnexion</a>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link text-primary font-weight-bold" href="login">Connexion</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-primary font-weight-bold" href="register">Inscription</a>
                    </li>
            @endif
        </ul>
        <form class="form-inline my-2 my-md-0" action="searchFile" method="post">
            {{ csrf_field() }}
            <div class="input-group">
                <div class="input-group-prepend">
                    <select class="rounded-left" data-trigger="Acheter" name="objectType">
                        <option value="0">Fichiers</option>
                        <option value="1">Dossiers</option>
                    </select>
                </div>
                <input type="search" class="form-control" name="objectName" placeholder="Je cherche..." aria-label="Search" maxlength="200" required="">
                <div class="input-group-append">
                    <button class="input-group-text"><i class="fas fa-search"></i></button>
                </div>
            </div>
        </form>
    </div>
  </nav>