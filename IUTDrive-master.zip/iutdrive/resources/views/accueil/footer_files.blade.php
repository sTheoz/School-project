<div class="navbar navbar-expand-lg navbar-dark bg-dark fixed-bottom text-center text-white">
    @php
    $groups_access = App\Models\Rights::getAccessListForDirectory($path);
    @endphp
    <div class="row">
    @foreach($groups_access as $access)
        <div class="col-auto text-center">
            <img class="rounded" height="30" width="30" src="{{DB::table('group')->select('image')->where('id', $access)->get()[0]->image}}" alt="Card image cap">
            <p class="card-text">{{DB::table('group')->select('name')->where('id', $access)->get()[0]->name}}</p>
        </div>
    @endforeach
    </div>
</div>