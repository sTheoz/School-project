{{--aaa--}}
@php 
    $folders = array();
    $files = array();
@endphp
@foreach (new DirectoryIterator($path) as $fileInfo)
    @if (substr($fileInfo->getFileName(), 0, 1) === '.')
        {{-- DOSSIER POINT --}}
    @else
        @php 
        if($fileInfo->isDir()){
            $folders += array(
                $fileInfo->getPathname() => array(
                "path"  => $fileInfo->getPath(),
                "pathname" => $fileInfo->getPathname(),
                "name" => $fileInfo->getFileName(),
                "extension" => $fileInfo->getExtension(),
                "taille" => $fileInfo->getSize(),
                "isDir" => $fileInfo->isDir(),
                "isFile" => $fileInfo->isFile()
            ));
        }else{
            $files += array(
                $fileInfo->getPathname() => array(
                "path"  => $fileInfo->getPath(),
                "pathname" => $fileInfo->getPathname(),
                "name" => $fileInfo->getFileName(),
                "extension" => $fileInfo->getExtension(),
                "taille" => $fileInfo->getSize(),
                "isDir" => $fileInfo->isDir(),
                "isFile" => $fileInfo->isFile()
            ));
        }
        @endphp
    @endif
    {{--INSERER--}}
@endforeach
@php 
    /* TRI DU TABLEAU */
    uksort($folders, 'strcasecmp');
    uksort($files, 'strcasecmp');
    /* AFFICHAGE DES DONNÉES */
@endphp
@if(($path !== storage_path('app/public')) && ($path !== storage_path('app/public/')))
    <div class="col-auto text-center text-truncate mb-3" id="dossier">
        <form action="goBackward" method="POST">
            {{ csrf_field() }}
            <input type="hidden" name="folder_id" value="{{DB::table('register')->select('id')->where('path', $path)->get()[0]->id}}">
            <button class="btn p-0" href="">
                <img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png" width="50" height="50">
            </button>
            <br>
            <button class="btn p-0 mt-0" href="">
                <i class="fas fa-backward"></i>
            </button>
        </form>
    </div>
@endif
@foreach($folders as $folder)
    <div class="col-auto text-center text-truncate mb-3 position-relative">
        {{-- Si accès en écriture sur le dossier --}}
        @if((App\Models\Rights::hasRightUser(Auth::user()->id,$folder["pathname"]."/") == 2))
            <form action="deleteFolder" method="POST">
                {{ csrf_field() }}
                <input type="hidden" name="folder_id" value="{{DB::table('register')->select('id')->where('path',$folder["pathname"]."/")->get()[0]->id}}">
                <button class="position-absolute btn pr-0 pt-0" type="submit">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </form>
        @endif
        {{-- Si accès en lecture ou écriture au dossier --}}
        @if(App\Models\Rights::hasRightUser(Auth::user()->id,$folder["pathname"]."/") >= 1)
            <form action="downloadFolder" method="POST" class="position-absolute">
                {{ csrf_field() }}
                <input type="hidden" name="folder_id" value="{{DB::table('register')->select('id')->where('path',$folder['pathname']."/")->get()[0]->id}}">
                <button class="position-absolute btn pl-0 pt-0" type="submit">
                    <i class="fas fa-cloud-download-alt"></i>
                </button>
            </form>
            <form action="gotoFolder" method="POST">
                {{ csrf_field() }}
                <input type="hidden" name="folder_id" value="{{DB::table('register')->select('id')->where('path',$folder['pathname']."/")->get()[0]->id}}">
                <button class="btn p-0" href="">
                    <img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png" width="50" height="50">
                </button>
                <br>
                <button class="btn p-0 mt-0" href="">{{$folder['name']}}</button>
            </form>
        @endif
    </div>
@endforeach
@foreach($files as $file)
    <div class="col-auto text-center text-truncate mb-3">
        {{-- Si accès en écriture sur le fichier --}}
        @if(App\Models\Rights::hasRightUser(Auth::user()->id,$file["pathname"]) == 2)
            <form action="deleteFile" method="POST">
                {{ csrf_field() }}
                <input type="hidden" name="file_id" value="{{DB::table('register')->select('id')->where('path',$file["pathname"])->get()[0]->id}}">
                <button class="position-absolute btn pr-0 pt-0" type="submit">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </form>
        @endif
        {{-- Si accès en lecture ou écriture au fichier --}}
        @if(App\Models\Rights::hasRightUser(Auth::user()->id,$file["pathname"]) >= 1)
            <form action="downloadFile" method="POST">
                {{ csrf_field() }}
                <input type="hidden" name="file_id" value="{{DB::table('register')->select('id')->where('path',$file['pathname'])->get()[0]->id}}">
                <button class="btn p-0" type="submit">
                    {{\App\Http\Controllers\HomeController::fileExtension($file['pathname'],$file['name'],substr($file['name'], strrpos($file['name'], '.') + 1))}}
                </button>
                <br>
                <button class="btn p-0 mt-0" type="submit">{{$file['name']}}</button>
            </form>
        @endif
    </div>
@endforeach