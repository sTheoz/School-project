<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
        @include('base/header')
        {{----}}    
        @php
            if(!isset($path)){
                $path = storage_path('app/public/');
            }
        @endphp
        {{----}}
        <div class="pt-5 mt-2">
            <div class="w-100">
                <!-- Division principale, au centre de la page, avec les fichiers et dossiers -->
                <div class="pt-3 px-4">
                    @include('base/message')
                    <table class="table table-bordered table-hover">
                        <thead class="bg-dark text-white">
                            <tr>
                            <th scope="col">Nom</th>
                            <th scope="col">Propriétaire</th>
                            <th scope="col">Taille</th>
                            <th scope="col">Emplacement</th>
                            <th scope="col"><i class="fas fa-download text-white text-center d-block"></i></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($objects_access as $access)
                                @php $pathname = App\Models\Users::getSomethingOfUser("name",DB::table('register')->select('owner')->where('path',storage_path('app/public/').$access)->get()[0]->owner)[0]->name; @endphp
                                <tr>
                                    <th scope="row">
                                        {{$access}}
                                    </th>
                                    <th scope="row">
                                        {{$pathname}}
                                        
                                    </th>
                                    <td>
                                        {{filesize(storage_path('app/public/').$access)}} octets (xx %)
                                    </td>
                                    <td>
                                        {{substr($access, 0, strrpos( $access, '/'))}}/
                                    </td>
                                    <td>
                                        <form action="downloadFile" method="POST">
                                            {{ csrf_field() }}
                                            <input type="hidden" name="file_id" value="{{DB::table('register')->select('id')->where('path',"/srv/http/Drive/storage/app/public/".$access)->get()[0]->id}}">
                                            <button class="btn p-0" type="submit">
                                                <i class="fas fa-download text-dark text-center d-block"></i>
                                            </button>
                                        </form>
                                    </td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>