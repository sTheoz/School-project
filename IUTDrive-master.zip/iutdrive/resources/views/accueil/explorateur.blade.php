<h3 class="text-center">Explorateur</h3>
Insérer explorateur
<!-- SI CONNECTÉ -->
<!-- Si un utilisateur est connecté alors on regarde s'il fait parti de groupe et de cercle puis on les affiche -->
@if($user = Auth::user())
<div class="">
    <!-- Je dois sélectionner tous les groupes auxquels appartiennent l'utilisateur en utilisant l'id du groupe et l'id de l'utilisateur-->
    @php
    $count = 0;
    @endphp
    @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
        @if($count == 0)
        <h3 class="text-center">Vos groupes :</h3>
        @endif
        <table>
            <tbody>
                <tr>
                    @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,"grp") as $group)
                    <th scope="row">
                        <img class="rounded-circle" height="25" width="25" src="{{ $group->image }}">
                    </th>
                    <td><a href="/groups/?group={{ $group->id }}">&nbsp;{{ $group->name }}</a></td>
                    @endforeach
                </tr>
            </tbody>
        </table>
        @php $count++; @endphp
        <!-- FAIRE LA MEME POUR LES CERCLES -->
    @endforeach
    @php $count=0; @endphp
    @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
        @if($count == 0)
            <h3 class="text-center">Vos cercles :</h3>
            @endif
            @php $count++ @endphp
            <table>
                <tbody>
                    <tr>
                        @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,"cer") as $circle)
                        <th scope="row">
                            <img class="rounded-circle" height="25" width="25" src="{{ $circle->image }}">
                        </th>
                        <td><a href="/circles/?circle={{ $circle->id }}">&nbsp;{{ $circle->name }}</a></td>
                        @endforeach
                    </tr>
                </tbody>
            </table>
        @endforeach
    </div>
@endif