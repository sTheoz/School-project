<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="{{ URL::asset('js/Modal.js') }}"></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
        @include('base/header')
        <div class="container-fluid pt-5 mt-2">
      <div class="row">
        {{-- @include('user/sideBar') --}}
        
        <main role="main" class="col pt-3 px-4">
          <div class="d-flex border-bottom">
            <h1 class="h2 text-info">Cercles</h1>
                <!-- Button trigger modal -->
                <button type="button" class="btn" data-toggle="modal" data-target="#addCircleModal">
                        <img width="25" heigth="25" src="https://www.freeiconspng.com/uploads/add-1-icon--flatastic-1-iconset--custom-icon-design-0.png">
                </button>
                <!-- Modal -->
                @include('modals/create_circle')
            <div class="btn-toolbar mb-2 mb-md-0">
            </div>
          </div>
                @if(App\Models\Group_member::countGroupOfUserByID(auth()->user()->id) == 0)
                    <h1>Vous n'avez pas de cercles</h1>
                @endif
                @if(session('success') != NULL)
                    <div id="success_message"><br>{{ session('success') }}<br></div>
                @elseif(session('error') != NULL)
                    <div id="error_message"><br>{{ session('error') }}<br></div>
                @endif
                <h3>Vos cercles :</h3>
                <div class="row">
                    @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
                        @foreach(App\Models\Group::getGroupWithIDAndName($item->id_group,0) as $circle)
                            <div class="col-md-2 mb-4">
                                <div class="card w-100 mx-auto">
                                    <div class="position-relative">
                                        <a href="/circles?circle={{$circle->id}}"><img class="card-img-top" alt="image vente" src="{{$circle->image}}" height="auto"></a>
                                        <small class="text-left position-absolute fixed-bottom p-1 bd-highlight text-white" style="background-color: rgba(50, 50, 50, 0.25);">
                                            Cercle de {{App\Models\Users::getSomethingOfUser("name", $circle->responsible)[0]->name}}
                                        </small>
                                        <div class="card-title text-right position-absolute fixed-bottom m-0 text-white">
                                            {{App\Models\Group_member::countUsersOfGroup($circle->id)}} membres
                                        </div>
                                    </div>
                                    
                                    <div class="card-body pt-0 pb-0 text-center">
                                        <h6 class="card-title text-center m-0">
                                            <a class="btn-link" href="/circles?circle={{$circle->id}}"><u><strong>{{ $circle->name }}</strong></u></a>
                                        </h6>
                                        <small>{{$circle->description}}</small>
                                        <br>
                                    </div>
                                    @if($circle->responsible ==  auth()->user()->id)
                                        <div class="card-footer d-flex justify-content-around bd-highlight p-0">
                                            <div class="p-2 bd-highlight">
                                                <form class="btn btn-light border p-0" action="../groups/addMembersRedirect" method="POST">
                                                    {{ csrf_field() }}
                                                    <input type="hidden" name="group_id" value="{{ $circle->id }}">
                                                    <button type="submit" class="btn btn-sm text-muted" title="Configurer le cercle">
                                                        <i class="fas fa-users-cog"></i>
                                                    </button>
                                                </form>
                                                <form class="btn btn-light border p-0" action="../groups/deleteGroup" method="POST" enctype="multipart/form-data">
                                                    {{ csrf_field() }}
                                                    <input type="hidden" name="group_id" value="{{ $circle->id }}">
                                                    <input type="hidden" name="circle_image" value="{{ $circle->image }}">
                                                    <button type="submit" class="btn btn-sm text-danger" title="Supprimer le cercle">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    @else
                                        <form class="btn btn-light border p-0"  action="../groups/suppMemberGroup" method="POST">
                                            {{ csrf_field() }}
                                            <input type="hidden" name="id_user" value="{{ Auth::user()->id }}">
                                            <input type="hidden" name="id_group" value="{{ $circle->id }}">
                                            <button type="submit" class="btn btn-sm text-muted" title="Quitter le cercle">
                                                <i class="fas fa-user-minus"></i>
                                            </button>
                                        </form>
                                    @endif
                                </div>
                            </div>
                            {{--
                            <div class="text-center p-5 border-bottom position-relative">
                                @if($circle->responsible ==  auth()->user()->id)
                                <form id="form_circle_suppression" class="position-absolute" action="../groups/deleteGroup" method="POST" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="group_id" value="{{ $circle->id }}">
                                    <input type="hidden" name="circle_image" value="{{ $circle->image }}">
                                    <div>
                                        <input type="submit" class="float-right" style="position: absolute;
                                        width: 50px;
                                        height: 50px;
                                        left:175px;
                                        border-radius:50%;
                                        cursor: pointer;
                                        background: url(http://mytourdumonde.net/wp-content/uploads/Croix-rouge-erreur.png);
                                        background-size: contain;
                                        border:0;
                                        transition: 1s all ease-in-out;" value="">
                                    </div>
                                </form>
                                <form id="form_circle_ajout_membre" class="position-absolute" action="../groups/addMembersRedirect" method="POST">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="group_id" value="{{ $circle->id }}">
                                    <div >
                                        <input style="position: relative;
                                        width: 50px;
                                        height: 50px;
                                        border-radius:50%;
                                        cursor: pointer;
                                        background: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVGrr_318yzWghr-nWNsKwJ_aOk_hZ1iAmRRoNOrXqQgul_T2u);
                                        background-size: contain;
                                        border:0;" type="submit" value="">
                                    </div>
                                </form>

                                <form id="form_circle_supp_group" class="position-absolute" action="../groups/suppMemberGroup" method="POST">
                                    {{ csrf_field() }}
                                    <input type="hidden" name="id_user" value="{{ Auth::user()->id }}">
                                    <input type="hidden" name="id_group" value="{{ $circle->id }}">
                                    <div >
                                    <button type="submit" class="btn" style="position: relative;
                                            width: 50px;
                                            height: 50px;
                                            top:150px;
                                            left:175px;
                                            border-radius:50%;
                                            cursor: pointer;
                                            background-size: contain;
                                            border:0;">
                                        <i class="h1 text-danger fas fa-sign-out-alt"></i>
                                    </button>
                                    
                                    </div>
                                </form>

                                @endif
                                <div>
                                    <a href="/circles/?circle={{ $circle->id }}"><img class="rounded-circle" width="200" height="200" src="{{$circle->image }}"></a>
                                </div>
                                <div class="font-weight-bold">
                                    <a class="btn btn-light" href="/circles/?circle={{ $circle->id }}">{{ $circle->name }}</a>
                                </div>
                                <div class="p-3">Description : <br>{{ $circle->description }}</div>
                                <div class="">Responsable : <a href="">{{ App\Models\Users::getUserNameByID($circle->responsible)[0]->name }}</a></div>
                                <div class="">Nombre de membres :
                                <a class="btn btn-outline-dark rounded-circle" data-toggle="collapse" href="#membre_du_groupe{{$count}}" role="button" aria-expanded="false" aria-controls="membre_du_groupe">
                                        {{ $circle->count_members }}
                                    </a>
                                <div class="collapse" id="membre_du_groupe{{$count}}">
                                        <div class="card card-body">
                                            @foreach (App\Models\Group_member::getAllUsersOfGroup($circle->id) as $item)
                                                @foreach(App\Models\Users::getUserByID($item->id_user) as $user_member)
                                                    <a href="UserInfo?id={{$user_member->id}}">{{$user_member->name}}</a><br>
                                                @endforeach
                                            @endforeach
                                        </div>
                                    </div>


                                    <div class="tooltip">
                                        <div class="rounded-count-members">{{ $circle->count_members }}</div>
                                        <!-- Afficher la liste de tous les membres du circlees -->
                                        <!-- Pour chaque id de circlees -->
                                        <span class="tooltiptext">
                                            
                                        </span>
                                    </div>
                                </div>
                            </div>
                            --}}
                    @endforeach
                @endforeach
        </div>
    </body>
</html>