<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
        @include('base/header')
            <div class="container pt-5 mt-5">
                @if(session('success') != NULL)
                    <div id="success_message"><br>{{ session('success') }}<br></div>
                @elseif(session('error') != NULL)
                    <div id="error_message"><br>{{ session('error') }}<br></div>
                @endif
                    @php
                        if(isset($_GET['group'])){
                            $alldata = DB::table('group')->where('id', $_GET['group'])->get()[0];
                            $var_group = $_GET['group'];
                        }else{
                            $alldata = DB::table('group')->where('id', $_GET['circle'])->get()[0];
                            $var_group = $_GET['circle'];
                        }
                    @endphp
                    <div class="row">
                        <div class="col">
                            <div class="card flex-md-row mb-4 box-shadow h-md-250">
                                <div class="card-body d-flex flex-column align-items-start">
                                <h3 class="mb-0">
                                    <a class="text-dark" href="#">{{ $alldata->name }}</a>
                                </h3>
                                <div class="mb-1 text-muted">{{App\Models\Group_member::countUsersOfGroup($alldata->id)}} Membres</div>
                                <p class="card-text mb-auto">{{$alldata->description}}</p>
                                @if($alldata->is_group)
                                    Groupe géré par {{ App\Models\Users::getUserNameByID($alldata->responsible)[0]->name }}
                                @else
                                    Cercle géré par {{ App\Models\Users::getUserNameByID($alldata->responsible)[0]->name }}
                                @endif
                                </div>
                                <img class="card-img-right flex-auto d-none d-md-block" src="{{$alldata->image}}" alt="Image du groupe ou cercle" style="width: 250px; height: 250px;">
                            </div>
                        </div>
                    </div>
                    <h3>Les membres :</h3>
                    <div class="row">
                        @foreach (DB::table('group_member')->where('id_group', $var_group)->get() as $item)
                            @foreach(DB::table('users')->where('id', $item->id_user)->get() as $user_member)
                                <div class="col text-center">
                                    <form action="user/infoProfile" method="POST" enctype="multipart/form-data">
                                        {{ csrf_field() }}
                                        <input type="hidden" name="id" value="{{$user_member->id}}" required><br>
                                        <button class="btn"><img class="rounded-circle" src="{{App\Models\Users::getSomethingOfUser("image",$user_member->id)[0]->image}}" height="100" width="100"></button>
                                        <br>
                                        <input class="btn" type="submit" value="{{$user_member->name}}">
                                    </form>
                                </div>
                            @endforeach
                        @endforeach
                    </div>
                    {{--
                    <div class="container">
                            <div class="col-md-3">
                                <div class="profile-sidebar">
                                    <!-- SIDEBAR USERPIC -->
                                    <div class="profile-userpic">
                                        <img src="{{$alldata->image}}" alt="ze">
                                    </div>
                                    <!-- END SIDEBAR USERPIC -->
                                    <!-- SIDEBAR USER TITLE -->
                                    <div class="profile-usertitle">
                                        <div class="profile-usertitle-name">
                                            {{ $alldata->name }}
                                        </div>
                                        <div class="profile-usertitle-job">
                                            @if($alldata->is_group)
                                                Groupe géré par {{ App\Models\Users::getUserNameByID($alldata->responsible)[0]->name }}
                                            @else
                                                Cercle géré par {{ App\Models\Users::getUserNameByID($alldata->responsible)[0]->name }}
                                            @endif
                                        </div>
                                    </div>
                                    <!-- END SIDEBAR USER TITLE -->
                                    <!-- SIDEBAR BUTTONS -->
                                    <div class="profile-userbuttons">
                                        <div class="information_big">
                                            <h2>{{ $alldata->count_members }}</h2>
                                            Membres
                                        </div>
                                        <div class="information_big">
                                            <h2>{{ $alldata->count_members }}</h2>
                                            Fichiers
                                        </div>
                                    </div>
                                    <!-- END SIDEBAR BUTTONS -->
                                    <!-- END MENU -->
                                </div>
                            </div>
                            <div class="twice-line">
                                <div class="list_member">
                                    <h5>Membres actuels :</h5>
                                    @foreach (DB::table('group_member')->where('id_group', $var_group)->get() as $item)
                                            @foreach(DB::table('users')->where('id', $item->id_user)->get() as $user_member)
                                                <form action="user/infoProfile" method="post" enctype="multipart/form-data">
                                                    {{ csrf_field() }}
                                                    <input type="hidden" name="id" value={{$user_member->id}} required><br>
                                                    <input type="submit" value={{$user_member->name}} >
                                                </form>
                                            @endforeach
                                    @endforeach
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="profile-content">
                                    <h3>Description du groupe :</h3><br>
                                   {{ $alldata->description }}
                                </div>
                            </div>
                    </div>
                    --}}
            </div>
    </body>
</html>