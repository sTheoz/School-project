{{--
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<nav class="col-md-2 d-md-block bg-light sidebar">
	<div class="sidebar-sticky">
		<ul class="nav flex-column">
			<li class="nav-item">
                @if(strpos(url()->current(),'/user/profile'))
                    <a class="nav-link text-dark" href="/user/profile">
                        <i class="fas fa-home"></i>
                        <strong>Mon profil</strong>
                    </a>
                @else
                    <a class="nav-link text-dark" href="/user/profile">
                        <i class="fas fa-home"></i>
                        Mon profil
                    </a>
                @endif
			</li>
			<li class="nav-item">
                @if(strpos(url()->current(),'/user/groups'))
                    <a class="nav-link text-dark" href="/user/groups">
                        <i class="fas fa-users"></i>
                        <strong>Mes groupes</strong>
                    </a>
                @else
                    <a class="nav-link text-dark" href="/user/groups">
                        <i class="fas fa-users"></i>
                        Mes groupes
                    </a>
                @endif
			</li>
			<li class="nav-item">
                @if(strpos(url()->current(),'/user/circle'))
                    <a class="nav-link text-dark" href="/user/circles">
                        <i class="fas fa-circle"></i>
                        <strong>Mes cercles</strong>
                    </a>
                @else
                    <a class="nav-link text-dark" href="/user/circles">
                        <i class="fas fa-circle"></i>
                        Mes cercles
                    </a>
                @endif
			</li>
            @if(null !== DB::table('group_member')->where('id_group', 1)->where('id_user', auth()->user()->id)->get()->first())
                <hr>
                <li class="nav-item">
                    <a class="nav-link text-dark" href="/admin/users">
                        <i class="fas fa-crown"></i>
                        Administration
                    </a>
                </li>
                <li class="nav-item">
                    @if(strpos(url()->current(),'/admin/groups'))
                        <a class="nav-link text-dark" href="/admin/groups">
                            <i class="fas fa-users"></i>
                            <strong>Les groupes</strong>
                        </a>
                    @else
                        <a class="nav-link text-dark" href="/admin/groups">
                            <i class="fas fa-users"></i>
                            Les groupes
                        </a>
                    @endif
                </li>
                <li class="nav-item">
                    @if(strpos(url()->current(),'/admin/circle'))
                        <a class="nav-link text-dark" href="/admin/circles">
                            <i class="fas fa-circle"></i>
                            <strong>Les cercles</strong>
                        </a>
                    @else
                        <a class="nav-link text-dark" href="/admin/circles">
                            <i class="fas fa-circle"></i>
                            Les cercles
                        </a>
                    @endif
                </li>
            @endif
        </ul>
	</div>
</nav>
--}}