<table>
    <tr>
        <td class="first"><a href="parametreProfil"> <div class="noSelected"> Paramètres </div></a></td>
        <td class="first"><a href="donneesProfil"> <div class="selected"> Données </div></a></td>
    </tr>
</table>
<div class="Container">
        <div class="Content">
                @if(null!== session('success') )
                    <p id='success_message'>{{ session('success') }}</p>
                @endif
                @if(session('success') != NULL)
                    <div id="success_message"><br>{{ session('success') }}<br></div>
                @elseif(session('error') != NULL)
                    <div id="error_message"><br>{{ session('error') }}<br></div>
                @endif

            <label> Vous êtes connecté en tant que : {{ auth()->user()->name }}. </label><br>
            @if(null !== DB::table('group_member')->where('id_group', 1)->where('id_user', auth()->user()->id)->get()->first())
            <label> Vous êtes un admin. </label>
            @else
            <label> Dans cette interface vous pouvez modifier vos données de profil.</label>
            @endif


            <div class="boxForm">
                <form action="changePassword" method="post">
                    {{ csrf_field() }}
                    <label>Ancien mot de passe :</label><br>
                    <input type="password" name="ancienPWD" minlength=6 maxlength=50 required><br>
                    <label>Nouveau mot de passe :</label><br>
                    <input type="password" name="newPWD" minlength=6 maxlength=50 required><br>
                    <label> Confirmer le mot de passe : </label><br>
                    <input type="password" name="confirmPWD" minlength=6 maxlength=50 required><br>
                    <input type="submit" value="Appliquer">
                </form>

            </div>
            <br>
            <div class="boxForm">
                @php
                    $user = Auth::user()
                @endphp
                <img src="{{ $user->image }}" class="imgProfil" alt="{{ $user->name }}"/>
                    <form action="changePhoto" method="post">
                    {{ csrf_field() }}
                    URL Nouvelle photo :<br>
                    <input type="url" name="photo" required><br>
                    <input type="submit" value="Appliquer">
                </form>
            </div>
        </div>
</div>