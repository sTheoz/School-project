<table id="onglet">
    <tr>
        <td class="first"><a href="parametreProfil"> <div class="noSelected"> Paramètres </div> </a></td>
        <td class="first"><a href="donneesProfil"> <div class="selected"> Données </div></a></td>
    </tr>
</table>
<div class="Container">
        <div class="Content">
            <br>
            @php
                $user=Auth::user();
            @endphp
            
            <table class="data">
                <tr>
                    <td class="first"> Place utilisé : </td>
                    <td class="first"> {{ $user->size_used }}
                 <!--       if(null !== $sizeUsed=DB::table('users')->select('size_used')->where('id', auth()->user()->id)->get()->first())
                                { $sizeUsed }}
                        endif
                        / 
                        if(null !== $sizeMax=DB::table('users')->select('size_max')->where('id', auth()->user()->id)->get()->first())
                                { $sizeMax }}
                        endif-->
                        / {{ $user->size_max }} octets
                    </td>
                </tr>
                <tr>
                        <td> Date d'inscription : </td>
                        <td>    @php
                                $inscrip = substr($user->created_at,0,10);
                                $date = date_create($inscrip);
                                $inscrip = date_format($date,'j F Y');
                                @endphp
                                {{ $inscrip }}
                        </td>
                </tr>
                <tr>
                        <td> Dernière modification : </td>
                        <td> 
                            @if(null !== $date=DB::table('users')->select('updated_at')->where('id', auth()->user()->id)->get()->first())
                            @php
                                $modif = substr($date->updated_at,0,10)
                            @endphp
                            {{ $modif}}
                            @endif
                        </td>
                </tr>
                <tr>
                    <td>Fichiers uploadés</td>
                    <td>
                        @php
                            //$nbrFile = DB::table('data')->where('id', auth()->user()->id)->count();
                        @endphp
                        {{$user->numberOfFiles}}
                    </td>
                </tr>
            </table>
           
        </div>
</div>