<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="{{ URL::asset('js/Modal.js') }}"></script>
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
    @include('base/header')
    @php
        if( isset($_POST['id']) ){
            $id = $_POST['id'];
        }else{
            try{
                $id = Auth::user()->id;
            }catch(Exception $e){
            //Faire l'exception quand une personne n'est pas connecté pour le rediriger vers la page de login
            }
        }
        $user = DB::table('users')->where('id',$id)->get();
    @endphp
    <div class="container-fluid pt-5 mt-2">
        <div class="row">
            {{-- @include('user/sideBar') --}}
            <main role="main" class="col pt-3 px-4"><div style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;" class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div></div><div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;"><div style="position:absolute;width:200%;height:200%;left:0; top:0"></div></div></div>
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
                <h1 class="h2 text-info">Mon profil</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    @if(null !== DB::table('group_member')->where('id_group', 1)->where('id_user', auth()->user()->id)->get()->first())
                        <label> Vous êtes un administrateur</label><br>
                    @endif
                </div>
            </div>
            <div>
                <div class="row">
                    <div class="col-auto text-center">
                        <form class="was-validated" action="changePhoto" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <label for="validatedCustomFile" class="position-absolute text-white" style="top:30%;left:44%;font-size:xx-large;">
                                <i class="fas fa-camera"></i>
                            </label>
                            <input type="file" class="custom-file-input position-absolute rounded-circle" name="photo" style="width:200px;height:200px;" required>
                            <img width="200" height="200" class="rounded-circle" src="{{ $user[0]->image }}">
                            <br>
                            <div class="invalid-feedback">
                                Veuillez importer une image
                                <br>
                                <div class="btn text-white btn-danger mx-auto text-center w-50">
                                    <del>Valider</del>
                                </div>
                            </div>
                            <div class="valid-feedback">
                                Vous pouvez désormais valider
                                <br>
                                <button class="btn text-white btn-success mx-auto text-center w-50">
                                    Valider
                                </button>
                            </div>
                        </form>
                        {{--
                        <img src="{{ $user[0]->image }}" class="img-thumbnail rounded-circle" width="175" alt="{{ $user[0]->name }}"/>
                        <h2 class="text-info">{{ $user[0]->name }}</h2>
                        @if(!isset($_POST['id']))
                            <div id="changePhoto">
                                <form class="was-validated" action="changePhoto" method="post" enctype="multipart/form-data">
                                    <div class="col">
                                        {{ csrf_field() }}
                                        <label for="file_profile" class="btn btn-secondary" id="photo">Importer une image</label>
                                        <input class="form-control" type="file" name="photo" hidden id='file_profile' accept="image/" required>
                                        <div class="invalid-feedback">
                                            Veuillez uploader une image
                                        </div>
                                        <div class="valid-feedback">
                                            Ca semble bon !
                                        </div>
                                        <input type="submit" class="btn btn-primary" value="Changer d'avatar">
                                    </div>
                                </form>
                            </div>
                        @endif
                        --}}
                    </div>
                    <div class="col position-relative">
                        @if(!isset($_POST['id']))
                            <!-- PHP -->
                            <div>
                                <h4>Votre pourcentage d'espace utilisé : </h4>
                                @php $stat = App\Models\Users::getPercentageFiles(Auth::user()->id); @endphp
                                <div class="progress position-relative h-auto">
                                    @if($stat > 90)
                                        <div class="progress-bar-striped bg-danger" role="progressbar" style="width: {{$stat}}%" aria-valuenow="{{$stat}}%" aria-valuemin="0" aria-valuemax="100">
                                            <strong class="d-block text-center text-white">{{$stat}}% ({{App\Models\Users::getSomethingOfUser("numberOfFiles", Auth::user()->id)[0]->numberOfFiles}} fichiers)</strong>
                                        </div>
                                    @elseif($stat > 75)
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: {{$stat}}%" aria-valuenow="{{$stat}}%" aria-valuemin="0" aria-valuemax="100">
                                            <strong class="d-block text-center text-white">{{$stat}}% ({{App\Models\Users::getSomethingOfUser("numberOfFiles", Auth::user()->id)[0]->numberOfFiles}} fichiers)</strong>
                                        </div>
                                    @else
                                        <div class="progress-bar bg-info" role="progressbar" style="width: {{$stat}}%" aria-valuenow="{{$stat}}%" aria-valuemin="0" aria-valuemax="100">
                                            <strong class="d-block text-center text-white">{{$stat}}% ({{App\Models\Users::getSomethingOfUser("numberOfFiles", Auth::user()->id)[0]->numberOfFiles}} fichiers)</strong>
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <br>
                            <table class="table text-center w-50" style="bottom:0;">
                                <thead>
                                    <tr>
                                    <th scope="col">Nom</th>
                                    <th scope="col">Promotion</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Membre depuis</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">{{Auth::user()->name}}</th>
                                        <td>{{Auth::user()->promotion}}</td>
                                        <td>{{Auth::user()->email}}</td>
                                        <td>{{Auth::user()->created_at}}</td>
                                    </tr>
                                </tbody>
                            </table>
                        @endif
                    </div>
                    
                </div>


                @if(isset($success))
                    <p>{{ $success }}</p>
                @endif
                @if(isset($error))
                    <p>{{ $error }}</p>
                @endif
            
            @if(isset($_POST['id']) && $_POST['id'] != Auth::user()->id)
                <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#modalSignal">
                    Signaler l'utilisateur
                </button>


                    <!-- Modal -->
                    <div class="modal fade" id="modalSignal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Signalement de {{ $user[0]->name }}</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="signalement" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                                {{ csrf_field() }}
                                <p>Etes-vous sûr de signaler cet utilisateur ?</p>
                                <input type="hidden" name="MyID" value={{Auth::user()->id}} />
                                <input type="hidden" name="signalID" value={{ $_POST['id'] }} />
                                <textarea required name="message_signal" maxlength="300" 
                                placeholder="Ecrivez la raison de votre signalement ici..."></textarea>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" value="oui"/>
                            <input type="reset" class="btn btn-secondary" data-dismiss="modal" id="nonModal" value="non""/>
                        </div>
                        </form>
                        </div>
                    </div>
                    </div>
            @endif
            <hr>
                @if(!isset($_POST['id']))
                <!-- Changement du mot de passe -->
                <div class="row border rounded p-2">
                    <form action="changePassword" class="was-validated" method="post">
                        <div class="col">
                            <div class="form-group text-center">
                                <label for="exampleFormControlInput1">Ancien mot de passe :</label>
                                <input type="password" class="form-control" id="exampleFormControlInput1" name="ancienPWD" minlength=6 maxlength=50 required>
                                <div class="invalid-feedback">
                                    Veuillez mettre entre 6 et 50 caractères
                                </div>
                                <div class="valid-feedback">
                                    Ca semble bon !
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group text-center">
                                <label for="exampleFormControlInput2">Nouveau mot de passe :</label>
                                <input type="password" class="form-control" id="exampleFormControlInput2" name="newPWD" minlength=6 maxlength=50 required>
                                <div class="invalid-feedback">
                                    Veuillez mettre entre 6 et 50 caractères
                                </div>
                                <div class="valid-feedback">
                                    Ca semble bon !
                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group text-center">
                                <label for="exampleFormControlInput3">Confirmer le mot de passe :</label>
                                <input type="password" class="form-control" id="exampleFormControlInput3" name="confirmPWD" minlength=6 maxlength=50 required>
                                <div class="invalid-feedback">
                                    Veuillez mettre entre 6 et 50 caractères
                                </div>
                                <div class="valid-feedback">
                                    Ca semble bon !
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary d-block mx-auto w-50" type="submit">Valider</button>
                    </form>
                </div>
                @endif
            </div>
        </div>
        <form action="daemon/getFolderById" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <input type="text" name="id" required>
                <br>
            <input type="submit" value="Submit">
        </form>
    </body>
</html>