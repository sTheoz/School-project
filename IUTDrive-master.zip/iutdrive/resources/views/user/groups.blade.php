<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="{{ URL::asset('js/Modal.js') }}"></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
        @include('base/includeBootstrap')
        <title>IUTDrive</title>
    </head>
    <body>
        @include('base/header')
        <div class="container-fluid pt-5 mt-2">
      <div class="row">
        {{-- @include('user/sideBar') --}}

        <main role="main" class="col pt-3 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2 text-info">Groupes</h1>
            <div class="btn-toolbar mb-2 mb-md-0">
            </div>
              </div>
                @if(App\Models\Group_member::countGroupOfUserByID(auth()->user()->id) == 0)
                    <h1>Vous n'avez pas de groupes</h1>
                @endif
                @if(session('success') != NULL)
                    <div id="success_message"><br>{{ session('success') }}<br></div>
                @elseif(session('error') != NULL)
                    <div id="error_message"><br>{{ session('error') }}<br></div>
                @endif
                <h3>Vos groupes :</h3>
                <div class="row">
                    @foreach(App\Models\Group_member::getUserGroupMember(auth()->user()->id) as $item)
                        @foreach(DB::table('group')->where('id', $item->id_group)->where('is_group', 1)->get() as $group)
                            <div class="col-md-2 mb-4">
                                <div class="card w-100 mx-auto">
                                    <div class="position-relative">
                                        <a href="/groups?group={{$group->id}}"><img class="card-img-top" alt="image vente" src="{{$group->image}}" height="auto"></a>
                                        <small class="text-left position-absolute fixed-bottom p-1 bd-highlight text-white" style="background-color: rgba(50, 50, 50, 0.25);">
                                            Groupe de {{App\Models\Users::getSomethingOfUser("name", $group->responsible)[0]->name}}
                                        </small>
                                        <div class="card-title text-right position-absolute fixed-bottom m-0 text-white">
                                            {{App\Models\Group_member::countUsersOfGroup($group->id)}} membres
                                        </div>
                                    </div>
                                    
                                    <div class="card-body pt-0 pb-0 text-center">
                                        <h6 class="card-title text-center m-0">
                                            <a class="btn-link" href="/groups?group={{$group->id}}"><u><strong>{{ $group->name }}</strong></u></a>
                                        </h6>
                                        <small>{{$group->description}}</small>
                                        <br>
                                    </div>
                                    @if($group->responsible ==  auth()->user()->id)
                                        <div class="card-footer d-flex justify-content-around bd-highlight p-0">
                                            <div class="p-2 bd-highlight">
                                                <form class="btn btn-light border p-0" action="../groups/addMembersRedirect" method="POST">
                                                    {{ csrf_field() }}
                                                    <input type="hidden" name="group_id" value="{{ $group->id }}">
                                                    <button type="submit" class="btn btn-sm text-muted" title="Rajouter des membres">
                                                        <i class="fas fa-users-cog"></i>
                                                    </button>
                                                </form>
                                                <form class="btn btn-light border p-0" action="../groups/deleteGroup" method="POST" enctype="multipart/form-data">
                                                    {{ csrf_field() }}
                                                    <input type="hidden" name="group_id" value="{{ $group->id }}">
                                                    <input type="hidden" name="group_image" value="{{ $group->image }}">
                                                    <button type="submit" class="btn btn-sm text-danger" title="Supprimer le groupe">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                            {{--
                            <div class="col-md-2">
                                <div class="card mb-4 box-shadow">
                                    <img class="card-img-top" src="{{$group->image}}" width="100%" height="auto">
                                    <div class="card-body">
                                        <h2 class="text-center">{{ $group->name }}</h2>
                                        <p class="card-text">{{$group->description}}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            @if($group->responsible ==  auth()->user()->id)
                                                <div class="btn-group">
                                                    <form class="btn btn-sm btn-outline-secondary p-0 m-0" action="../groups/addMembersRedirect" method="POST">
                                                        {{ csrf_field() }}
                                                        <input type="hidden" name="group_id" value="{{ $group->id }}">
                                                        <button type="button" class="btn btn-sm text-muted">Ajouter des membres</button>
                                                    </form>
                                                    <form class="btn btn-sm btn-outline-secondary p-0 m-0" action="../groups/deleteGroup" method="POST" enctype="multipart/form-data">
                                                        {{ csrf_field() }}
                                                        <input type="hidden" name="group_id" value="{{ $group->id }}">
                                                        <input type="hidden" name="group_image" value="{{ $group->image }}">
                                                        <button type="button" class="btn btn-sm text-muted">Supprimer</button>
                                                    </form>
                                                </div>
                                            @endif
                                        <small class="text-muted">{{App\Models\Group_member::countUsersOfGroup($group->id)}} membres</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            --}}
                        @endforeach
                    @endforeach
                </div>
                {{-- Vérification si l'utilisateur appartient au groupe admin --}}
                @php
                $isMember = 0;
                $id_admin = DB::table('group')->select('id')->where('name', "Admin")->get()[0]->id;
                //On cherche si l'utilisateur connecté fait parti du groupe admin
                foreach (DB::table('group_member')->select('id_user')->where('id_group', $id_admin)->get() as $memberOfAdmin){
                    if(auth()->user()->id == $memberOfAdmin->id_user)
                        $isMember=1;
                }
                @endphp
                @if($isMember==1)
                <div class="modal" tabindex="-1" id="fenetrePop" role="dialog">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <form id="" action="../groups/createGroup" method="POST" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <input type="hidden" name="object_type" value="1" required>  
                        <h5 class="modal-title">Créez vos groupes :</h5>
                        <button onclick="hideModal()" type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span  aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <input type="text" name="group_name" value="" minlength="2" maxlength="200" placeholder="Nom du groupe" required>
                            </div>
                            <div>
                            <label>Responsable :</label><br>
                            <select name="group_responsible" required>
                                <option value="{{ auth()->user()->id }}" default selected>{{ auth()->user()->name }}</option>
                                @foreach(DB::table('users')->select('name')->where('name', '!=', auth()->user()->name)->orderBy('name')->get() as $all_users)
                                    <option value="{{ App\Models\Users::getUserIDByName($all_users->name)[0]->id }}">{{ $all_users->name }}</option>
                                @endforeach
                            </select>
                            </div>
                        <br><br><label>Image :</label><br>
                        <input type="file" name="group_image" class="input_image" value="" minlength="2" maxlength="200" required>
                        <br><br><label>Membres : (Vous êtes inclus dedans)</label><br>
                        <select multiple name="group_members[]">
                            @foreach(DB::table('users')->select('name')->where('name', '!=', auth()->user()->name)->get() as $all_users)
                                <option value="{{ App\Models\Users::getUserIDByName($all_users->name)[0]->id }}">{{ $all_users->name }}</option>
                            @endforeach
                        </select>
                        <textarea name="group_desc" minlength="2" maxlength="200" placeholder="Description" required></textarea>
                        <br><br><input type="submit" value="Créer le cercle">
                        </form>
                      </div>
                      <div class="modal-footer">
                      </div>
                    </div>
                  </div>
                </div>


{{--
                    <form id="form_circle_creation" action="../groups/createGroup" method="POST" enctype="multipart/form-data">
                        <h3>Créez vos groupes :</h3><br>
                        {{ csrf_field() }}
                        <div class="twice-line">
                            <div>
                            <input type="text" name="group_name" value="" minlength="2" maxlength="200" placeholder="Nom du groupe" required>
                            </div>
                            <div>
                            <label>Responsable :</label><br>
                            <select name="group_responsible" required>
                                <option value="{{ auth()->user()->id }}" default selected>{{ auth()->user()->name }}</option>
                                @foreach(DB::table('users')->select('name')->where('name', '!=', auth()->user()->name)->orderBy('name')->get() as $all_users)
                                    <option value="{{ App\Models\Users::getUserIDByName($all_users->name)[0]->id }}">{{ $all_users->name }}</option>
                                @endforeach
                            </select>
                            </div>
                        </div>
                        <br><br><label>Image :</label><br>
                        <input type="file" name="group_image" class="input_image" value="" minlength="2" maxlength="200" required>
                        <br><br><label>Membres : (Vous êtes inclus dedans)</label><br>
                        <select multiple name="group_members[]">
                            @foreach(DB::table('users')->select('name')->where('name', '!=', auth()->user()->name)->get() as $all_users)
                                <option value="{{ App\Models\Users::getUserIDByName($all_users->name)[0]->id }}">{{ $all_users->name }}</option>
                            @endforeach
                        </select>
                        <textarea name="group_desc" minlength="2" maxlength="200" placeholder="Description" required></textarea>
                        <br><br><input type="submit" value="Créer le cercle">
                    </form>--}}
                @endif
    </body>
</html>