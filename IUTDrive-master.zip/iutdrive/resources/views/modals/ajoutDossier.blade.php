<div class="modal fade" id="addDossier" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title text-center" id="exampleModalLabel">
					Ajouter un dossier
                </h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
            <form class="was-validated" action="addDirectory" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="pathFolder" value="{{$path}}">
                <div class="modal-body">
                        <div>
                            <h3 class="text-center">Groupes et droits d'accès</h3>
                            <table class="w-100 text-center">
                                <tr>
                                    <th>Lecture</th>
                                    <th>Lecture & Ecriture</th>
                                    <th>Nom du groupe</th>
                                </tr>
                                @php $count=0 @endphp
                                @if(Auth::check())
                                    @foreach(App\Models\Group_member::getUserGroupMember(Auth::user()->id) as $group)
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                    <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-1" name="checklist_read_folder[]" value="{{$group->id_group}}">
                                                    <label class="custom-control-label" for="checkbox{{$count}}-1"></label>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                    <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-2" name="checklist_write_folder[]" value="{{$group->id_group}}">
                                                    <label class="custom-control-label" for="checkbox{{$count}}-2"></label>
                                                </div>
                                            </td>
                                            <td>
                                                {{App\Models\Group::getGroupByID($group->id_group)[0]->name}}
                                            </td>
                                        </tr>
                                        @php $count++ @endphp
                                    @endforeach
                                @endif
                            </table>
                            <div>
                                <br>
                                <div class="col-md-6 m-auto text-center">
                                    <label for="validationServer03">Nom du répertoire :</label>
                                    <input type="text" class="form-control is-invalid" name="nameDirectory" placeholder="Nom du répertoire" required>
                                    <div class="invalid-feedback">
                                        Veuillez saisir un nom valide
                                    </div>
                                    <div class="valid-feedback">
                                        C'est tout bon !
                                    </div>
                                </div>
                                @if(!isset($_GET['directory']))
                                    <input type="hidden" name="path" value="/"/>
                                @else
                                    @php $valeur = '/'.$_GET['directory'] @endphp
                                    <input type="hidden" name="path" value="{{ $valeur }}">
                                @endif
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Créer le dossier</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                </div>
            </form>
		</div>
	</div>
</div>

{{--
    <div class="custom-control custom-radio mr-sm-2 ml-3">
        <input type="checkbox" class="custom-control-input" id="checkbox0" name="checklist[]" value="Alpinisme">
        <label class="custom-control-label" for="checkbox0">Alpinisme</label>
    </div>
--}}
{{--
    
                    <!-- Fenêtre modal afin d'ajouter un dossier -->
                    <div id="addDossier"  class="w3-modal">
                        <div class="w3-modal-content" style="top:20%;opacity:0.94;">     
                            <div class="w3-container">
                                <span onclick="noAddDirectory()" class="w3-button w3-display-topright">&times;</span>
                                <br>
                            </div>
                        </div>
                    </div>
    --}}