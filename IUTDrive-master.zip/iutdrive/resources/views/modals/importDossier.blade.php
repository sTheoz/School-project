<div class="modal fade" id="importDossier" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">
					Importer un répertoire
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<form class="was-validated" action="importFolder" method="POST" enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="path" value="{{$path}}">
			    <div class="modal-body">
                    <div>
                        <h3 class="text-center">Groupes et droits d'accès</h3>
                        <table class="w-100 text-center">
                            <tr>
                                <th>Lecture</th>
                                <th>Lecture & Ecriture</th>
                                <th>Nom du groupe</th>
                            </tr>
                            @php $count=0 @endphp
                            @if(isset(Auth::user()->id))
                                @foreach(App\Models\Group_member::getUserGroupMember(Auth::user()->id) as $group)
                                    <tr>
                                        <td>
                                            <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-5" name="checklist_read_import[]" value="{{$group->id_group}}">
                                                <label class="custom-control-label" for="checkbox{{$count}}-5"></label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-6" name="checklist_read_import[]" value="{{$group->id_group}}">
                                                <label class="custom-control-label" for="checkbox{{$count}}-6"></label>
                                            </div>
                                        </td>
                                        <td>{{App\Models\Group::getGroupByID($group->id_group)[0]->name}}</td>
                                    </tr>
                                    @php $count++ @endphp
                                @endforeach
                            @endif
                        </table>
                    </div>
                    <br>
                    <div class="custom-file">
						<input type="hidden" name="path" value="{{$path}}">
						<input type="file" class="custom-file-input" id="importFolderInputFile" name="folder" accept=".zip" required>
                        <label class="custom-file-label" for="importFolderInputFile">Choisissez un fichier...</label>
                        <div class="invalid-feedback text-center">Veuillez charger un fichier</div>
                        <div class="valid-feedback text-center">Tout semble bon</div>
                    </div>
			    </div>
                <div class="modal-footer">
                    @if(App\Models\Users::getPercentageFiles(Auth::user()->id) <= 100)
                        <button type="submit" class="btn btn-primary">Ajouter le fichier ({{App\Models\Users::getPercentageFiles(Auth::user()->id)}}%)</button>
                    @else
                        <div type="submit" class="btn btn-danger">
                            Cotat atteint : ({{App\Models\Users::getPercentageFiles(Auth::user()->id)}}%)
                        </div>
                    @endif
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                </div>
			</form>
		</div>
	</div>
</div>