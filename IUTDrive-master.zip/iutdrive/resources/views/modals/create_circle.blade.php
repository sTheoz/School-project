<div class="modal fade text-dark" id="addCircleModal" tabindex="-1" role="dialog" aria-labelledby="addCircle" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="addCircleTitle">
					Création d'un cercle
				</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			</div>
			<form class="was-validated" action="../groups/createGroup" method="POST" enctype="multipart/form-data">
				<div class="modal-body">
					{{ csrf_field() }}
					<input type="hidden" name="object_type" value="0" required>
					<div class="text-center mb-3">
						<h5>Nom du cercle :</h5>
						<input type="text" name="circle_name" class="form-control" placeholder="Projet Tuteuré" minlength="2" maxlength="200" required>
					</div>
                    <h5 class="text-center">Image du cercle :</h5>
                    <div class="custom-file mb-3">
                        <input type="file" name="circle_image" class="custom-file-input" id="circle_image_input" required>
                        <label class="custom-file-label" for="circle_image_input">Choisissez un fichier</label>
                    </div>
					<div class="text-center mb-3">
                        <table class="w-100 text-center">
                            <tr>
                                <th>Ajouter ?</th>
                                <th>Nom de l'utilisateur</th>
                            </tr>
                            @php $count=0 @endphp
                            @if(isset(Auth::user()->id))
                                @foreach(DB::table('users')->select('name', 'id')->where('name', '!=', auth()->user()->name)->orderBy('name')->get() as $all_users)
                                    <tr>
                                        <td class="">
                                            <div class="custom-control custom-radio mr-sm-2 ml-3">
                                                <input type="checkbox" class="custom-control-input" id="checkbox{{$count}}-5" name="circle_members[]" value="{{$all_users->id}}">
                                                <label class="custom-control-label" for="checkbox{{$count}}-5"></label>
                                            </div>
                                        </td>
                                        <td>{{$all_users->name}}</td>
                                    </tr>
                                    @php $count++ @endphp
                                @endforeach
                            @endif
                        </table>
					</div>
					<div class="text-center">
						<label>Description :</label>
						<textarea name="circle_desc" class="form-control" minlength="2" maxlength="200" style="height:250px;" required></textarea>
					</div>
				</div>
				<div class="modal-footer">
					<input type="submit" class="btn btn-primary" value="Créer le cercle">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
				</div>
			</form>
		</div>
	</div>
</div>