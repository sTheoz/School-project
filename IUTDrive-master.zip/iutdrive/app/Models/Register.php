<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Register extends Model
{
    //Vérifie les permission d'un utilisateur
    public static function fileExist($id, $path){
    }

    //Renvoi tout les fichiers qu'un utilisateur possède
    public static function getFilesByOwner($owner){
        return DB::table('register')->where('owner', $owner)->get();
    }

    public static function getPathWithID($id){
        return DB::table('register')->select('path')->where('id',$id)->get();
    }

    public static function getIDWithPath($path){
        return DB::table('register')->select('id')->where('path',$path)->get();
    }

    public static function getFileOwnerByPath($path){
        return DB::table('register')->select('owner')->where('path',$path)->get();
    }

    public static function deleteData($path){
        return DB::table('register')->where('path',$path)->delete();
    }

    public static function insertFile($type,$owner,$filesize,$path){
        try{
            DB::table('register')->insertGetId(['type' => $type,'owner' => $owner,'filesize' => $filesize, 'path' => $path]);
            return 0;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getFolderById($id_group){
        try{
            return DB::table('rights')->select('path')->where('id_group',$id_group)->get();
        }catch(Exception $e){
            return -1;
        }
    }
}
