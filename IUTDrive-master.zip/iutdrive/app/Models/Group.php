<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Group extends Model
{
    //Obtenir tout les utilisateurs d'un groupe
    public static function getGroupByID($id){
	    try{
            return DB::table('group')->where('id',$id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Obtenir le responsable d'un groupe
    public static function getMembersOfGroup($group_id){
        try{
            return DB::table('group_member')->where('id_group', $group_id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Obtenir 
    public static function getGroupWithIDAndName($group_id, $string_cer_or_grp){
        try{
            return DB::table('group')->where('id', $group_id)->where('is_group', $string_cer_or_grp)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Obtenir un nom_user par son id
    public static function getSomethingOfGroup($something, $id){
        try{
            return DB::table('group')->select($something)->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    public function verifyIdInGroup($id,$nameGroupe){
        if(isset($_POST['id']) && isset($_POST['nameGroupe'])){
            //Chercher l'appartenance au cercle et au groupe avec ce nom ci
            

        }else{
            //Non Valide
            return -1;
        }

    }

}
