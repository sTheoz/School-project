<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Users extends Model
{
    //Obtenir tout les utilisateurs
    public static function getAllUsers(){
        try{
            return DB::table('users')->get();
        }catch(Exception $e){
            return -1;
        }
    }


    //Obtenir un utilisateur par son id
    public static function getUserByID($id){
        try{
            return DB::table('users')->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Obtenir un nom_user par son id
    public static function getUserNameByID($id){
        try{
            return DB::table('users')->select('name')->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Obtenir un nom_user par son id
    public static function getSomethingOfUser($something, $id){
        try{
            return DB::table('users')->select($something)->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Obtenir un id_user par son nom
    public static function getUserIDByName($name){
        try{
            return DB::table('users')->select('id')->where('name', $name)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Modifier la valeur de size_used d'un utilisateur par son id
    public static function changeSize_UsedByID($id, $value){
        try{
            DB::table('users')->where('id', $id)->update(['size_used' => (DB::table('users')->where('id', $id)->get()[0]->size_used)+$value]);
        }catch(Exception $e){
            return -1;
        }
    }

    //Modifier la valeur de size_max d'un utilsiateur par son id
    public static function changeSize_MaxByID($id, $value){
        try{
            DB::table('users')->where('id', $id)->update(['size_max' => $value]);
        }catch(Exception $e){
            return -1;
        }
    }

    //Modifier la valeur de numberOfFiles d'un utilsiateur par son id
    public static function changeNumberOfFilesByID($id, $value){
        try{
            DB::table('users')->where('id', $id)->update(['numberOfFiles' => (DB::table('users')->where('id', $id)->get()[0]->numberOfFiles)+$value]);
        }catch(Exception $e){
            return -1;
        }
    }

    //Changer le password d'un utilisateur
    public static function changePasswordByID($id, $old_password, $new_password, $new_password_confirm){
        try{
            if(isset($old_password) && isset($new_password) && isset($new_password_confirm) ){
                if( Hash::check(($old_password),DB::table('users')->select('password')->where('id',auth()->user()->id)->get()[0]->password) ){
                    if($new_password == $new_password_confirm){
                        DB::table('users')->where('id',auth()->user()->id)->update(['password' => Hash::make($new_password)]);
                        return 1;
                    }
                }
            }
            return -1;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function changeEMailByID($id, $new_email){
        try{
            DB::table('users')->where('id', $id)->update(['email' => $new_email]);
        }catch(Exception $e){
            return -1;
        }
    }

    public static function increaseSizeUsed($id, $size){
        try{
        
            return DB::table('users')->where('id', $id)->increment('size_used', $size);
        }catch(Exception $e){
            return -1;
        }
    }

    public static function decreaseSizeUsed($id, $size){
        try{
            return DB::table('users')->where('id', $id)->decrement('size_used', $size);
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getSizeUsed($id){
        try{
            return DB::table('users')->select('size_used')->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getSizeMax($id){
        try{
            return DB::table('users')->select('size_max')->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getNumberOfFiles($id){
        try{
            return DB::table('users')->select('numberOfFiles')->where('id', $id)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function incrementNumberOfFiles($id){
        try{
            DB::table('users')->where('id', $id)->increment('numberOfFiles');
            return 0;
        }catch(Exception $e){
            return -1;
        }
    }
    public static function decrementNumberOfFiles($id){
        try{
            DB::table('users')->where('id', $id)->decrement('numberOfFiles');
            return 0;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getPercentageFiles($id){
        try{
            return round((auth()->user()->size_used/auth()->user()->size_max)*100,2);
        }catch(Exception $e){
            return -1;
        }
    }

    //Fonction pierre
    public static function verifyPassword($id, $password){
        try{
            if( Hash::check(($password),DB::table('users')->select('password')->where('id',auth()->user()->id)->get()[0]->password) ){
                return 0;
            }
            return 1;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function verifySignal($id){
        try{
            $number = DB::table('report')->where('id_signale',$id)->count();
            Users::suppOldSignal($id);
            if($number > 0){
                $message = "L'utilisateur avec l'id :".$id." a été signalé ". $number ." fois. Veuillez regarder ce problème ...";
                mail('theo.szatkowski@etu.u-pec.fr','[REPORT] '.$id, $message);
            }
            return 0;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function suppOldSignal($id){
        try{
            DB::table('report')->where('date', '<',mktime(0,0,0,date("Y"),date("m"),date("d") - 365))->delete();
            return 0;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function verifySignalById($id, $s_id){
        try{
            $number = DB::table('report')->where('id_signale',$id)->where('id_signalant',$s_id)->get();
            
            return 1;
        }catch(Exception $e){
            return 0;
        }
    }
}
