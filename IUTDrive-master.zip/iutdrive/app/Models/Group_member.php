<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Auth;

class Group_member extends Model
{
    //Vérifie les permission d'un utilisateur
    public static function hasRightUser($id, $path){
        try{
            if(DB::table('rights')->where('id_user', $id)->where('path', $path)->where('file_write',1)->count() > 0){
                //Il peut écrire et donc lire
                return 2;
            }else if(DB::table('rights')->where('id_user', $id)->where('path', $path)->where('file_read',1)->count() > 0){
                //Il peut lire
                return 1;
            }else{
                //Il ne peut ni lire ni écrire
                return 0;
            }
            return -1;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getNonUsersOfGroup($group_id){
        //Obtenitr la liste de tout les utilisateurs
        //POur chaque utilisatuer, on regarde si il est dans le groupe
        //Si non, on le rajoute au tableau des gens n'étant pas le groupe
        $users = array();
        foreach(DB::table('group_member')->select('id_user')->where('id_group', $group_id)->get() as $user){
            array_push($users, $user->id_user);
        }
        $not_in_group = array();
        foreach(DB::table('users')->select('id')->get() as $user){
            if(!in_array($user->id,$users)){
                //L'utilisateur est dans le groupe
                array_push($not_in_group,$user->id);
            }
        }
        return $not_in_group;
    }

    //
    public static function getUserGroupMember($id_user){
        try{
            return DB::table('group_member')->where('id_user', $id_user)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //
    public static function getAllUsersOfGroup($id_group){
        try{
            return DB::table('group_member')->where('id_group', $id_group)->get();
        }catch(Exception $e){
            return -1;
        }
    }

    //Compte le nombre de personnes dans un groupe
    public static function countUsersOfGroup($id_group){
        try{
            return DB::table('group_member')->where('id_group', $id_group)->count();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getAllGroupsOfUser($id_user){
        //Prendre les groupes dans lequel l'utilisateur est
        //Dans ces groupes, voir si ils sont présent dans des rights
        //Garder le tableau de path des fichiers ayant accès
        try{
            $rights = array();
            $group_list = array();
            $groups = DB::table('group_member')->select('id_group')->where('id_user', $id_user)->get();
            //Ne tourne que 2 fois, continue en plus englobant ca à faire
            foreach($groups as $group){
                array_push($group_list, $group->id_group);
            }
            for($i=0 ; $i < DB::table('rights')->whereIn('id_group', $group_list)->OrWhere('id_user', $id_user)->count() ; $i++){
                array_push($rights, DB::table('rights')->whereIn('id_group', $group_list)->OrWhere('id_user', $id_user)->get()[0]->path);
            }
;           return $group_list;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function countGroupOfUserByID($id_user){
        try{
            $cpt_group = 0;
            foreach(Group_member::getAllGroupsOfUser(Auth::user()->id) as $group){
                if(DB::table('group')->where('id', $group)->where('is_group',1)->count() !== 0){
                    $cpt_group++;
                }
            }
            return $cpt_group;
        }catch(Exception $e){
            return "?";
        }
    }

    public static function countCircleOfUserByID($id_user){
        try{
            $cpt_circle = 0;
            foreach(Group_member::getAllGroupsOfUser(Auth::user()->id) as $group){
                if(DB::table('group')->where('id', $group)->where('is_group',0)->count() !== 0){
                    $cpt_circle++;
                }
            }
            return $cpt_circle;
        }catch(Exception $e){
            return "?";
        }
    }

    public static function deleteUser($id_group,$id_user){
        try{
            DB::table('group_member')->where('id_user', $id_user)->where('id_group',$id_group)->delete();
            return 0;
        }catch(Exception $e){
            return -1;
        }
    }

    public static function addUser($id_group, $id_user){
        try{
            DB::table('group_member')->insert(
                [
                    'id_group' => $id_group,
                    'id_user' => $id_user
                ]
            );
            return 0;
        }catch(Exception $e){
            return 1;
        }
    }
    
}
