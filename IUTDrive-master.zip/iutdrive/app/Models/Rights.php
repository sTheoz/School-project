<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Models\Group_member;

class Rights extends Model
{
    /*
        Verification des droits
        - Vérification Ecriture, si oui alors "affichage dossier" + "possibilité suppression"
        - Vérification Lecture, si oui alors "affichage dossier"

        - Pour vérifier :
            - On prend tout les id des groupes dont l'utilisateur fait parti
            - Si l'id du groupe actuel possède un tuple dans la BDD, il a accès en écriture ou lecture
            - Sinon si son id_user est mentionné, il n'y a que lui qui a accès en lecture ET ecriture
            - Sinon, pas d'accès
    */
    //Vérifie les permission d'un utilisateur
    public static function hasRightUser($id, $path){
        try{
            //If you are admin, you have write access
            if(DB::table('group_member')->where('id_group', 1)->where('id_user', $id)->count() == 1)
                return 2;
            $groups = Group_member::getAllGroupsOfUser($id);
            foreach($groups as $group){
                //Si le groupe actuel possède un droit concernant le path
                if(DB::table('rights')->where('id_group', $group)->where('path', $path)->count() > 0){
                    //Obtenir le droit en question
                    $rights = DB::table('rights')->select('file_read','file_write')->where('id_group', $group)->where('path', $path)->get();
                    if($rights[0]->file_write == 1){
                        //Droit en écriture
                        return 2;
                    }else if($rights[0]->file_read == 1){
                        //Droit en lecture
                        return 1;
                    }else{
                        //Pas de droits
                        return 0;
                    }
                }
            }
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getPermissionRacine(){
        try{
            return DB::table('rights')->where('path', '/')->where(function ($query) {$query->where('file_read', 1)->orWhere('file_write', 1);})->get();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function getPermissionSpecificPath($directory){
        try{
            return DB::table('rights')->where(function ($query) {$query->where('path', 'like', '/'.$directory.'%')->orWhere('path', '/');})->where(function ($query2) {$query2->where('file_read', 1)->orWhere('file_write', 1);})->get();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function deleteData($path){
        try{
            return DB::table('rights')->where('path',$path)->delete();
        }catch(Exception $e){
            return -1;
        }
    }

    public static function insertRight($id_user,$id_group,$path,$file_read,$file_write){
        try{
            return DB::table('rights')->insert(['id_user' => $id_user, 'id_group' => $id_group, 'path' => $path, 'file_read' => $file_read, 'file_write' => $file_write]);
        }catch(Exception $e){
            return -1;
        }
    }

    //Renvoie la liste des utilisateurs ayant accès à un répertoire
    public static function getAccessListForDirectory($repertory){
        $permission_array  = array();
        try{
            foreach(DB::table('rights')->where('path', 'like', $repertory.'%')->get() as $access){
                if (!in_array($access->id_group, $permission_array)) {
                    array_push($permission_array,$access->id_group);
                }
            }
            return $permission_array;
        }catch(Exception $e){
            return -1;
        }
    }




}
