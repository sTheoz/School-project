<?php

namespace Artemis\Http\Controllers;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Redirect;

class MailController extends Controller
{
    public function __construct()
    {
    }
    
    public function sendMail()
    {
        if(mail("service@lucas-naveteur.fr","Mail-footer","Un mail de : ".request('email')." à été envoyé du footer avec le message suivant : \r\n".request('message'))){
            return Redirect::to('https://lucas-naveteur.fr/Artemis/public/')->with('success', 'Votre mail à bien été envoyé !');
        }else{
            return Redirect::to('https://lucas-naveteur.fr/Artemis/public/')->with('error', 'Erreur lors de l\'envoi de votre mail !');
        }
    }
}