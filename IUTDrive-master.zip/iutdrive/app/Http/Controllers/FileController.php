<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Redirect;
use Auth;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use FilesystemIterator;
use App\Models\Users;
use App\Models\Register;
use App\Models\Rights;
use App\Models\Group_member;
use File;
use Storage;
use ZipArchive;

class FileController extends Controller
{
    public function __construct()
    {
    }

    function getFileNameWithDB() {
        return auth()->user()->id.'_'.DB::table('users')->select('numberOfFiles')->where('id', auth()->user()->id)->get()[0]->numberOfFiles;
    }

    //PAS TOUCHE CA MARCHE
    function addFile(Request $request){
        try{
            if(substr($request->path, -1) == "/"){
                $path = $request->path;
            }else{
                $path = $request->path."/";
            }
            $name = Input::file('fileData')->getClientOriginalName();
            if($request->checklist_read_file == NULL && $request->checklist_write_file == NULL){
                return redirect('/')->with('error', 'Vous ne pouvez pas donner aucun accès');
            }
            if(!empty($request->checklist_read_file)){
                foreach($request->checklist_read_file as $group_id){
                    //Pour chaque groupe ayant accès en lecture
                    if(DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name)->count() >= 1){
                        //Le tuple existe, on update
                        DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name)->update(['file_read' => 1]);
                    }else{
                        //le tuple existe pas, on insert
                        Rights::insertRight("-1",$group_id,$path.$name,1,0);
                    }
                }
            }
            if(!empty($request->checklist_write_file)){
                foreach($request->checklist_write_file as $group_id){
                    //Pour chaque groupe ayant accès en écriture
                    if(DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name)->count() >= 1){
                        //Le tuple existe, on update
                        DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name)->update(['file_write' => 1]);
                    }else{
                        //le tuple existe pas, on insert
                        Rights::insertRight("-1",$group_id,$path.$name,0,1);
                    }
                }
            }
            if(file_exists($path.$name)){
                Users::increaseSizeUsed(auth()->user()->id,(-1*filesize($path.$name)));
                unlink($path.$name);
                DB::table('users')->where('id', auth()->user()->id)->decrement('numberOfFiles');
                Register::deleteData($path.$name);
            }
            $file = $request->file('fileData');
            $file->move($path,$file->getClientOriginalName());
            Users::increaseSizeUsed(auth()->user()->id,filesize($path.$name));
            Users::incrementNumberOfFiles(auth()->user()->id);
            Register::insertFile(0,Auth::user()->id,filesize($path.$name),$path.$name);
            return redirect('/')->with('success', 'Le fichier à bien été rajouté')->with('path',$path);
        }catch(Exception $e){
            return redirect('/')->with('error', 'Erreur lors du traitement');
        }
    }

    //PAS TOUCHE CA MARCHE
    function addDirectory(Request $request){
        $path = $request->pathFolder;
        $name = $request->nameDirectory;
        if(file_exists($path.$name)){
            return redirect('/')->with('error', 'Le dossier existe déja, vous ne pouvez pas l\'écraser');
        }else{
            //Création du répertoire
            if(!mkdir($path.$name,0775)){
                return view('/')->with('error',"Erreur lors de la création du répertoire");
            }else{
                //Ajout dans rights
                if(!empty($request->checklist_read_folder)){
                    foreach($request->checklist_read_folder as $group_id){
                        //Pour chaque groupe ayant accès en lecture
                        if(DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name."/")->count() >= 1){
                            //Le tuple existe, on update
                            DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name."/")->update(['file_read' => 1]);
                        }else{
                            //le tuple existe pas, on insert
                            Rights::insertRight("-1",$group_id,$path.$name."/",1,0);//RACINE
                        }
                    }
                }
                if(!empty($request->checklist_write_folder)){
                    foreach($request->checklist_write_folder as $group_id){
                        //Pour chaque groupe ayant accès en écriture
                        if(DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name."/")->count() >= 1){
                            //Le tuple existe, on update
                            DB::table('rights')->where('id_group', $group_id)->where('path', $path.$name."/")->update(['file_write' => 1]);
                        }else{
                            //le tuple existe pas, on insert
                            Rights::insertRight("-1",$group_id,$path.$name."/",0,1); //RACINE
                        }
                    }
                }
                //Ajout dans register
                Register::insertFile(1,Auth::user()->id,0,$path.$name."/");
            }
            return redirect('/')->with('success', 'Votre répertoire à été créer');
        }
    }

    /* RECHERCHE DE FICHIERS OU REPERTOIRES DANS LE SERVEUR GRACE AU HEADER */
    function searchFile(Request $request){
        //echo "Je cherche un ".$request->objectType." nommé ".$request->objectName;
        $objects_access = array();
        $objects = DB::table('register')->where('path', 'LIKE', '%'.$request->objectName.'%')->where('type', $request->objectType)->get();
        foreach($objects as $object){
            if(Rights::hasRightUser(Auth::user()->id,$object->path)){
                //Vérification des droits
                array_push($objects_access,str_replace(storage_path('app/public/'),"",$object->path));
            }
        }
        return view('accueil/search_object')->with('objects_access', $objects_access);
    }

    /* SUPPRESION DES FICHIERS ET REPERTOIRES */
    function deleteFile(Request $request){
        /*
        - Suppression du fichier sur le serveur
        - Decrementation de size_used et numberoffiles
        - Suppression du fichier dans le registre
        - Suppression des droits dans rights
        */
        $fileInfo = DB::table('register')->where('id',$request->file_id)->get();
        $file_size = filesize($fileInfo[0]->path);
        unlink($fileInfo[0]->path);
        Users::decreaseSizeUsed(auth()->user()->id,$file_size);
        Users::decrementNumberOfFiles(auth()->user()->id);
        Register::deleteData($fileInfo[0]->path);
        Rights::deleteData($fileInfo[0]->path);
        return view('welcome')->with('success', 'Votre fichier a été supprimé');
        //return redirect('?directory='.substr($_POST['filename'],1).'')->with('success', 'Votre fichier a été supprimé');
    }

    function rmdir_recursive($dir) {
        $it = new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS);
        $it = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
        foreach($it as $file) {
            if ($file->isDir()){
                //Removing folder
                Register::deleteData($file->getPathname()."/");
                Rights::deleteData($file->getPathname()."/");
                rmdir($file->getPathname());
            }else{
                //Removing file
                Users::decreaseSizeUsed(Auth::user()->id,filesize($file->getPathname()));
                Users::decrementNumberOfFiles(Auth::user()->id);
                Register::deleteData($file->getPathname());
                Rights::deleteData($file->getPathname());
                unlink($file->getPathname());
            }
        }
        //Removing base folder
        rmdir($dir);
        Register::deleteData($dir);
        Rights::deleteData($dir);
    }

    function deleteFolder(Request $request){
        try{
            $folderInfo = DB::table('register')->where("id", $request->folder_id)->get();
            $this->rmdir_recursive($folderInfo[0]->path);
            return redirect('/')->with('success', 'Le répertoire à bien été supprimé !');
        }catch(Exception $e){
            return redirect('/')->with('error', 'Erreur lors de la suppresion du répertoire');
        }
    }

    function endswith($string, $test) {
        $strlen = strlen($string);
        $testlen = strlen($test);
        if ($testlen > $strlen) return false;
        return substr_compare($string, $test, $strlen - $testlen, $testlen) === 0;
    }

    //PAS TOUCHE CA MARCHE
    function downloadFile(Request $request){
        try{
            $file_url = DB::table('register')->select('path')->where('id',$request->file_id)->get()[0]->path;
            header('Content-Type: application/octet-stream');
            header("Content-Transfer-Encoding: Binary"); 
            header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\"");
            readfile($file_url);
        }catch(Exception $e){
            return "failure";
        }
    }

    function downloadFolder(Request $request){
        $path = DB::table('register')->select('path')->where('id', $request->folder_id)->get()[0]->path;
        $localpath = "/srv/http/Drive/storage/app/public/.zip/".$request->folder_id.".zip";
        $zipVar = new ZipArchive();
        $zipVar->open($localpath, ZIPARCHIVE::CREATE);
        $files = scandir($path);
        $files = new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS);
        $files = new RecursiveIteratorIterator($files, RecursiveIteratorIterator::SELF_FIRST);
        foreach($files as $file => $fileObject){
            $name = str_replace($path, "", $fileObject->getPathName());
            if($fileObject->isDir()){
                echo "Adding folder ".$name."<br>";
                $zipVar->addEmptyDir($name);
            }elseif($fileObject->isFile()){
                echo "Adding file ".$name."<br>";
                $zipVar->addFile($file); 
            }else{

            }
        }
        $zipVar->close();
        /* PARTIE TELECHARGEMENT */
        return;
    }

    //PAS TOUCHE CA MARCHE
    function gotoFolder(Request $request){
        try{
            $folder_url = DB::table('register')->select('path')->where('id',$request->folder_id)->get()[0]->path;
            return view('welcome',['path' => $folder_url]);
        }catch(Exception $e){
            return "failure";
        }
    }

    //PAS TOUCHE CA MARCHE
    function breadcrumbTraveller(Request $request){
        $path = DB::table('register')->where('id', $request->folder_id)->get()[0]->path;
        for($i = 0; $i < $request->breadcrumb_index; $i++){
            $path=substr($path, 0, strrpos( rtrim($path,"/"), '/'))."/";
        }
        return view('welcome',['path' => $path]);
    }

    //PAS TOUCHE CA MARCHE
    function goBackward(Request $request){
        try{
            $folder_url = DB::table('register')->select('path')->where('id',$request->folder_id)->get()[0]->path;
            $folder_url = substr($folder_url, 0, strrpos( rtrim($folder_url,"/"), '/'))."/";
            return view('welcome',['path' => $folder_url]);
        }catch(Exception $e){
            return "failure";
        }
    }

    function importFolder(Request $request){
        $file = $request->file('folder');
        $file->move(storage_path('app/public/'),"07564CAEG51AD65VB1ADEG6H8A1E".$file->getClientOriginalName());
        $zip = new ZipArchive;
        //Ne marche pas avec les .tar.gz
        if($zip->open(storage_path('app/public/07564CAEG51AD65VB1ADEG6H8A1E').$file->getClientOriginalName()) === TRUE){
            $zip->extractTo($request->path); 
            for( $i = 0; $i < $zip->numFiles; $i++ ){ 
                $stat = $zip->statIndex($i); 
                if(substr($stat['name'], -1) == "/"){
                    //echo "Add ".$request->path.$stat['name']." in bdd<br>";
                    Register::insertFile(0,Auth::user()->id,filesize($request->path.$stat['name']),$request->path.$stat['name']);
                }else{
                    Register::insertFile(0,Auth::user()->id,filesize($request->path.$stat['name']),$request->path.$stat['name']);
                    //echo "Add ".$request->path.$stat['name']." in bdd<br>";
                    Users::increaseSizeUsed(auth()->user()->id,filesize($request->path.$stat['name']));
                    //echo "Increase sizeUsed of ".Auth::user()->name." by ".$stat['size']."<br>";
                    Users::incrementNumberOfFiles(Auth::user()->id);
                    //echo "Increate numberOfFile by 1<br>";
                }
                //Ajout dans rights
                if(!empty($request->checklist_read_import)){
                    foreach($request->checklist_read_import as $group_id){
                        //Pour chaque groupe ayant accès en lecture
                        if(DB::table('rights')->where('id_group', $group_id)->where('path', $request->path.$stat['name'])->count() >= 1){
                            //Le tuple existe, on update
                            DB::table('rights')->where('id_group', $group_id)->where('path', $request->path.$stat['name'])->update(['file_read' => 1]);
                        }else{
                            //le tuple existe pas, on insert
                            Rights::insertRight("-1",$group_id,$request->path.$stat['name'],1,0);//RACINE
                        }
                    }
                }
                if(!empty($request->checklist_write_import)){
                    foreach($request->checklist_write_import as $group_id){
                        //Pour chaque groupe ayant accès en écriture
                        if(DB::table('rights')->where('id_group', $group_id)->where('path', $request->path.$stat['name'])->count() >= 1){
                            //Le tuple existe, on update
                            DB::table('rights')->where('id_group', $group_id)->where('path', $request->path.$stat['name'])->update(['file_write' => 1]);
                        }else{
                            //le tuple existe pas, on insert
                            Rights::insertRight("-1",$group_id,$request->path.$stat['name'],0,1); //RACINE
                        }
                    }
                }
            }
            $zip->close(storage_path('app/public/07564CAEG51AD65VB1ADEG6H8A1E').$file->getClientOriginalName());
            unlink(storage_path('app/public/07564CAEG51AD65VB1ADEG6H8A1E').$file->getClientOriginalName());
            return redirect('/')->with('success', 'L\'extraction est un succès !');
        }else{
            return redirect('/')->with('error', 'L\'extraction est un echec !');
        }
        return redirect('/')->with('error', 'Erreur inconnue :(');
    }

}
