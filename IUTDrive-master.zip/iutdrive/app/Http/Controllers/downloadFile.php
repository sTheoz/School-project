<?php 

class FileController extends Controller
{
	function download(int $num_id){
		$name = DB::table('register')->select('path','name')->where('id',$num_id)->get();
		redirect('http://37.58.131.231/storage/'.$name[0]->path.$name[0]->name);
	}
}