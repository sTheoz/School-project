<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use URL;
use App\Models\Group_member;
use App\Models\Group;

class GroupsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){}

        public function createGroup(Request $request){ 
            //C'est un groupe
            $random_string = app('App\Http\Controllers\FileController')->getFileNameWithDB();
            if(isset($request->group_name)){
                $data = "group";
                //Stocker l'image du groupe sur le serveur
                $request->group_image->storeAs('public/.images/', $random_string);
            //C'est un cercles
            }else{
                $data = "circle";
                //Stocker l'image du groupe sur le serveur
                $request->circle_image->storeAs('public/.images/', $random_string);
                //C'est ni un cercle ni un groupe, donc un bug.
            }
            try{
                $count_members=0; 
                if($request->post(''.$data.'_members') !== NULL){
                    foreach($request->post(''.$data.'_members') as $username){
                        $count_members+=1;
                    }
                }
                $id_group = DB::table('group')->max('id')+1;
                if(request(''.$data.'_image') == NULL){
                    DB::table('group')->insert(
                        [
                            'id' => $id_group,
                            'is_group' => $request->object_type,
                            'name' => request(''.$data.'_name'),
                            'image' => "https://upload.wikimedia.org/wikipedia/commons/2/20/Point_d_interrogation.jpg",
                            'description' => request(''.$data.'_desc'),
                            'count_members' => $count_members+1,
                            'responsible' => request(''.$data.'_responsible')
                        ]
                    );
                }else{
                    DB::table('group')->insert(
                        [
                            'id' => $id_group,
                            'is_group' => $request->object_type,
                            'name' => request(''.$data.'_name'),
                            'image' => "/storage/.images/".$random_string,
                            'description' => request(''.$data.'_desc'),
                            'count_members' => $count_members+1,
                            'responsible' => request(''.$data.'_responsible')
                        ]
                    );
                    DB::table('users')->where('id',auth()->user()->id)->increment('numberOfFiles',1);
                }
                if($request->post(''.$data.'_members') !== NULL){
                    foreach($request->post(''.$data.'_members') as $username){
                        DB::table('group_member')->insert(
                            [
                                'id_group' => $id_group,
                                'id_user' => DB::table('users')->where('id', $username)->get()[0]->id
                            ]
                        );
                    }
                }
                DB::table('group_member')->insert(
                    [
                        'id_group' => $id_group,
                        'id_user' => auth()->user()->id
                    ]
                );
                if(isset($request->group_name)){
                    return view('user/groups')->with('success','Votre groupe a été ajouté');
                }elseif(isset($request->circle_name)){
                    return view('user/circles')->with('success','Votre cercle a été ajouté');
                }else{
                    return view('user/circles')->with('error','Erreur lors de l\'ajout');
                }
            }catch(Exception $e){
                return view('user/circles')->with('error','Erreur lors de l\'ajout de votre cercle');
            }
        }


        public function deleteGroup(Request $request){
            try{
                DB::table('group_member')->where('id_group', $request->post('group_id'))->delete();
                DB::table('group')->where('id', $request->post('group_id'))->delete();
                //Supprimer l'image
                unlink("/srv/http/Drive/storage/app/public/".substr($request->post('circle_image'),9));
                DB::table('users')->where('id', auth()->user()->id)->decrement('numberOfFiles');
                return view('user/circles')->with('success','Votre groupe à bien été supprimé !');
            }catch(Exception $e){
                return view('user/circles')->with('error','Erreur lors de la suppression de votre cercle');
            }
        }

        public function addMembersRedirect(Request $request){
            if(($request->post('group_id') !== null)){
                return view('groups/addMembersToGroup', ['groupID' => $request->post('group_id')]);
            }elseif($request->post('circle_id') !== null){
                return view('groups/addMembersToGroup', ['groupID' => $request->post('circle_id')]);
            }else{
                return view('user/circles')->with('error','Erreur lors de la consultation du cercle ou groupe');
            }
        }

        public function changeGroup(Request $request){
            $user = null;
            if($request->group_name != Group::getSomethingOfGroup("name",$request->group_id)[0]->name){
                DB::table('group')->where('id', $request->group_id)->update(['name' => $request->group_name]);
            }
            if($request->responsible != Group::getSomethingOfGroup("responsible",$request->group_id)[0]->responsible){
                DB::table('group')->where('id', $request->group_id)->update(['responsible' => $request->responsible]);
            }
            if($request->description != Group::getSomethingOfGroup("description",$request->group_id)[0]->description){
                DB::table('group')->where('id', $request->group_id)->update(['description' => $request->description]);
            }
            //Check des ajouts d'utilisateurs au groupe
            if(!empty($request->users_to_add)){
                foreach($request->users_to_add as $user){
                    Group_member::addUser($request->group_id, $user);
                }
            }
            //Check des suppressions d'utilisateurs au groupe
            if(!empty($request->users_to_delete)){
                foreach($request->users_to_delete as $user){
                    Group_member::deleteUser($request->group_id, $user);
                }
            }
            return view('groups/addMembersToGroup', ['groupID' => $request->group_id]);
            /*
            $array = DB::table('group')->where('id', $request->post('group_id'))->get();
            //Verification des égalités des champs
            if($request->post('circle_name') != substr($array[0]->name,4)){
                //On change le nom en regardant si c'est un groupe ou un cercle
                if($request->post('circle_type') == "cer_"){
                    //C'est un cercle
                    DB::table('group')->where('id', $request->post('group_id'))->update(['name' => "cer_".$request->post('circle_name')]);
                }else{
                    //C'est un groupe
                    DB::table('group')->where('id', $request->post('group_id'))->update(['name' => "grp_".$request->post('circle_name')]);
                }
            }
            if($request->post('circle_responsible') != $array[0]->responsible){
                //On change le responsable
                DB::table('group')->where('id', $request->post('group_id'))->update(['responsible' => $request->post('circle_responsible')]);
            }
            //Image
            if (request('circle_image') == NULL){
                //On ne change pas l'image
            }else{
                $random_string = app('App\Http\Controllers\FileController')->getFileNameWithDB();
                //On supprime l'ancienne image
                unlink("/srv/http/Drive/storage/app/public/".substr($array[0]->image,9));
                DB::table('users')->where('id', auth()->user()->id)->decrement('numberOfFiles');
                //On intègre la nouvelle
                $request->circle_image->storeAs('public/.images/', $random_string);
                DB::table('users')->where('id', auth()->user()->id)->increment('numberOfFiles');
                DB::table('group')->where('id', $request->post('group_id'))->update(['image' => "/storage/.images/".$random_string]);
            }
            //Description
            if($request->post('circle_desc') != $array[0]->description){
                DB::table('group')->where('id', $request->post('group_id'))->update(['description' => $request->post('circle_desc')]);
            }
            //Membres à rajouter
            if(empty($request->post('circle_membersAdd'))){
            }else{
                //On ajoute des membres
                foreach ($request->post('circle_membersAdd') as $memberToAdd){
                    DB::table('group_member')->insert(
                        [
                        'id_group' => $request->post('group_id'),
                        'id_user' => DB::table('users')->select('id')->where('name', $memberToAdd)->get()[0]->id,
                        ]
                    );
                    DB::table('group')->where('id', $request->post('group_id'))->increment('count_members');
                }
            }
            if(empty($request->post('circle_membersDelete'))){
            }else{
                //On veut enlever des membrs
                foreach ($request->post('circle_membersDelete') as $memberToDelete){
                    DB::table('group_member')->where('id_group', $request->post('group_id'))->where('id_user', DB::table('users')->select('id')->where('name', $memberToDelete)->get()[0]->id)->delete();
                    DB::table('group')->where('id', $request->post('group_id'))->decrement('count_members');
                }
            }
            return view('groups/addMembersToGroup', ['groupID' => $request->post('group_id')]);
            */
        }

        public function deleteUser(Request $request){
            if(Group_member::deleteUser($request->post('id_group'), $request->post('id_user'))){
                return back()->with("success","Vous avez bien quitté le groupe !");
            }else{
                return back()->with("error","Vous n'avez pas réussi à sortir du groupe ...");
            }
        }

}
