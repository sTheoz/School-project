<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }

    public static function fileExtension($pathname, $filename, $extension){
        $images_array = array('jpg', 'JPG', 'png' ,'PNG' ,'jpeg' ,'JPEG');
        if(in_array($extension,$images_array)){
            echo '<img width="50" height="50" class="E_File" src="/storage/'.$filename.'">';
            return;
        }
        if(file_exists("/srv/http/Drive/storage/app/public/.images/explorator_images/".$extension.".jpg")){
            echo '<img width="50" height="50" class="E_File" src="/storage/.images/explorator_images/'.$extension.'.jpg">';
            return;
        }else{
            echo '<img width="50" height="50" class="E_File" src="/storage/.images/explorator_images/unknown.jpg">';
            return;
        }
    }

}
