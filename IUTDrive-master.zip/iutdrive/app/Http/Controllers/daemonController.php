<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use App\Models\Register;
use ZipArchive;
use App\Models\Group;

class daemonController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(){}

        public function checkPassword(){
            $mail = $_POST['mail'];
            $password = $_POST['password'];
            try{
                if(isset($_POST['mail']) && isset($_POST['password']) ){
                    if( Hash::check(($_POST['password']),DB::table('users')->select('password')->where('email',$mail)->get()[0]->password) ){
                        //Valide
                        return DB::table('users')->select('id')->where('email', $mail)->get()[0]->id;
                    }
                }
                return -1;
            }catch(Exception $e){
                return -1;
            }
        }

        public function getSomethingOfUser(){
            return DB::table('users')->select($_POST['something'])->where('id', $_POST['id'])->get();
        }

        public function getUserGroups(){
            return DB::table('group_member')->select('id_group')->where('id_user', $_POST['id'])->get();
        }

    	public function getGroupById(Request $request){
    		if(isset($request->id)){
                    return Group::getGroupByID($request->id);
            }
            return -1;
        }

        public function getOk(){
            return "Ok";
        }

        public function getArg(){
            return $_POST['test'];
        }

        public function getTok(){
            return csrf_token();
        }

        public function removeFolder(){
            try{
                unlink("/srv/http/Drive/storage/app/public/.zip/".$_POST['id_user'].".zip");
                return 0;
            }catch(Exception $e){
                return -1;
            }
        }

        //Donne tout les fichiers d'un utilisateur dans un groupe sous un .zip
        public function getFolder(){
            //$_POST['id'] = 1;
            if(DB::table('register')->where('owner',$_POST['id_user'])->count() <= 0){
                return 0;
            }
            $localpath = "/srv/http/Drive/storage/app/public/.zip/".$_POST['id_user'].".zip";
            $zipVar = new ZipArchive(); 
            $zipVar->open($localpath, ZIPARCHIVE::CREATE);
            $files = DB::table('rights')->where('id_group',$_POST['id_user'])->get();
            foreach($files as $file){
                $new_path = str_replace("/srv/http/Drive/storage/app/public/", "", $file->path);
                if(is_file($file->path)){
                    //C'est un fichier
                    $zipVar->addFile($file->path, $new_path); 
                }elseif(is_dir($file->path)){ 
                    //C'est un dossier
                    $zipVar->addEmptyDir($new_path); 
                }else{
                    echo "unknown type";
                }
            }
            $zipVar->close();
            /* PARTIE TELECHARGEMENT */
            $return_path = "37.58.131.231/storage/.zip/".$_POST['id_user'].".zip";
            return $return_path;
        }
}
