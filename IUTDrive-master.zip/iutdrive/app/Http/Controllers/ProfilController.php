<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Users;
use DB;

class ProfilController extends Controller
{
    public function __construct()
    {
    }

    public function changePassword(){
        try{
            if(isset($_POST['ancienPWD']) && isset($_POST['newPWD']) && isset($_POST['confirmPWD']) ){
                if( Hash::check(($_POST['ancienPWD']),DB::table('users')->select('password')->where('id',auth()->user()->id)->get()[0]->password) ){
                    if($_POST['newPWD'] == $_POST['confirmPWD']){
                        DB::table('users')->where('id',auth()->user()->id)->update(['password' => Hash::make($_POST['newPWD'])]);
                        return view('user/profile')->with('success','Votre mot de passe a bien été changé.');
                    }
                }
            }
            return view('user/profile')->with('error','Erreur lors de la modification de votre mot de passe.');
        }catch(Exception $e){
            return view('user/profile')->with('error','Erreur lors de la modification de votre mot de passe.');
        }
    }

    public function changePhoto(Request $request){
        if(file_exists("/srv/http/Drive/storage/app/public/.images/users/".auth()->user()->id.".jpg")){
            unlink("/srv/http/Drive/storage/app/public/.images/users/".auth()->user()->id.".jpg");
        }
        try{
            DB::table('users')->where('id',auth()->user()->id)->update(
            [
                'image' => "/storage/.images/users/".auth()->user()->id.".jpg"
            ]
        );
            $request->photo->storeAs('public/.images/users/', auth()->user()->id.".jpg");
            return view('user/profile')->with('success','Votre avatar a bien été modifié');
        }catch(Exception $e){
            return $e;
            return view('user/profile')->with('error','Votre avatar n\' pas été modifié');
        }
        
    }

    public function signalement(Request $request){
        try{
            if(!isset($request->MyID)){
                return view('user/profile')->with('error','Erreur lors du signalement0');
            }
            if(isset($request->MyID) &&  isset($request->signalID) && isset($request->message_signal)){
                $myId=$request->MyID;
                $S_Id=$request->signalID;
                $message=$request->message_signal;
                DB::table('report')->insert(
                    [
                        'id_signale'=>$S_Id,
                        'id_signalant'=>$myId,
                        'message'=>$message,
                        'date'=>date("Y-m-d")
                    ]
                );
                Users::verifySignal($S_Id);
                return view('user/profile')->with('success','Le signalement a bien été envoyé !');
            }else{
                return view('user/profile')->with('error','Erreur lors du signalement1');
            }
        }catch(Exception $e){
            return view('user/profile')->with('error','Erreur lors du signalement2');
        }
    }

}
