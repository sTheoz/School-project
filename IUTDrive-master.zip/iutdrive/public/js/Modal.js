function clickModal(){
	document.getElementById('addFichier').style.display='block';
};

function afficheSignal(){
	document.getElementById('signalU').style.display='block';
};

function afficheNoSignal(){
	document.getElementById('signalU').style.display='none';
};

function clickNoModal(){
	document.getElementById('addFichier').style.display='none';
};

function addDirectory(){
	document.getElementById('addDossier').style.display='block';
};

function noAddDirectory(){
	document.getElementById('addDossier').style.display='none';
};
function afficheOption(){
	if(eval("document.forms.bidon.advancedOption.checked == true")){
		document.getElementById('optionsAvance').style.display="none";
	}else{
		document.getElementById('optionsAvance').style.display="block";
	}
};
function hideModal(){
	document.getElementById('fenetrePop').style.display='none';
};
function sawModal(){
	document.getElementById('fenetrePop').style.display='block';
};

