<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Auth::routes();

/* CONCERNANT LES CONTROLLEURS */

Route::get('/home', 'HomeController@index')->name('home');
Route::post('groups/createGroup', 'GroupsController@createGroup');
Route::post('groups/changeGroup', 'GroupsController@changeGroup');
Route::post('groups/deleteGroup', 'GroupsController@deleteGroup');
Route::post('groups/addMembersRedirect', 'GroupsController@addMembersRedirect');
Route::post('user/changePassword', 'ProfilController@changePassword');
Route::post('user/changePhoto', 'ProfilController@changePhoto');
Route::post('addFile','FileController@addFile');
Route::post('importFolder','FileController@importFolder');
Route::post('downloadFile','FileController@downloadFile');
Route::post('downloadFolder','FileController@downloadFolder');
Route::post('gotoFolder','FileController@gotoFolder');
Route::post('breadcrumbTraveller','FileController@breadcrumbTraveller');
Route::post('goBackward','FileController@goBackward');
Route::post('deleteFile','FileController@deleteFile');
Route::post('deleteFolder','FileController@deleteFolder');
Route::post('searchFile','FileController@searchFile');
Route::post('addDirectory','FileController@addDirectory');
Route::post('user/signalement','ProfilController@signalement');
Route::post('groups/suppMemberGroup','GroupsController@deleteUser');

/* CONCERNANT UTILISATEURS */

Route::get('/auth/disconnection', function () {
    Auth::logout();
    return redirect('/');
})->middleware('auth');

Route::get('/user/groups', function () {
    return view('user/groups');
})->middleware('auth');

Route::get('/groups', function () {
    return view('user/groupInformations');
})->middleware('auth');

Route::get('/circles', function () {
    return view('user/groupInformations');
})->middleware('auth');

Route::get('/user/circles', function () {
    return view('user/circles');
})->middleware('auth');

Route::get('/user/profile', function () {
    return view('user/profile');
})->middleware('auth');

Route::get('user/parametreProfil', function () {
    return view('user/profile',['tab' => 'param']);
})->middleware('auth');

Route::get('user/donneesProfil', function () {
    return view('user/profile',['tab' => 'data']);
})->middleware('auth');

Route::post('user/infoProfile', function() {
    return view('user/profile');
})->middleware('auth');

/* CONCERNANT L'ADMINISTRATION */
Route::get('admin/circles', function() {
    return view('admin/circles');
})->middleware('auth');

Route::get('admin/groups', function() {
    return view('admin/groups');
})->middleware('auth');

Route::get('admin/signals', function() {
    return view('admin/signals');
})->middleware('auth');

Route::get('admin/users', function() {
    return view('admin/users');
})->middleware('auth');

/* CONCERNANT LE CONTROLLEUR DU DAEMON */
Route::post('daemon/login','daemonController@checkPassword');
Route::post('daemon/getImage','daemonController@getSomethingOfUser');
Route::get('daemon/getOk','daemonController@getOk');
Route::post('daemon/getGroupById','daemonController@getGroupById');
Route::post('daemon/getArg','daemonController@getArg');
Route::post('daemon/getSomethingOfUser','daemonController@getSomethingOfUser');
Route::post('daemon/getUserGroups','daemonController@getUserGroups');
//Route::post('daemon/getTok','daemonController@getTok');

//CHANGE LE GET EN POST
Route::post('daemon/getFolder','daemonController@getFolder');
Route::post('daemon/removeFolder','daemonController@removeFolder');

/* ROUTES POUR TEST */
Route::get('test', function() {
    return view('test');
});