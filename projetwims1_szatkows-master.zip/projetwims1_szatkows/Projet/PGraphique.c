/*Szatkowski Théo et Badol Jérémie*/
#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "PGraphique.h"


int accueil(void){
	int tou, x;
	couleur c;
	c=CouleurParComposante(255,255,255);
	InitialiserGraphique();
	CreerFenetre(50,50,1280,732);
	ChargerImageFond("./Images/FondMDC.jpeg");
	ChoisirCouleurDessin(c);
	RemplirRectangle(635,0,15,732);
	
	ChargerImage("./Images/marveL.png",435,100,1,1,500,500);
	ChoisirCouleurDessin(c);
	DessinerRectangle(1,1,635,730);
	ChoisirCouleurDessin(c);
	DessinerRectangle(650,1,628,730);
	ChoisirCouleurDessin(c);
	RemplirRectangle(900,300, 100, 100); 
	ChargerImage("./Images/bouton.png", 925,325,1,1,50,50);

	while(tou!=XK_Escape){
		
		x=1;
		if(tou!=XK_Escape && tou!=XK_Right  && tou!=XK_Left && tou!=XK_Return ){
		tou=Touche();
		
		
		}
			if (tou==XK_Right){
				ChargerImageFond("./Images/FondMDC.jpeg");
				ChoisirCouleurDessin(c);
				RemplirRectangle(635,0,15,732);
				ChargerImage("./Images/marveL.png",435,100,1,1,500,500);
				ChoisirCouleurDessin(c);
				DessinerRectangle(1,1,635,730);
				ChoisirCouleurDessin(c);
				DessinerRectangle(650,1,628,730);
				ChoisirCouleurDessin(c);
				RemplirRectangle(900,300, 100, 100); 
				ChargerImage("./Images/bouton.png", 925,325,1,1,50,50);
				tou=Touche();
				x=1;
		
		
			}else if(tou==XK_Left){
				ChargerImageFond("./Images/FondMDC.jpeg");
				ChoisirCouleurDessin(c);
				RemplirRectangle(635,0,15,732);
				ChargerImage("./Images/marveL.png",435,100,1,1,500,500);
				ChoisirCouleurDessin(c);
				DessinerRectangle(1,1,635,730);
				ChoisirCouleurDessin(c);
				DessinerRectangle(650,1,628,730);
				ChoisirCouleurDessin(c);
				RemplirRectangle(300,300, 100, 100);
				ChargerImage("./Images/bouton.png", 325,325,1,1,50,50);
				tou=Touche();
				x=2;
			}else if(tou==XK_Escape){
				x=0;
				break;
			}
			if(tou==XK_Return){
				return x;
			}
	}
	FermerGraphique();
	return EXIT_SUCCESS;
}


struct image* marvel(void){
	struct image* z;
	int tou=0;
	int x, y;
	y=110;
	couleur a;
	a=CouleurParComposante(255,255,255);
	EffacerEcran(a);
	ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
	ChargerImage("./Images/ironmanchoix.png", 508, 100, 10, 10, 263, 100);
	ChargerImage("./Images/spidermanchoix.png", 508, 300, 10, 10, 400, 400);
	ChargerImage("./Images/jeangreychoix.png", 508, 500, 10, 10, 400, 400);
	ChargerImage("./Images/fleche.png", 300, y, 10, 10, 100, 100);
	z=malloc(4*sizeof(int));
	
	while(tou!=XK_Escape){
		x=1;
		if(tou!=XK_Escape && tou!=XK_Up && tou!=XK_Return && tou!=XK_Down){
			tou=Touche();
		}
		if(tou==XK_Down && y<510 ){
			y=y+200;
			EffacerEcran(a);
			ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
			ChargerImage("./Images/ironmanchoix.png", 508, 100, 10, 10, 263, 100);
			ChargerImage("./Images/spidermanchoix.png", 508, 300, 10, 10, 263, 100);
			ChargerImage("./Images/jeangreychoix.png", 508, 500, 10, 10, 263, 100);
			ChargerImage("./Images/fleche.png", 300, y, 10, 10, 100, 100);
			tou=Touche();

		 }else if (tou==XK_Up && y>110){
		 	y=y-200;
		 	EffacerEcran(a);
			ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
		 	ChargerImage("./Images/ironmanchoix.png", 508, 100, 10, 10, 263, 100);
			ChargerImage("./Images/spidermanchoix.png", 508, 300, 10, 10, 263, 100);
			ChargerImage("./Images/jeangreychoix.png", 508, 500, 10, 10, 263, 100);
			ChargerImage("./Images/fleche.png", 300, y, 10, 10, 100, 100);
			tou=Touche();
		}else if(tou==XK_Escape){
			x=9;
			z->choiximage=x;
			printf("z->x=%d",z->choiximage);
			return z;
		}else if(tou==XK_Return){
			z->choiximage=x;
			z->xi=400;
			z->yi=400;
			return z;
		}else{
		 	y=y;
		 	tou=Touche();
		 	
		 }
		 if(y==110){
			x=1;
			
		}else if(y==310){
			x=2;
		}else if(y==510){
			x=3;
		
		}
			if(tou==XK_Return && x==1){
				z->xi=400;
				z->yi=400;
				z-> choiximage = x;
				return z;
			}else if(tou==XK_Return && x==2){
				z->xi=500;
				z->yi=500;
				z-> choiximage = x;
				return z;
			
			}else if(tou==XK_Return && x==3){
				z-> choiximage = x;
				z->xi=500;
				z->yi=500;
				return z;
			}else if(tou==XK_Escape){
				x=9;
				z->choiximage=x;
				return z;
	 }
	}
	 FermerGraphique();
	 return EXIT_SUCCESS;
}
struct image* dccom(void){
	struct image* z;
	int tou;
	int x, y;
	y=110;
	couleur a;
	a=CouleurParComposante(255,255,255);
	EffacerEcran(a);
	ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
	ChargerImage("./Images/shazamchoix.png", 508, 100, 10, 10, 263, 100);
	ChargerImage("./Images/flashchoix.png", 508, 300, 10, 10, 400, 400);
	ChargerImage("./Images/batmanchoix.png", 508, 500, 10, 10, 400, 400);
	ChargerImage("./Images/fleche.png", 300, y, 10, 10, 100, 100);
	z=malloc(4*sizeof(int));
	while(tou!=XK_Escape){
		x=4;
		if(tou!=XK_Escape && tou!=XK_Up && tou!=XK_Return && tou!=XK_Down){
			tou=Touche();
		}
		if(tou==XK_Down && y<510 ){
			y=y+200;
			EffacerEcran(a);
			ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
			ChargerImage("./Images/shazamchoix.png", 508, 100, 10, 10, 263, 100);
			ChargerImage("./Images/flashchoix.png", 508, 300, 10, 10, 263, 100);
			ChargerImage("./Images/batmanchoix.png", 508, 500, 10, 10, 263, 100);
			ChargerImage("./Images/fleche.png", 300, y, 10, 10, 100, 100);
			tou=Touche();

		 }else if (tou==XK_Up && y>110){
		 	y=y-200;
		 	EffacerEcran(a);
		 	ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
		 	ChargerImage("./Images/shazamchoix.png", 508, 100, 10, 10, 263, 100);
			ChargerImage("./Images/flashchoix.png", 508, 300, 10, 10, 263, 100);
			ChargerImage("./Images/batmanchoix.png", 508, 500, 10, 10, 263, 100);
			ChargerImage("./Images/fleche.png", 300, y, 10, 10, 100, 100);
			tou=Touche();
		}else if(tou==XK_Escape){
			x=9;
			z->choiximage=x;
			return z;
		}else if(tou==XK_Return){
			z-> choiximage = x;
			z->xi=700;
			z->yi=700;
			return z;
		}else{
		 	y=y;
		 	tou=Touche();
		 	
		 }
		 if(y==110){
			x=4;
			
		}else if(y==310){
			x=5;
		}else if(y==510){
			x=6;
		
		}
			if(tou==XK_Return && x==4){
				z->xi=700;
				z->yi=700;
				z-> choiximage = x;
				return z;
			}else if(tou==XK_Return && x==5){
				z->xi=500;
				z->yi=500;
				z-> choiximage = x;
				return z;
			
			}else if(tou==XK_Return && x==6){
				z-> choiximage = x;
				z->xi=600;
				z->yi=600;
				return z;
			}else if(tou==XK_Escape){
				x=9;
				z->choiximage=x;
				return z;
	 }
	}
	 FermerGraphique();
	 return EXIT_SUCCESS;
}
int decoupe(void){
	int x = 3;
	int y = 464;
	int tou;
	couleur a;
	couleur c;
	c=CouleurParComposante(0,0,0);
	a=CouleurParComposante(255,255,255);
	EffacerEcran(a);
	ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
	ChargerImage("./Images/decoupe.png",350,200,1,1,579,293);
	ChoisirCouleurDessin(c);
	DessinerRectangle(y,362,40,40);
	
	
	while(1){
		
		if(tou!=XK_Right && tou!=XK_Escape && tou!=XK_Left && tou!=XK_Return){
			tou=Touche();
		}
		if(tou==XK_Right && y<714){
			y=y+50;
			x=x+1;
			ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
			ChargerImage("./Images/decoupe.png",350,200,1,1,579,293);
			ChoisirCouleurDessin(c);
			DessinerRectangle(y,362,40,40);
			tou=Touche();
		}else if(tou==XK_Left && y>464){
			y=y-50;
			x=x-1;
			ChargerImage("./Images/arriere.png",1,1,1,1,552,63);
			ChargerImage("./Images/decoupe.png",350,200,1,1,579,293);
			ChoisirCouleurDessin(c);
			DessinerRectangle(y,362,40,40);
			tou=Touche();
		}else if(tou==XK_Escape){
			return x=9;
		}else if(tou==XK_Return){
			return x;
		}else{
			x=x;
		 	y=y;
		 	tou=Touche();
		 }
		if(tou==XK_Return){
			return x;
		}else if(tou==XK_Escape){
				return x=9;
			}
	}
	FermerGraphique();
	return EXIT_SUCCESS;
}

char menu2(){
	int att,tou;
	InitialiserGraphique();
	CreerFenetre(50,50,1280,732);
	ChargerImageFond("./Images/FondMDC.jpeg");
	EcrireTexte(170,15,"EQUIPE MARVEL",1);
	EcrireTexte(100,80,"a)Shazam",1);/*Ecriture du menu*//*Menu Marvel vs DC cliquer pour sur une image pour choisir son personnage*/
	EcrireTexte(100,130,"b)Spiderman",1);
	EcrireTexte(100,180,"c)Jean Grey",1);
	while(tou!=XK_space){
		att=ToucheEnAttente();
		if(att==1){
			tou=Touche();
			if(tou==XK_a || tou==XK_A){
				FermerGraphique();
				return 'a';
			}
			if(tou==XK_b || tou==XK_B){
				FermerGraphique();
				return 'b';
			}if(tou==XK_c || tou==XK_C){
				FermerGraphique();
				return 'c';
			}
		}
	}
	FermerGraphique();
	return EXIT_FAILURE;
}
struct image* image(int choix,int dnbr, struct image* z){
	couleur c;
	c=CouleurParComposante(255,255,255);
	EffacerEcran(c);
	if (choix==1){
	ChargerImage("./Images/ironman.png",0,0,0,0,((z->xi)/dnbr)*dnbr,(((z->yi)/dnbr)*dnbr)); /*Definition de la fonction : void ChargerImage( char *f, int x, int y, int xi, int yi, int l, int h)
		avec x et y position dans la fenêtre, xi et yi pixel en haut a gauche de l'image et l et h dimensions de l'image */
	ChargerImage("./Images/ironman.png",(z->xi)+200,0,0,0,((z->xi)/dnbr*dnbr),(((z->yi)/dnbr)*dnbr));
	
}else if(choix==2){
	ChargerImage("./Images/spiderman.png",0,0,0,0,((z->xi)/dnbr)*dnbr,(((z->yi)/dnbr)*dnbr)); 
	ChargerImage("./Images/spiderman.png",(z->xi)+200,0,0,0,((z->xi)/dnbr*dnbr),(((z->yi)/dnbr)*dnbr));
}else if(choix==3){
	ChargerImage("./Images/jeangrey.png",0,0,0,0,((z->xi)/dnbr)*dnbr,(((z->yi)/dnbr)*dnbr)); 
	ChargerImage("./Images/jeangrey.png",(z->xi)+200,0,0,0,((z->xi)/dnbr*dnbr),(((z->yi)/dnbr)*dnbr));
}else if(choix==4){
	ChargerImage("./Images/shazam.png",0,0,0,0,((z->xi)/dnbr)*dnbr,(((z->yi)/dnbr)*dnbr)); 
	ChargerImage("./Images/petitshazam.png",(z->xi)+200,0,0,0,((z->xi)/dnbr*dnbr),(((z->yi)/dnbr)*dnbr));
}else if(choix==5){
	ChargerImage("./Images/flash.png",0,0,0,0,((z->xi)/dnbr)*dnbr,(((z->yi)/dnbr)*dnbr)); 
	ChargerImage("./Images/flash.png",(z->xi)+200,0,0,0,((z->xi)/dnbr*dnbr),(((z->yi)/dnbr)*dnbr));
}else if(choix==6){
	ChargerImage("./Images/batman.png",0,0,0,0,((z->xi)/dnbr)*dnbr,(((z->yi)/dnbr)*dnbr)); 
	ChargerImage("./Images/batman.png",(z->xi)+200,0,0,0,((z->xi)/dnbr*dnbr),(((z->yi)/dnbr)*dnbr));
}

	return z;
}

int divImg(int xi, int yi,int dnbr){
	int i;
	couleur c;
	c=CouleurParComposante(255,255,255);
	ChoisirCouleurDessin(c);
	for(i=1;i<dnbr;i++){
		RemplirRectangle(0,0,xi,1);/*Pour certaines images qui ne rendait pas bien*/
		RemplirRectangle((xi/dnbr)*i-1,0,2,yi);
		RemplirRectangle(0,(yi/dnbr)*i-1,xi,2);
	}
	return (0);
}
