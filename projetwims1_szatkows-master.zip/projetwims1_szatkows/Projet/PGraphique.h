/*Szatkowski Théo et Badol Jérémie*/
#ifndef PGRAPHIQUE_H
#define PGRAPHIQUE_H

#include <graph.h>

struct image{
	int choiximage;
	int xi;
	int yi;
	int choixdecoupe;
};

int accueil(void);
struct image* marvel(void);
struct image* dccom(void);
int decoupe(void);
char menu2();
struct image* image(int choix,int dnbr,struct image* z);
int divImg(int xi, int yi,int dnbr);



#endif /* PGRAPHIQUE_H */
