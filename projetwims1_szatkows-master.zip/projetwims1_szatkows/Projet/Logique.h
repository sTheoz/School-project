/*Szatkowski Théo et Badol Jérémie*/
#ifndef LOGIQUE_H
#define LOGIQUE_H

int Assign(int dnbr, int* t);
unsigned int ImgAlea(int xi,int yi,int dnbr,int* t2);
int aleat(int dnbr, int* t);
int caseTest(int xi,int yi,int dnbr);
unsigned int moove(unsigned int r, int dnbr, int xi, int yi, int* t2,int tou, int ran);
int Libre(unsigned int r,int* t2,int dnbr);
int Verification(int* t,int* t2,int dnbr);

#endif 