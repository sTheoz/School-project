/*Szatkowski Théo et Badol Jérémie*/
#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "PGraphique.h"
#include "Logique.h"
#include <time.h>

int Assign(int dnbr,int * t){
	int i;
	for(i=0;i<(dnbr*dnbr);i++){
		t[i]=i;
	}
	return 0;
}

unsigned int ImgAlea(int xi,int yi,int dnbr,int* t2){  /*Afficher les images dans l'ordre du tableau aléatoire*/
	int i,j;
	unsigned int r;
	couleur c;
	c=CouleurParComposante(255,255,255);
	ChoisirCouleurDessin(c);
	DessinerRectangle(0,0,xi/dnbr,yi/dnbr);
	RemplirRectangle(0,0,xi/dnbr,yi/dnbr);
	for(i=0;i<(dnbr*dnbr);i++){
		for(j=0;j<(dnbr*dnbr);j++){
			if(t2[i]==j){
			CopierZone(0,1,(xi/dnbr)*(j%dnbr),(yi/dnbr)*(j/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(i%dnbr),(yi/dnbr)*(i/dnbr));
			if(t2[i]==0)
				r=i;
			break;
		}
	}
}
for(i=0;i<(dnbr*dnbr);i++){
	CopierZone(1,0,(xi/dnbr)*(i%dnbr),(yi/dnbr)*(i/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(i%dnbr),(yi/dnbr)*(i/dnbr));
}
return r;
}

int caseTest(int xi,int yi,int dnbr){
	int x,y,i,j;
	unsigned int w;
	x=xi/dnbr;
	y=yi/dnbr;
		for(i=0;i<dnbr;i++){
			if(_X<((i+1)*x)){
				x=i; /*Position de la colonne du clic*/
			}
		}
		for(j=0;j<dnbr;j++){
			if(_Y<((j+1)*y)){
			y=j; /*Position de la ligne du clic */
		} /*Essayé de mettre dans une structure pour renvoyé x et y */
	}
	w=dnbr*y+x;
	return w;
}

/*Fonction pour rendre l'image aléatoire*/

int aleat(int dnbr, int* t2){ /*Fonction aléatoire (mettre les valeurs dans un tableau)*/
	int i,j,n;
	srand((unsigned int) time(NULL));
	for(i=0;i<(dnbr*dnbr);i++){
		t2[i]=rand()%(dnbr*dnbr);
		n=i;
		for(j=0;j<n;j++){
				if(t2[j]==t2[n]){ /*Pour empêcher les doublons et avoir le bon nombre de valeurs par rapport au nombre de case*/
				i--;
				}
		}
	}
	return (0);
}

int Libre(unsigned int r,int* t2,int dnbr){
	int up=55,down=55,left=55,right=55;
	if(r==0){
		down=t2[r+dnbr];
		right=t2[r+1];
	}else{
		if(r<dnbr && (r%dnbr)==(dnbr-1)){
			down=t2[r+dnbr];
			left=t2[r-1];
			}else{
				if((r>=(dnbr*dnbr)-dnbr) && r%dnbr==0) {
					right=t2[r+1];
					up=t2[r-dnbr];
				}else{
					if(r==(dnbr*dnbr)-1){
						left=t2[r-1];
						up=t2[r-dnbr];
					}else{
						if(r%dnbr==0){
							down=t2[r+dnbr];
							right=t2[r+1];
							up=t2[r-dnbr];
						}else{
							if((r%dnbr)==(dnbr-1)){
								down=t2[r+dnbr];
								left=t2[r-1];
								up=t2[r-dnbr];
							}else{
								if(r>=(dnbr*dnbr)-dnbr){
									left=t2[r-1];
									right=t2[r+1];
									up=t2[r-dnbr];
								}else{
									if(r<dnbr){
										down=t2[r+dnbr];
										left=t2[r-1];
										right=t2[r+1];
									}else{
										left=t2[r-1];
										right=t2[r+1];
										up=t2[r-dnbr];
										down=t2[r+dnbr];
							}
						}
					}
				}
			}
		}
	}
}
	if(up==0){
		return (1);/*Valeur pour savoir si la case du dessus est blanche*/
	}
	if(down==0){
		return (2);
	}
	if(right==0){
		return (3);
	}
	if(left==0){
		return (4);
	}
	return 55;
}

unsigned int moove(unsigned int r,int dnbr,int xi, int yi,int* t2,int tou,int ran){
	int att,s,libre,c;
	while(tou!=XK_Escape){
		att=ToucheEnAttente();
		s=SourisCliquee();
		if(s==1){
			c=caseTest(xi,yi,dnbr);
			libre=Libre(c,t2,dnbr);
			if(libre==3){/*Case de droite est la case blanche*/
				CopierZone(0,0,(xi/dnbr)*(c%dnbr),(yi/dnbr)*(c/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r-1];
				r=r-1;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;

			}
			if(libre==4){/*Case de gauche est la case blanche*/
				CopierZone(0,0,(xi/dnbr)*(c%dnbr),(yi/dnbr)*(c/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r+1];
				r=r+1;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;
			}
			if(libre==1){/*Case du dessus qui est libre*/
				CopierZone(0,0,(xi/dnbr)*(c%dnbr),(yi/dnbr)*(c/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r+dnbr];
				r=r+dnbr;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;
			}
			if(libre==2){/*Case en dessous qui est libre*/
				CopierZone(0,0,(xi/dnbr)*(c%dnbr),(yi/dnbr)*(c/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r-dnbr];
				r=r-dnbr;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;
		}
		return r;
	}
			if (att==1){
				tou=Touche();
			}
			if(ran==1 || att==1){
			if(tou==XK_Right || tou==1){
				if(r%(dnbr)==(dnbr-1)){
					return r;
				}
				CopierZone(0,0,(xi/dnbr)*((r+1)%dnbr),(yi/dnbr)*((r+1)/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r+1];
				r=r+1;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;

			}
			if(tou==XK_Left || tou==2){
				if(r%dnbr==0){
					return r;
				}
				CopierZone(0,0,(xi/dnbr)*((r-1)%dnbr),(yi/dnbr)*((r-1)/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r-1];
				r=r-1;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;


			}
			if(tou==XK_Up || tou==3){
				if(r<dnbr){
					return r;
				}else{
				CopierZone(0,0,(xi/dnbr)*((r-dnbr)%dnbr),(yi/dnbr)*((r-dnbr)/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r-dnbr];
				r=r-dnbr;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;
			}

			}
			if(tou==XK_Down || tou==4){
				if(r>=((dnbr*dnbr)-dnbr)){
					return r;
				}
				CopierZone(0,0,(xi/dnbr)*((r+dnbr)%dnbr),(yi/dnbr)*((r+dnbr)/dnbr),xi/dnbr,yi/dnbr,(xi/dnbr)*(r%dnbr),(yi/dnbr)*(r/dnbr));
				t2[r]=t2[r+dnbr];
				r=r+dnbr;
				t2[r]=0;
				RemplirRectangle(xi/dnbr*(r%dnbr),(yi/dnbr)*(r/dnbr),(xi/dnbr),yi/dnbr);
				return r;

			}
		}
	}
	return(999);
}

int Verification(int* t,int* t2,int dnbr){
	int i;
	for(i=0;i<(dnbr*dnbr);i++){
		if(t[i]!=t2[i]){
			return 1;
		}
	}
	return 0;
}