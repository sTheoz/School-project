/*Szatkowski Théo et Badol Jérémie*/
#include <stdlib.h>
#include <stdio.h>
#include <graph.h>
#include "PGraphique.h"
#include "Logique.h"
#include <time.h>

int main(void){
	int choix,dnbr,verif,r,x,att,tou,i,m;
	struct image* z;
	couleur c,n;
	char compt[10],fin[100]="Bravo !! Appuyez sur (R) pour rejouer";
	int* t= NULL;
	int* t2 = NULL;
	debut: choix=accueil();
	r=0;
	if(choix == 2){
		z=marvel();
		if ((z->choiximage)==9) goto debut;
		dnbr=decoupe();
		if (dnbr==9){
			 goto debut;
			}
	}else{
		z=dccom();
	if (z->choiximage==9){
		goto debut;
	}
	dnbr=decoupe();
	if (dnbr==9) goto debut;
	}
	z=image(z->choiximage,dnbr,z);
	t = (int*) malloc(dnbr*dnbr*sizeof(int));
	Assign(dnbr,t);
	n=CouleurParComposante(255,255,255);
	ChoisirCouleurDessin(n);
	t2 = (int*) malloc(dnbr*dnbr*sizeof(int));
	for(i=0;i<(dnbr*dnbr);i++){
		t2[i]=t[i];
	}
	divImg(z->xi,z->yi,dnbr);
	srand((unsigned int) time(NULL));
	for(i=0;i<1000;i++){
		m=rand()%(4);
		m=m+1;
		r=moove(r,dnbr,z->xi,z->yi,t2,m,1);
	}
	for(i=0;i<(dnbr*dnbr);i++){
	}
	verif=Verification(t,t2,dnbr);
	x=0;
	while(verif==1){
		r=moove(r,dnbr,z->xi,z->yi,t2,n,0);	
		if(r==999){
			FermerGraphique();
			goto debut;
		}
		verif=Verification(t,t2,dnbr);
		x++;
			sprintf(compt,"%d",x);
			RemplirRectangle(z->xi+50,50,50,50);
				c=CouleurParComposante(0,0,0);
				ChoisirCouleurDessin(c);
			EcrireTexte((z->xi)+50,100,compt,2);
			ChoisirCouleurDessin(n);
			}		
		ChoisirCouleurDessin(n);
		RemplirRectangle((z->xi)/2-50,(z->yi)/2-50,700,200);
		ChoisirCouleurDessin(c);
	EcrireTexte(z->xi/2-25,z->yi/2-25,fin,2);
	while(tou!=XK_Escape){
	att=ToucheEnAttente();
	if(att==0){
		tou=Touche();
		if(tou==XK_R || tou==XK_r)goto debut;
	}
}
free(z);
free(t);
free(t2);
FermerGraphique();
return EXIT_SUCCESS;
}
