import java.awt.GraphicsEnvironment;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

import helpers.Polices;
import views.FenetreConnexion;

public class Connexion{
    public static void main(String[] args) {
        FenetreConnexion fenetre = new FenetreConnexion();
       
    }
}