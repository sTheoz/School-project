import java.awt.GraphicsEnvironment;

import views.FenetreGestionnaire;

public class Gestionnaire{
    public static void main(String[] args) {
        FenetreGestionnaire fenetre = new FenetreGestionnaire();
    }
}