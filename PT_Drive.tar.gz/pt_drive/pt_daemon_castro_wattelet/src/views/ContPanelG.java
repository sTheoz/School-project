package views;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;

import java.io.*;
import java.net.*;
import java.lang.*;

import javax.swing.*;
import java.awt.*;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;
import java.io.*;
import java.util.Properties;

import helpers.*;

import buttons.*;


public class ContPanelG extends JPanel{

    public static final String ID_IMAGE_OUI = "./rsc/images/synchro_oui.png";
    public static final String ID_IMAGE_NON = "./rsc/images/synchro_non.png";

    private JPanel titlePan;
    private JLabel textFile;
    private JPanel loginPan;
    private JPanel groupPan;
    private JPanel filePan;
    private JPanel promoPan;
    private JPanel croixPan;
    private JPanel reducePan;
    private JPanel stockageTextPan;
    private JPanel stockageBarPan;
    private GridBagLayout gbLayout;
    private FlowLayout flwLayout;
    private FenetreGestionnaire fenetre;

    public ContPanelG(FenetreGestionnaire fenetre){
        super();

        flwLayout = new FlowLayout();
        flwLayout.setVgap(0);
        flwLayout.setHgap(0);

        this.fenetre=fenetre;
        this.setLayout(null);
        this.buildCroixZone(fenetre);
        this.buildReduceZone(fenetre);
        this.setBackground(Palette.LIGHT_GREY);
        this.buildTitlePanel();
        this.buildAvatarZone();
        this.buildLoginZone();
        this.buildProgressBarStockage();
        this.buildFileChooser();
        this.buildGroupList();
    }

    private void buildGroupList() {
        JPanel panEvent = new JPanel(); //Panel ou on place tous les evenements
        JScrollPane scroll = new JScrollPane(panEvent, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBounds(50, 175, 500, 300);
        scroll.setBackground(Palette.DARK_GREY);
        this.add(scroll);//ajout du panel qui contient tous les panel/event
        //on a donc un panel avec dedans des panels/event et une scrollbar sur la gauche
         
        //j'ajoute quelques boutons pour remplir le jpanel
        //panEvent.setLayout(new GridLayout(50, 2));
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        panEvent.setLayout(gridbag);
        
        for (int i = 1; i <= 50; i++) {
            JLabel label = new JLabel("Label n" + i);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            c.gridy = i;
            c.fill = GridBagConstraints.BOTH;
            c.weightx = 7;
            gridbag.setConstraints(label,c);
            panEvent.add(label);

            JPanel pane = new JPanel();
            JLabel image = new JLabel( new ImageIcon( ContPanelG.ID_IMAGE_OUI));
            pane.setLayout(new BorderLayout());
            pane.add(image);
            c.weightx = 1;
            gridbag.setConstraints(pane,c);
            panEvent.add(pane);

            //pane.addMouseListener(new ControllerMouse(pane));
        }
        setSize(930, 610);//je redimensionne la fenetre
        setVisible(true);


/*
        groupPan = new JPanel();
        groupPan.setBackground(Palette.DARK_GREY);
        groupPan.setLayout(new GridBagLayout());
        groupPan.setBounds(50, 175, 500, 300);
        this.add(groupPan);*/

    }

    private void buildTitlePanel() {
        titlePan = new JPanel();
        titlePan.setLayout(new GridBagLayout());
        titlePan.setBackground(Palette.DARK_BLUE);
        titlePan.setLocation(0, 30);
        titlePan.setBounds(0, 0, 600, 30);
        this.add(titlePan);

        JLabel textTitre1 = new JLabel("IUT");
        textTitre1.setForeground(Palette.WHITE);
        textTitre1.setFont(Polices.little_arial);
        titlePan.add(textTitre1);

        JLabel textTitre2 = new JLabel("Drive");
        textTitre2.setForeground(Palette.SAPPHIRE_BLUE);
        textTitre2.setFont(Polices.little_arial);
        titlePan.add(textTitre2);

    }

    private void buildCroixZone(FenetreGestionnaire fenetre) {

        BoutonCroix croix = new BoutonCroix(reducePan, fenetre);
        croixPan = new JPanel();
        croixPan.setBackground(Palette.DARK_BLUE);
        croixPan.setLayout(new GridBagLayout());
        croixPan.setBounds(570, 0, 30, 30);
        croixPan.add(croix);
        this.add(croixPan);
    }

    private void buildReduceZone(FenetreGestionnaire fenetre) {

        BoutonReduce reduce = new BoutonReduce(reducePan, fenetre);
        reducePan = new JPanel();
        reducePan.setBackground(Palette.DARK_BLUE);
        reducePan.setLayout(new GridBagLayout());
        reducePan.setBounds(540, 0, 30, 30);
        reducePan.add(reduce);
        this.add(reducePan);
    }

    private void buildAvatarZone() {
        loginPan = new JPanel();
        loginPan.setBackground(Palette.DARK_GREY);
        loginPan.setLayout(new GridBagLayout());
        loginPan.setBounds(20, 50, 100, 100);
        this.add(loginPan);

        //CETTE PARTIE A SUPPRIMER POUR -A LA PLACE- CHARGER L'IMAGE
        JLabel tempTextAvatar = new JLabel("Avatar");
        tempTextAvatar.setForeground(Palette.SAPPHIRE_BLUE);
        tempTextAvatar.setFont(Polices.loginName);
        loginPan.add(tempTextAvatar);
        //FIN DE PARTIE A SUPPRIMER
    }

    private void buildLoginZone() {
        loginPan = new JPanel();
        loginPan.setBackground(Palette.LIGHT_GREY);
        loginPan.setLayout(new GridBagLayout());
        loginPan.setBounds(150, 50, 85, 20);
        this.add(loginPan);

        JLabel textLogin = new JLabel("wattelet");
        textLogin.setForeground(Palette.DARK_GREY);
        textLogin.setFont(Polices.little_arial);
        loginPan.add(textLogin);

        promoPan = new JPanel();
        promoPan.setBackground(Palette.LIGHT_GREY);
        promoPan.setLayout(new GridBagLayout());
        promoPan.setBounds(150, 75, 90, 16);
        this.add(promoPan);

        JLabel textPromo = new JLabel("An2017 - FA2");
        textPromo.setForeground(Palette.DARK_GREY);
        textPromo.setFont(Polices.promo);
        promoPan.add(textPromo);

    }

    private void buildProgressBarStockage() {

        //PANNEAU DE LA BARRE DE STOCKAGE
        stockageBarPan = new JPanel();
        stockageBarPan.setBackground(Palette.DARK_BLUE); //LIGHT_GREY
        stockageBarPan.setLayout(new GridBagLayout());
        stockageBarPan.setBounds(150, 120, 420, 20);
        this.add(stockageBarPan);

        //BAR DE STOCKAGE
        JProgressBar progress = new JProgressBar();
        progress.setMaximum(50);
        progress.setStringPainted(true);
        progress.setPreferredSize(new Dimension(420, 20));
        progress.setValue(29);
        stockageBarPan.add(progress);

        
        stockageTextPan = new JPanel();
        stockageTextPan.setBackground(Palette.LIGHT_GREY); //LIGHT_GREY
        stockageTextPan.setLayout(new GridBagLayout());
        stockageTextPan.setBounds(150, 90, 420, 30);
        this.add(stockageTextPan);

        JLabel stockageText = new JLabel("2,9 Go / 5,0 Go utilises");
        stockageText.setForeground(Palette.SAPPHIRE_BLUE);
        stockageText.setFont(Polices.stockageRestant);
        stockageTextPan.add(stockageText);
    }

    private void buildFileChooser() {
        filePan = new JPanel();
        filePan.setBackground(Palette.DARK_GREY);
        filePan.setLayout(new GridBagLayout());
        filePan.setBounds(310, 50, 260, 30);
        this.add(filePan);

        textFile = new JLabel( readInFile("file.emplacement") );
        textFile.setForeground(Palette.SAPPHIRE_BLUE);
        textFile.setFont(Polices.fileChooser);
        filePan.add(textFile);
    }

    private void openFileChooser() {
        JFileChooser choix = new JFileChooser();
        String fileEmplacement = new String();
        choix.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int retour=choix.showOpenDialog(fenetre);
        if(retour==JFileChooser.APPROVE_OPTION){
            //choix.getSelectedFile().getName();
            fileEmplacement=choix.getSelectedFile().getAbsolutePath();
            String otherFolder = fileEmplacement + File.separator + "IUTDrive" + File.separator;
            saveFolderEmplacement(otherFolder);
        } else {
            //Mettre une erreur
        }
    }

    private void saveFolderEmplacement(String emplacement) {
        final Properties prop = new Properties();
        OutputStream output = null;
        try {
            output = new FileOutputStream("config.properties");
            prop.setProperty("file.emplacement", emplacement);
            prop.store(output, null);
        } catch (final IOException io) {
            io.printStackTrace();
        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    private int createProperties() {
        String currentUsersHomeDir = System.getProperty("user.home");
        String otherFolder = currentUsersHomeDir + File.separator + "IUTDrive" + File.separator;
        saveFolderEmplacement(otherFolder);
        return 0;
    }

    private String readInFile(String clef) {
        String filename = "config.properties";
        String valeur = new String();
        final Properties prop = new Properties();


        File tmpDir = new File("config.properties");
        if (tmpDir.exists() == false) {
            System.out.println("Le fichier properties n'existe pas " + filename +"\nCreation en cours...");
            if(createProperties()!=0) {
                System.out.println("Probleme: impossible de creer le fichier " + filename+ ".");
            }
            else {
                System.out.println("Fichier properties genere.");
            }
        }
        InputStream input = null;
        try {
            input = new FileInputStream(filename);
            prop.load(input);
            if (clef.equals("file.emplacement")) {
                valeur=prop.getProperty("file.emplacement");
            }
            else if (clef.equals("utilisateur.id")) {
                valeur=prop.getProperty("utilisateur.id");
            }
            else {
                System.out.println("Erreur: Clef " + clef + " introuvable.");
                valeur=null;
            }
        } catch (final IOException ex) {
            ex.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (final IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return valeur;
    }

}