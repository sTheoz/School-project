package views;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import helpers.Palette;
import helpers.Polices;

public class ContPanel extends JPanel{

    private JPanel titlePan, msgPan;
    private IDPanel IDPan;
    private FlowLayout flwLayout;

    public ContPanel(Dimension contentPaneSize){
        super();
        flwLayout = new FlowLayout();
        flwLayout.setVgap(0);
        flwLayout.setHgap(0);
        this.setLayout(flwLayout);
        this.setBackground(Palette.DARK_GREY);
        this.buildTitlePanel(contentPaneSize);
        this.buildIDPanel(contentPaneSize);
        this.buildMsgPan(contentPaneSize);
    }

    private void buildTitlePanel(Dimension contentPaneSize){
        titlePan = new JPanel();
        titlePan.setLayout(new GridBagLayout());
        titlePan.setBackground(Palette.DARK_BLUE);
        titlePan.setPreferredSize(new Dimension((int)contentPaneSize.getWidth(), (int)contentPaneSize.getHeight()/5));
        this.add(titlePan);

        JLabel label1 = new JLabel("IUT");
        label1.setForeground(Palette.WHITE);
        label1.setFont(Polices.arial);
        titlePan.add(label1);

        JLabel label2 = new JLabel("Drive");
        label2.setForeground(Palette.SAPPHIRE_BLUE);
        label2.setFont(Polices.arial);
        titlePan.add(label2);

        

    }

    public void buildIDPanel(Dimension contentPaneSize){
        IDPan = new IDPanel(contentPaneSize);
        this.add(IDPan);
    }

    public void buildMsgPan(Dimension contentPaneSize){
        msgPan = new JPanel();
        msgPan.setPreferredSize(new Dimension((int)contentPaneSize.getWidth(), (int)contentPaneSize.getHeight()/5 + 20));
        msgPan.setBackground(Palette.LIGHT_BLUE);
        this.add(msgPan);
    }

}
