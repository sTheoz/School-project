public class buttonGroup extends JPanel{

	private JLabel lab;
	private boolean oui;
	private JLabel img_oui = new JLabel( new ImageIcon( "./rsc/images/synchro_oui.png"));
	private JLabel img_non = new JLabel( new ImageIcon( "./rsc/images/synchro_non.png"));


	public buttonGroup(JLabel label){
		super();
		this.lab = label;
		this.oui = true;
	}

	public void change(){
		if(this.oui){
			this.lab = this.img_non;
		}else{
			this.lab = this.img_oui;
		}
		this.oui = !this.oui;
	}
}