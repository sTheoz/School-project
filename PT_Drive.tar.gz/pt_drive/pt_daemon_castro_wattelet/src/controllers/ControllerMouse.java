import java.awt.event.*;

public class ControllerMouse extends MouseListener{

	private JPanel panel;

	public ControllerMouse(JPanel pan){
		super();
		this.panel = pan;
	}

	/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/
	public void mouseClicked(MouseEvent evenement){
		
	}

	/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/

	public void mouseExited(MouseEvent evenement){
	}

/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/
	public void mouseEntered(MouseEvent evenement){

	} 

	/**
		*Lorsque un bouton de la souris est pressé.
		*@param evenement MouseEvent invoqué
		*/	      
	public void mousePressed(MouseEvent evenement){
		int bouton = evenement.getButton();
		if(bouton == MouseEvent.BUTTON1){
			/*Bouton gauche*/
			cases.change();
		}else 
		if(bouton == MouseEvent.BUTTON3){
			/*Bouton droit*/
			cases.clicDroit();
		}
	} 

	/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/      
	public void mouseReleased(MouseEvent evenement){

	}
}