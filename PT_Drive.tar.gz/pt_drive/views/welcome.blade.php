<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">-->
        <link rel="stylesheet" href="{{ URL::asset('css/Header.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Footer.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Container.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Explorator.css') }}">
        <title>DriveIUT</title>
    </head>
    <body>
        @include('header')
        <div class="Container">
            <div class="Explorator">
                <h3>Explorateur</h3>
                <div class="E_Folder">
                        @php
                            if(isset($_GET['directory'])){
                                $baseurl="/srv/http/Drive/storage/app/public/";
                            }else{
                                $baseurl="/srv/http/Drive/storage/app/public";
                            }
                            if("$_SERVER[REQUEST_URI]" == "/"){
                                $path=$baseurl;
                            }else{
                                $path=$baseurl.$_GET['directory'];
                            }
                            $current_link = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
                            try{
                                foreach (new DirectoryIterator($path) as $fileInfo) {
                                    if($fileInfo->isDot()) continue;
                                    if(is_dir($path."/".$fileInfo->getFilename())){
                                        echo '<img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png">'.$fileInfo->getFilename().'<br>';
                                    }else{
                                        echo '<div class="E_File"><img src="https://cdn3.iconfinder.com/data/icons/brands-applications/512/File-512.png">'.$fileInfo->getFilename().'</div>';
                                    }
                                }
                            }catch (Exception $hi){
                                echo "<h3><i class='fas fa-exclamation-triangle'></i>Nothing to print<i class='fas fa-exclamation-triangle'></i></h3>";
                            }
                        @endphp
                    <!-- Changer l'image si fichier php,txt,java ou autre -->
                </div>
                <!-- SI CONNECTÉ -->
                @if($user = Auth::user())
                <div class="E_GroupList">
                    <!-- Je dois sélectionner tous les groupes auxquels appartiennent l'utilisateur en utilisant l'id du groupe et l'id de l'utilisateur-->
                    @php
                        $loop = DB::table('group_member')->where('id_user', auth()->user()->id)->get();
                        $count = 0;
                    @endphp
                    @foreach(DB::table('group_member')->where('id_user', auth()->user()->id)->get() as $item)
                        @if($count == 0)
                        <h3>Vos groupes :</h3><br>
                        @endif
                        @foreach(DB::table('group')->where('id', $item->id_group)->where('name', 'LIKE', 'grp_%')->get() as $group)
                            <a class="E_Group"><img src="{{ $group->image }}"> {{ substr($group->name,4) }}</a>
                            <br>
                        @endforeach
                        @php
                            $count++;
                        @endphp
                        <!-- FAIRE LA MEME POUR LES CERCLES -->
                    @endforeach
                    @php $count=0; @endphp
                    @foreach(DB::table('group_member')->where('id_user', auth()->user()->id)->get() as $item)
                        @if($count == 0)
                            <h3>Vos cercles :</h3><br>
                        @endif
                        @php $count++ @endphp
                        @foreach(DB::table('group')->where('id', $item->id_group)->where('name', 'LIKE', 'cer_%')->get() as $group)
                            <a class="E_Group"><img src="{{ $group->image }}"> {{ substr($group->name,4) }}</a>
                            <br>
                        @endforeach
                    @endforeach
                </div>
                @endif
            </div>
            <div class="Content">
                @if(isset($success))
                    <div id="success_message"><br>{{ $success }}<br></div>
                @elseif(isset($error))
                    <div id="error_message"><br>{{ $error }}<br></div>
                @endif
            @if($path == "/srv/http/Drive/storage/app/public")
                <h3>Vos fichiers dans "/"</h3>
            @else
                <h3>Vos fichiers dans "/{{ $_GET['directory'] }}"</h3>
            @endif
                <div class="Container_files">
                    <div class="files">
                            @php
                            //echo 'User='.get_current_user();
                            try{
                                if($path=="/srv/http/Drive/storage/app/public"){
                                }else{
                                echo '<div class="information">';
                                    echo '<a class="image" href="'.substr($current_link, 0, - strlen(substr(strrchr($current_link,'/'), 0))).'"><img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png"/>../</a>';
                                    echo '<a class="nom" href="'.substr($current_link, 0, - strlen(substr(strrchr($current_link,'/'), 0))).'"><br>'.$fileInfo->getFilename().'</a>';
                                echo '</div>';

                                }
                                foreach (new DirectoryIterator($path) as $fileInfo) {
                                    if($fileInfo->isDot()) continue;
                                    if(is_dir($path."/".$fileInfo->getFilename())){
                                        echo '<div class="information">';
                                            if(isset($_GET['directory'])){
                                                echo '<a class="image" href="'.$current_link."/".$fileInfo->getFilename().'"><img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png"/></a>';
                                                echo '<a class="nom" href="'.$current_link."/".$fileInfo->getFilename().'"><br>'.$fileInfo->getFilename().'</a>';
                                            }else{
                                                echo '<a class="image" href="'.$current_link.'?directory='.$fileInfo->getFilename().'"><img src="http://icons.iconarchive.com/icons/custom-icon-design/flatastic-1/256/folder-icon.png"/></a>';
                                                echo '<a class="nom" href="'.$current_link.'?directory='.$fileInfo->getFilename().'"><br>'.$fileInfo->getFilename().'</a>';
                                            }
                                        echo '</div>';
                                    }
                                }
                                foreach (new DirectoryIterator($path) as $fileInfo) {
                                    if($fileInfo->isDot()) continue;
                                    if(!is_dir($path."/".$fileInfo->getFilename())){
                                        echo '<div class="information">';
                                            if(isset($_GET['directory'])){
                                                echo '<a class="image" href="{{route("login")}}'."/?directory=".$_GET['directory'].$fileInfo->getFilename().'"><img src="https://cdn3.iconfinder.com/data/icons/brands-applications/512/File-512.png"/></a>';
                                                echo '<a class="nom" href="{{route("login")}}'."/?directory=".$_GET['directory'].$fileInfo->getFilename().'"><br>'.$fileInfo->getFilename().'</a>';
                                            }else{
                                                echo '<a class="image" href="'.$current_link.'?directory='.$fileInfo->getFilename().'"><img src="https://cdn3.iconfinder.com/data/icons/brands-applications/512/File-512.png"/></a>';
                                                echo '<a class="nom" href="'.$current_link.'?directory='.$fileInfo->getFilename().'"><br>'.$fileInfo->getFilename().'</a>';
                                            }
                                            /*
                                            if(!isset($_GET['directory'])){
                                                echo '<a class="image" href="'.$current_link.$fileInfo->getFilename().'"><img src="https://cdn3.iconfinder.com/data/icons/brands-applications/512/File-512.png"/></a>';
                                                echo '<a class="nom" href="'.$current_link.$fileInfo->getFilename().'"><br>'.$fileInfo->getFilename().'</a>';
                                            }else{
                                                echo '<a class="image" href="'.$current_link.'?directory='.$fileInfo->getFilename().'"><img src="https://cdn3.iconfinder.com/data/icons/brands-applications/512/File-512.png"/></a>';
                                                echo '<a class="nom" href="'.$current_link.'?directory='.$fileInfo->getFilename().'"><br>'.$fileInfo->getFilename().'</a>';
                                            }
                                            */
                                            //echo file_get_contents($fileInfo->getFilename());
                                        echo '</div>';
                                    }
                                }
                            }catch (Exception $hi){
                                        echo '</div>';
                                echo "<h1><i class='fas fa-exclamation-triangle'></i>Nothing to print<i class='fas fa-exclamation-triangle'></i></h1>";
                            }
                            @endphp
                    </div>
                </div>
                <div class="bottom_users">
                    
                    Liste des utilisateurs ayant accès à ce répertoire :
                    <div class="liste_user">
                            <a href="#"><img src="https://www.staples-3p.com/s7/is/image/Staples/s0000441_sc7?$splssku$" title="Protut"/></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('footer')</body>
</html>
