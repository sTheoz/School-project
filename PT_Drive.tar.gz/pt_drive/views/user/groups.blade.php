<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{ URL::asset('css/Header.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Footer.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Container.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/ParaData.css') }}">
        <title>DriveIUT</title>
    </head>
    <body>
        @include('header')
            <div class="Content">
                @if(isset($success))
                    <div id="success_message"><br>{{ $success }}<br></div>
                @elseif(isset($error))
                    <div id="error_message"><br>{{ $error }}<br></div>
                @endif

                @php
                $loop = DB::table('group_member')->where('id_user', auth()->user()->id)->get();
                $count = 0;
                @endphp
                @foreach(DB::table('group_member')->where('id_user', auth()->user()->id)->get() as $item)
                    @if($count == 0)
                        <h3>Vos groupes :</h3><br>
                        <div class="groups">
                    @endif
                        @foreach(DB::table('group')->where('id', $item->id_group)->where('name', 'LIKE', 'grp_%')->get() as $group)
                            <div class="group">
                                <div class="group_image"><a href="/groups"><img src={{ $group->image }}></a></div>
                                <div class="group_name"><a href="/groups">{{ substr($group->name,4) }}</a></div>
                                <div class="group_desc">Description : <br>{{ $group->description }}</div>
                                <div class="group_resp">Responsable : <a href="/resp">{{ $group->responsible }}</a></div>
                                <div class="group_nbmemb">Nombre de membres : {{ $group->count_members }}
                                    <div class="hover">
                                        <!-- Afficher la liste de tous les membres du groupes -->
                                        @foreach (DB::table('group_member')->where('id_group', $group->id)->get() as $item)
                                            {{ $item->id_user }}
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        @php
                            $count++;
                        @endphp
                @endforeach
                </div>
                </div>
    </div>
    </body>
</html>