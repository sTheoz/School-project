<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{ URL::asset('css/Header.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Footer.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Container.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/ParaData.css') }}">
        <title>DriveIUT</title>
    </head>
    <body>
        @include('header')
        <div class="menu">
                @if(isset($tab))
                @if($tab == 'data')
                    @include('user/donneesProfil')
                @else
                    @include('user/parametreProfil')
                @endif
            @else
                @include('user/parametreProfil')
            @endif
    </div>
    @include('footer')
    </body>
</html>