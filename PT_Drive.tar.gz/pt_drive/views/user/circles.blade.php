<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{ URL::asset('css/Header.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Footer.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/Container.css') }}">
        <link rel="stylesheet" href="{{ URL::asset('css/ParaData.css') }}">
        <title>DriveIUT</title>
    </head>
    <body>
        @include('header')
            <div class="Content">
                @if(isset($success))
                    <div id="success_message"><br>{{ $success }}<br></div>
                @elseif(isset($error))
                    <div id="error_message"><br>{{ $error }}<br></div>
                @endif

                @php
                $loop = DB::table('group_member')->where('id_user', auth()->user()->id)->get();
                $count=0; 
                @endphp
                @foreach(DB::table('group_member')->where('id_user', auth()->user()->id)->get() as $item)
                    @if($count == 0)
                        <h3>Vos cercles :</h3><br>
                        <div class="circles">
                    @endif
                    @php $count++ @endphp
                    @foreach(DB::table('group')->where('id', $item->id_group)->where('name', 'LIKE', 'cer_%')->get() as $group)
                        <div class="circle">
                            <div class="circle_image"><a href="groups"><img src={{ $group->image }}></a></div>
                            <div class="circle_name">{{ substr($group->name,4) }}</div>
                            <div class="circle_desc">{{ $group->description }}</div>
                            <div class="circle_resp">Responsable : {{ $group->responsible }}</div>
                            <div class="circle_nbmemb">{{ $group->count_members }}</div>
                        </div>
                    @endforeach
                @endforeach
                </div>
    </div>
    </body>
</html>