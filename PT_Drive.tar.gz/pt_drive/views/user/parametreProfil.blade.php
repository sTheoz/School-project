<table>
    <tr>
        <td><a href="parametreProfil" class="noSelected"> Paramètres </a></td>
        <td><a class="selected" href="donneesProfil"> Données </a></td>
    </tr>
</table>
<div class="Container">
        <div class="Content">
            @if(isset($success))
                <div id="success_message"><br>{{ $success }}<br></div>
            @elseif(isset($error))
                <div id="error_message"><br>{{ $error }}<br></div>
            @endif

            Vous êtes connecté en tant que : {{ auth()->user()->name }}
           <form action="user/parametreProfil" method="post">
            Ancien mot de passe :<br>
            <input type="password" name="ancienPWD"><br>
            Nouveau mot de passe :<br>
            <input type="password" name="newPWD"><br>
            Confirmer le mot de passe :<br>
            <input type="password" name="confirmPWD"><br>
            <input type="submit" value="Appliquer">
           </form>
           <img src="">
           <form action="user/parametreProfil" method="post">
            URL Nouvel photo :<br>
            <input type="text" name="photo"><br>
            <input type="submit" value="Appliquer">
           </form>

         </div>
</div>