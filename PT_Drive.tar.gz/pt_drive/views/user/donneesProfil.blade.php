<table>
    <tr>
        <td><a href="parametreProfil" class="selected"> Paramètres </a></td>
        <td><a class="noSelected" href="donneesProfil"> Données </a></td>
    </tr>
</table>
<div class="Container">
        <div class="Content">
            <table>
                <tr>
                    <td> Place utilisé : </td>
                    <td> >$sizeUsed< / >$sizeMax< </td>
                </tr>
                <tr>
                        <td> Place utilisé : </td>
                        <td> >$sizeUsed< </td>
                </tr>
                <tr>
                        <td> Place utilisé : </td>
                        <td> >$sizeUsed<  </td>
                </tr>

            </table>
           
        </div>
</div>