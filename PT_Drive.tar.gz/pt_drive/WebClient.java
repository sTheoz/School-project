
import java.util.*;
import java.lang.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.net.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.CookieStore;
import org.apache.http.NameValuePair;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClientBuilder.*;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;


public class WebClient {
    public static void main(String[] args) {

    try {
		HttpClient httpclient = new HttpClientBuilder.create();

		// Get the CSRF token
		httpClient.execute(new HttpGet("http://37.58.131.231/"));
		CookieStore cookieStore = httpClient.getCookieStore();
		List <Cookie> cookies =  cookieStore.getCookies();
		for (Cookie cookie: cookies) {
		    if (cookie.getName().equals("XSRF-TOKEN")) {
		        CSRFTOKEN = cookie.getValue();
		    }
		}

		// Access POST route using CSRFTOKEN
		HttpPost httppost = new HttpPost("http://37.58.131.231/daemon/getGroupById");

		try {
		    // Add your data
		    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
		    nameValuePairs.add(new BasicNameValuePair("_token", CSRFTOKEN));
		    nameValuePairs.add(new BasicNameValuePair("id", "1"));
		    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

		    // Execute HTTP Post Request
		    HttpResponse response = httpclient.execute(httppost);

		} catch (ClientProtocolException e) {
		    // TODO Auto-generated catch block
		} catch (IOException e) {
		    // TODO Auto-generated catch block
		}
    }
    catch(Exception e) {}
    }
}