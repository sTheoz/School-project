import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.awt.event.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * La classe <code>InsertionMeubleVue</code> est la vue de l'insertion de meuble
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class InsertionMeubleVue extends JPanel {
    private String cheminFacture;
    private String cheminPhoto;
    private FenetreVue fen;

    public InsertionMeubleVue(FenetreVue fenetre) {
        this.fen = fenetre;
        this.setLayout(new GridLayout(1, 1));
        JPanel main = new JPanel(new GridLayout(12, 2));
        JPanel marge = new JPanel(new GridLayout(1, 1));
        marge.setBorder(new EmptyBorder(40, 40, 40, 40));
        main.setBorder(BorderFactory.createLoweredBevelBorder());

        // -------------------- Création des différents meubles --------------------

        Model model = new Model();
        //Définition des listes de pièces d'arrivée
        JComboBox arrivee = new JComboBox();
        int piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Chambre");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Chambre " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Cuisine");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Cuisine " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Garage");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Garage " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Salle_Bain");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Salle_Bain " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Salle_Manger");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Salle_Manger " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Autre");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Autre " + count);
        }
        //Définition des listes de pièces de départ
        JComboBox depart = new JComboBox();
        int piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Chambre");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Chambre " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Cuisine");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Cuisine " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Garage");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Garage " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Salle_Bain");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Salle_Bain " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Salle_Manger");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Salle_Manger " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Autre");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Autre " + count);
        }
        JTextField description = new JTextField(this.getWidth() / 50);
        JTextField nom = new JTextField(this.getWidth() / 50);
        JTextField prix = new JTextField(this.getWidth() / 50);
        JTextField largeur = new JTextField(this.getWidth() / 50);
        JTextField longueur = new JTextField(this.getWidth() / 50);
        // insérer pdf de facture
        // insérer fichier de photo
        JButton photo = new JButton("Sélectionner une photo");
        JButton facture = new JButton("Sélectionner une facture");
        photo.addActionListener(new AddFileController(photo, cheminPhoto));
        facture.addActionListener(new AddFileController(facture, cheminFacture));
        // Listener sur tous les champs

        // On rajoute à l'interface graphique les éléments
        main.add(new JLabel("Nom *"));
        main.add(new JLabel("Prix *"));
        main.add(nom);
        main.add(prix);
        main.add(new JLabel("Largeur *"));
        main.add(new JLabel("Longueur *"));
        main.add(largeur);
        main.add(longueur);
        main.add(new JLabel("Pièce de départ *"));
        main.add(new JLabel("Pièce d'arrivée *"));
        main.add(depart);
        main.add(arrivee);
        main.add(new JLabel("Description *"));
        main.add(new JLabel("Facture (* à partir de 500 euros)"));
        main.add(description);
        main.add(facture);
        main.add(new JLabel("Photo"));
        main.add(new JLabel(" "));
        main.add(photo);
        main.add(new JLabel(" "));
        main.add(new JLabel(" "));
        // On crée le bouton ajouter avec son gridlayout permettant de lancer
        // l'insertion
        JPanel ajouter = new JPanel(new GridLayout(1, 3));
        JButton ajout = new JButton("Ajouter");
        ajout.addActionListener(new InsertionMeubleController(fen, arrivee, depart, description, nom, prix, largeur,
                longueur, facture, photo));
        // Obligation de remplir l'espace pour un bon affichage
        ajouter.add(new JLabel(" "));
        ajouter.add(ajout);
        // On ajoute le bouton
        main.add(ajouter);

        marge.add(main);
        this.add(marge);

    }
}
