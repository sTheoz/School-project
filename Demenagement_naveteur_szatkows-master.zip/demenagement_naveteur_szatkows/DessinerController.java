import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

/**
 * La classe <code>DessinerController</code> met à jour les coordonées du meuble
 * pour l'affichage de PlanPremiumVue
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class DessinerController implements MouseListener {
    private DrawObjet meuble;

    public DessinerController(DrawObjet meuble) {
        this.meuble = meuble;
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
        // on get les coordonées du meuble
        meuble.miseAJour(e.getX(), e.getY());
    }
}