import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.awt.event.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

/**
 * La classe <code>LogementsVue</code> est la fenêtre affichant le logement
 * d'arrivée et de départ avec leurs meubles et cartons respectifs, c'est la vue
 * traitant avec le plus de données de la BDD
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class LogementsVue extends JPanel {
    private boolean isPremium = false;
    private int nbPieces = 0;
    private int nbMeublesByPiece = 0;
    private String tab1[];
    private String tab2[];
    private String tab3[][];
    private int i = 0, j = 0;
    private JLabel previousLabel = new JLabel();

    // Constructeur pour set pour les informations et ouvrir la fenêtre avec
    // configuration des boutons
    public LogementsVue(FenetreVue fen, CardLayout gestio) {
        Model database = new Model();
        this.setLayout(new GridLayout(1, 1));
        JPanel gauche = new JPanel(new GridLayout(database.getCountMyMateriel(database.ReadMymail())
                + database.getCountDistinctPiecesDepart(database.ReadMymail())
                + database.getCountMyCartons(database.ReadMymail()), 1));
        JPanel droite = new JPanel(new GridLayout(database.getCountMyMateriel(database.ReadMymail())
                + database.getCountDistinctPiecesArrivee(database.ReadMymail())
                + database.getCountMyCartons(database.ReadMymail()), 1));
        JPanel main = new JPanel(new GridBagLayout());
        JPanel margeg = new JPanel(new GridLayout(1, 1));
        JPanel marged = new JPanel(new GridLayout(1, 1));
        margeg.setBorder(new EmptyBorder(20, 20, 20, 20));
        marged.setBorder(new EmptyBorder(20, 20, 20, 20));
        // Border pour l'affichage des meubles et cartons du logement de départ
        TitledBorder centerBorder = BorderFactory
                .createTitledBorder("Meubles et cartons de votre logement de de départ");
        centerBorder.setTitleJustification(TitledBorder.CENTER);
        // Border pour l'affichage des meubles et cartons du logement d'arrivée
        TitledBorder centerBorder2 = BorderFactory
                .createTitledBorder("Meubles et cartons de votre logement de d'arrivée");
        centerBorder2.setTitleJustification(TitledBorder.CENTER);
        gauche.setBorder(centerBorder);
        droite.setBorder(centerBorder2);
        // Bouton pour voir le plan
        JButton plan = new JButton("Voir plan");
        plan.addActionListener(new BarreController(4, gestio, fen, new JMenuItem(), new JMenuItem(), new JMenuItem()));
        // Listener

        // -------------------- Listage des différents meubles --------------------

        // Nb de pièce de l'utilisateur
        nbPieces = database.getCountDistinctPiecesDepart(database.ReadMymail());
        // Nb de meuble pour chaque pièces en question
        nbMeublesByPiece = database.getCountMeubleByPieceDepart(database.ReadMymail(), "Cuisine");
        // Liste de pièces
        tab1 = database.getDistinctPiecesDepart(database.ReadMymail());
        // SI IL N'Y A PAS DE CARTON DANS UN PIECE, JE N'AFFICHE PAS LA PIECE

        for (i = 0; i < tab1.length; i++) {
            if (tab1[i] != null) {
                gauche.add(new JLabel(tab1[i]));
                tab3 = database.getAllMeublesWithPiece_D(database.ReadMymail(), tab1[i]);
                for (j = 0; j < tab3.length; j++) {
                    if (tab3[j][0] != null) {
                        gauche.add(new JLabel("---" + tab3[j][0] + " [M]"));
                    }
                }
                tab3 = database.getAllCartonsWithPiece_D(database.ReadMymail(), tab1[i]);
                for (j = 0; j < tab3.length; j++) {
                    if (tab3[j][0] != null) {
                        gauche.add(new JLabel("---" + tab3[j][0] + " [C]"));
                    }
                }
            }
        }

        // SI IL N'Y A PAS DE CARTON DANS UNE PIECE, JE N'AFFICHE PAS LA PIECE
        tab2 = database.getDistinctPiecesArrivee(database.ReadMymail());
        for (i = 0; i < tab2.length; i++) {
            if (tab2[i] != null) {
                droite.add(new JLabel(tab2[i]));
                tab3 = database.getAllMeublesWithPiece_A(database.ReadMymail(), tab2[i]);
                for (j = 0; j < tab3.length; j++) {
                    if (tab3[j][0] != null) {
                        JLabel label = new JLabel("---" + tab3[j][0] + " [M]");
                        label.addMouseListener(new AddObjetController(label, fen, tab3[j][0], true, this));// true=Meuble
                        droite.add(label);
                    }
                }
                tab3 = database.getAllCartonsWithPiece_A(database.ReadMymail(), tab2[i]);
                for (j = 0; j < tab3.length; j++) {
                    if (tab3[j][0] != null) {
                        JLabel label = new JLabel("---" + tab3[j][0] + " [C]");
                        label.addMouseListener(new AddObjetController(label, fen, tab3[j][0], false, this));// false=Carton
                        droite.add(label);
                    }
                }
            }
        }
        // Nouveau gridbag pour l'affichage
        GridBagConstraints contrainte = new GridBagConstraints();
        contrainte.gridx = 0;
        contrainte.gridy = 1;
        contrainte.gridwidth = 1;
        contrainte.fill = GridBagConstraints.BOTH;
        contrainte.weightx = 1.0;
        contrainte.weighty = 1.0;
        margeg.add(gauche);
        marged.add(droite);
        main.add(margeg, contrainte);
        contrainte.gridx = 1;
        // On passe sur la colonne de droite
        main.add(marged, contrainte);
        // On initie pour mettre le bouton premium (si besoin)
        contrainte.gridx = 0;
        contrainte.gridwidth = 2;
        contrainte.gridy = 2;
        contrainte.weighty = 0.0;
        // Si l'utilisateur est premium, on affiche le bouton en bas, sinon on ne
        // l'affiche pas
        isPremium = database.isPremium(database.ReadMymail());
        if (isPremium) {
            main.add(plan, contrainte);
        }
        this.add(main);
    }

    // Renvoye le JLabel sélectionné auparavant
    public JLabel voirAncien() {
        return previousLabel;
    }

    // Met à jour le nouveau JLabel selectionné
    public void addNew(JLabel lab) {
        this.previousLabel = lab;
    }
}