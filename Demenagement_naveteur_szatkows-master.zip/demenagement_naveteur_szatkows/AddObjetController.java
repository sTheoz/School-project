import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;

/**
 * La classe <code>AddObjetController</code> permet de changer un meuble ou carton de pièce
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class AddObjetController implements MouseListener {
    private String meuble;
    private FenetreVue parent;
    private JLabel label;
    private boolean bool;
    private JLabel previousLabel = new JLabel();
    private LogementsVue vue;

    public AddObjetController(JLabel label, FenetreVue parent, String meuble, boolean bool, LogementsVue vue) {
        this.label = label;
        this.parent = parent;
        this.meuble = meuble;
        this.bool = bool;
        this.vue = vue;
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // On appuye une fois alors il y a un aperçu visuel de la sélection
        if (e.getClickCount() == 1) {
            label.setBackground(Color.RED);
            label.setOpaque(true);
        }
        // Un double-click permet d'ouvrier une fenêtre (ici JDialog) pour changer de
        // pièce le meuble/carton
        if (e.getClickCount() == 2) {
            new ChangePieceVue(parent, "Changement de pièce", true, meuble, bool);
            label.setOpaque(false);
        }
        // Enlever la couleur rouge de l'ancien JLabel afin d'actualiser visuellement la
        // sélection
        vue.voirAncien().setOpaque(false);
        vue.voirAncien().updateUI();
        vue.voirAncien().setOpaque(false);
        label.setOpaque(true);
        // On stocke le nouveau JLabel sélectionner dans la variable dans la vue
        vue.addNew(label);
        vue.voirAncien().setBackground(Color.RED);
        vue.voirAncien().setOpaque(true);
        this.label.updateUI();

    }

    // Elle ne prend aucun argument
    // Permet de renvoyé l'ancien JLabel
    public JLabel voirAncien() {
        return previousLabel;
    }

    // Elle prend en argument un JLabel
    // Permet de mettre à jour le JLabel sélectionné
    public void addNew(JLabel lab) {
        this.previousLabel = lab;
    }
}
