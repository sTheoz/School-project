import java.awt.*;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.net.URI;

/**
 * La classe <code>DessinerPlanVue</code> met à jour les coordonées du meuble
 * pour l'affichage de PlanPremiumVue lorsque la souris glisse
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class DessinerPlanVue extends JPanel {
	// Chemin de l'image
	private String url;
	private Image img;

	public DessinerPlanVue(String url) {
		this.url = url;
		try {
			Image img = ImageIO.read(new File(url));
			this.img = img;
			// this.repaint();
		} catch (IOException e) {
			System.err.println("Erreur" + e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
	}

	// C'est l'heure du De-de-de-de-de Dessin !
	@Override
	public void paintComponent(Graphics g) {
		// Création du pinceau
		Graphics pinceau = g.create();
		// On dessine le plan
		pinceau.drawImage(img, 0, 0, this);
	}
}