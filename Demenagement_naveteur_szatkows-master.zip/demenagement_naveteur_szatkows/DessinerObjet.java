import javax.swing.*;
import java.awt.*;

/**
 * La classe <code>DessinerObjet</code> permet de dessiner un objet
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class DessinerObjet extends JPanel {

    private int x = 0;
    private int y = 0;
    private Color color;
    private String nom = "";
    private int largeur = 0;
    private int longueur = 0;

    public DessinerObjet(String nom, int x, int y, int largeur, int longueur) {
        super();
        this.nom = nom;
        this.largeur = largeur / 3;
        this.longueur = longueur / 3;
        this.x = x;
        this.y = y;
        this.color = new Color(20, 20, 20);
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics pinceau = g.create();
        // Dessiner l'objet sélectionné
        pinceau.setColor(Color.ORANGE);
        pinceau.fillRect(this.x, this.y, this.largeur, this.longueur);
        pinceau.setColor(Color.BLACK);
        pinceau.drawString(nom, x, y + longueur / 2);
    }

    // Mise A Jour des arguments et redessine
    /*
     * public void dessiner(String nom, int x, int y,int largeur,int longueur) {
     * this.nom=nom; this.largeur = largeur/ 3; this.longueur = longueur/ 3; this.x
     * = x; this.y = y; this.repaint(); }
     */
}
