import javax.swing.*;
import java.awt.event.*;
import java.nio.file.*;
import java.io.*;
import java.security.*;
import java.math.*;
import java.awt.Dimension;

/**
 * La classe <code>EntreeController</code> permet de se connecter avec la touche entrée
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class EntreeController implements KeyListener {
  private JTextField mail;
  private JPasswordField password;
  private int connection = 0;
  private JFrame fen = new JFrame();
  private JCheckBox checkbox;

  public EntreeController(JTextField mail, JPasswordField password, JFrame fen, JCheckBox checkbox) {
    this.mail = mail;
    this.password = password;
    this.fen = fen;
    this.checkbox = checkbox;
  }

  @Override
  public void keyReleased(KeyEvent e) {
  }

  @Override
  public void keyTyped(KeyEvent e) {
  }

  @Override
  public void keyPressed(KeyEvent e) {
    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
      // Pas d'utilisation de getText()
      Model model = new Model();
      // connection = model.Connection(this.mail.getText(),this.password.getText());
      connection = model.Connection(this.mail.getText(), HashMe(String.valueOf(this.password.getPassword())));
      if (connection == 1) {
        if (this.checkbox.isSelected()) {
          WriteMymail(this.mail.getText());
        }
        fen.dispose();
        new FenetreVue();
        // V_Demenagement dem = new V_Demenagement();
      } else {
        JOptionPane.showMessageDialog(null, "L'identifiant ou le mot de passe n'est pas correct", "Erreur de connexion",
            JOptionPane.ERROR_MESSAGE);
      }
    }
    // Lorsque l'on clique sur le bouton, on met à jour le JLabel
  }

  // ----------D
  public boolean WriteMymail(String mail) {
    try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("mail.txt"), "utf-8"))) {
      writer.write(mail);
      writer.close();
      return false;
    } catch (IOException ex) {
      ex.printStackTrace();
      System.out.println("Erreur lors de l'écriture du fichier");
      return true;
    }
  }

  public String HashMe(String password) {
    String hash = "NULL";
    try {
      MessageDigest m = MessageDigest.getInstance("MD5");
      m.update(password.getBytes(), 0, password.length());
      hash = new BigInteger(1, m.digest()).toString(16);
      return hash;
    } catch (NoSuchAlgorithmException e) {
      System.out.println("L'algorithme rentré n'est pas bon !");
    }
    return "NULL";
  }

}