import javax.swing.*;
import java.awt.event.*;

/**
 * La classe <code>ItemListenerController</code> regarde l'état de la case pour
 * se souvenir.
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class ItemListenerController implements ItemListener {
  private int indicateur = 0;
  private JCheckBox check = new JCheckBox();

  public ItemListenerController(int indicateur, JCheckBox check) {
    this.indicateur = indicateur;
    this.check = check;
  }

  @Override
  public void itemStateChanged(ItemEvent e) {
  }

}
