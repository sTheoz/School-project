import javax.swing.*;
import java.awt.event.*;

/**
 * La classe <code>AddObjectToCartonControlleur</code> permet de réaliser
 * différentes actions lorsque l'utilisateur clique sur le bouton de connexion.
 * Le début du programme se fait ici, avec ce controlleur
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class AddObjectToCartonControlleur implements ActionListener {
  private ChangePieceVue closeme;
  private String nomObject;

  // Définition de la classe, on récupère les champs rempli par l'utilisateur
  // (Login,Password) mais aussi le résultat de la Checkbox
  public AddObjectToCartonControlleur(ChangePieceVue closeme, String nomObject) {
    this.closeme = closeme;
    this.nomObject = nomObject;
  }

  // Si l'utilisateur clique sur "Connexion" on réalise essaye de se connecter et
  // on analyse les résultats
  @Override
  public void actionPerformed(ActionEvent e) {
    this.closeme.dispose();
    JOptionPane.showMessageDialog(null, "Le carton : " + this.nomObject + " à bien été modifié", "Attention",
        JOptionPane.INFORMATION_MESSAGE);
  }

}