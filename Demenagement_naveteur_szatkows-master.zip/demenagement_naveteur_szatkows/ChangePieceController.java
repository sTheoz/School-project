import javax.swing.*;
import java.awt.event.*;

public class ChangePieceController implements ActionListener {
  private ChangePieceVue fen;
  private int connection = 0;
  private JComboBox liste;
  private String meuble;
  private boolean bool;

  /**
   * La classe <code>ChangePieceController</code> Permet à l'utilisateur de
   * modifier la pièce d'arrivée d'un meuble dans la base de donnée à partie de la
   * vue Logement
   * 
   * @version 1.0
   * @author Lucas NAVETEUR / Théo SZATKOWSKI
   */
  // Initie la fenetre principal, la liste des pièces,
  // le nom du meuble/carton, bool pour savoir si c'est un carton ou un meuble
  public ChangePieceController(ChangePieceVue fenetre, JComboBox liste, String meuble, boolean bool) {
    this.fen = fenetre;
    this.liste = liste;
    this.meuble = meuble;
    this.bool = bool;
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if (this.meuble == "I_AM_SCAN") {
      JOptionPane.showMessageDialog(null, "Le carton à bien été scanné !", "Attention",
          JOptionPane.INFORMATION_MESSAGE);
    }
    Model model = new Model();
    try {
      // bool==true alors c'est un meuble
      // Changement de pièce pour le meuble
      if (bool == true) {
        connection = model.updatePiece(meuble, model.ReadMymail(), liste.getSelectedItem().toString());
      }
      // bool==false alors c'est un carton
      // Changement de pièce pour le carton
      if (bool == false) {
        connection = model.updatePieceCarton(meuble, model.ReadMymail(), liste.getSelectedItem().toString());
      }
    } catch (NumberFormatException error) {
      JOptionPane.showMessageDialog(null, "Vous devez sélectionner une pièce dans la liste !", "Attention",
          JOptionPane.ERROR_MESSAGE);
    }
    // Si l'update a bien fonctionné alors on update les vues avec une intéraction
    // avec la Base de Donnée
    // Ferme ensuite la boîte de dialogue
    if (connection == 1) {
      fen.updateFen();
      fen.dispose();
      // If insertion réussie, on load la vue
    }
    // Lorsque l'on clique sur le bouton, on met à jour le JLabel
  }
}