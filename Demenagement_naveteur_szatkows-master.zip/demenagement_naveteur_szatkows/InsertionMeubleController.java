import javax.swing.*;
import java.awt.event.*;

/**
 * La classe <code>InsertionMeubleController</code> permet d'insérer des meubles
 * dans la base de donnée.
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class InsertionMeubleController implements ActionListener {
  private FenetreVue fen;
  private JComboBox arrivee;
  private JComboBox depart;
  private JTextField description;
  private JTextField nom;
  private JTextField prix;
  private JTextField largeur;
  private JTextField longueur;
  private JButton cheminFacture;
  private JButton cheminPhoto;
  private int connection = 0;

  // On obtient toutes les données des JTextField et autre
  public InsertionMeubleController(FenetreVue fenetre, JComboBox arrivee, JComboBox depart, JTextField description,
      JTextField nom, JTextField prix, JTextField largeur, JTextField longueur, JButton cheminFacture,
      JButton cheminPhoto) {
    fen = fenetre;
    this.nom = nom;
    this.prix = prix;
    this.largeur = largeur;
    this.longueur = longueur;
    this.depart = depart;
    this.arrivee = arrivee;
    this.description = description;
    this.cheminFacture = cheminFacture;
    this.cheminPhoto = cheminPhoto;
  }

  // Lorsque l'on clique sur ajouter, on effectue les opérations suivante
  @Override
  public void actionPerformed(ActionEvent e) {
    Model model = new Model();
    if (this.cheminFacture.getText() == "Sélectionner une facture" && Integer.parseInt(prix.getText()) >= 500) {
      JOptionPane.showMessageDialog(null, "La facture est obligatoire lorsque le prix est >= à 500 euros",
          "Insertion de meuble", JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    try {
      // On essaye d'insérer le meuble dans la BDD
      connection = model.Insertion_Meuble(this.nom.getText(), Integer.parseInt(prix.getText()),
          Integer.parseInt(largeur.getText()), Integer.parseInt(longueur.getText()),
          this.depart.getSelectedItem().toString(), this.arrivee.getSelectedItem().toString(),
          this.description.getText(), this.cheminFacture.getText(), this.cheminPhoto.getText(), model.ReadMymail());
      fen.updateAddMeuble();
    } catch (NumberFormatException error) {
      // Si on a cette erreur, c'est que l'utilisateur n'a pas bien rempli les champs
      // (Champs vide ou champs censé être int étant String)
      JOptionPane.showMessageDialog(null, "Vous devez remplir les champs obligatoire notés par '*' !", "Attention",
          JOptionPane.ERROR_MESSAGE);
      return;
    }
    if (connection == 1) {
      // On préviens l'utilisateur que le meuble à bien été rajouté
      JOptionPane.showMessageDialog(null, "Votre meuble à bien été rajouté !", "Insertion de meuble",
          JOptionPane.INFORMATION_MESSAGE);
    }
  }
}