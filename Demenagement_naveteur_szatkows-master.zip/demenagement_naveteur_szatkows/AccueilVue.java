import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.awt.event.*;
import java.util.*;
import javax.imageio.*;
import java.security.*;
import java.math.*;

/**
 * La classe <code>AccueilVue</code> est la toute première vue avec laquelle
 * l'utilisateur traite Cette vue lui permettra de se connecter à la base de
 * donnée et ainsi charger toutes les données correspondantes de son
 * déménagement
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class AccueilVue extends JFrame {
  // Si le fichier de sauvegarde existe, on peux charger le mail du fichier
  private boolean file_Exist = true;
  private String mailData;

  // Vue accueil pour que l'utilisateur puisse se connecter à l'application
  public AccueilVue() {
    super("Lucas NAVETEUR & Théo SZATKOWSKI");
    this.file_Exist = RememberMeExist();
    // Si le fichier existe, on read le mail
    if (RememberMeExist() == true) {
      ReadMymail();
    }
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(400, 200);
    JPanel main = new JPanel(new GridBagLayout());
    // -------------------- Création des différents boutons --------------------
    // Le mail de l'ulisateur
    JTextField mail = new JTextField(12);
    // On rempli le champ par le mail présent dans le fichier
    mail.setText(mailData);
    // Mot de passe de l'utilisateur
    JPasswordField password = new JPasswordField(12);

    // CheckBox pour savoir ce qu'on doit écrire dans le fichier mail.txt
    JCheckBox checkbox = new JCheckBox("Se souvenir de moi", null, true);
    checkbox.addItemListener(new ItemListenerController(2, checkbox));
    // Bouton pour lancer la requête pour se connecter
    JButton connect = new JButton("Connexion");
    connect.addActionListener(new AccueilController(1, mail, password, this, checkbox));
    password.addKeyListener(new EntreeController(mail, password, this, checkbox));
    mail.addKeyListener(new EntreeController(mail, password, this, checkbox));

    GridBagConstraints contrainte = new GridBagConstraints();
    // Initialisation des contraintes: 1ere case, 5 cases de larges et rempli tout
    // L'espace possible afin de prendre toute la largeur
    contrainte.gridx = 1;
    contrainte.gridy = 1;
    contrainte.gridheight = 1;
    contrainte.gridwidth = 5;
    // Pour remplir de couleur tout en longueur et en hauteur
    contrainte.fill = GridBagConstraints.BOTH;
    contrainte.weightx = 1.0;
    contrainte.weighty = 1.0;
    JLabel fondGris = new JLabel("Entreprise DeniService");
    fondGris.setHorizontalTextPosition(SwingConstants.CENTER);
    fondGris.setForeground(Color.WHITE);
    JPanel lepan = new JPanel();
    lepan.setBackground(Color.DARK_GRAY);
    lepan.add(fondGris);
    main.add(lepan, contrainte);

    // Reinitialisation de fill et de gridwidth
    contrainte.fill = GridBagConstraints.NONE;
    contrainte.gridwidth = 2;
    // 2e ligne
    contrainte.gridy = 2;
    main.add(new JLabel("mail"), contrainte);// Ajout du champ pour le mail
    contrainte.gridx = 3;// Pour mettre le champ à côté du mail
    main.add(mail, contrainte);
    // 3e ligne
    contrainte.gridy = 3;
    main.add(password, contrainte);// Ajout du champ pour le MDP
    contrainte.gridx = 1;// Pour mettre l'intitulé à côté du champ
    main.add(new JLabel("Password"), contrainte);
    contrainte.gridy = 4;
    contrainte.gridx = 2;
    main.add(checkbox, contrainte);
    // 4e ligne
    contrainte.gridy = 4;
    contrainte.gridx = 4;
    main.add(connect, contrainte);
    this.add(main);

    this.setResizable(false);
    // Permet de pas redimensionner la fenêtre
    // this.pack();//pour rendre la fenêtre la plus petite possible
    // this.setUndecorated(true); //Pratique ça enleve la barre en haut (nom,
    // reduction, fermeture)
    this.setLocationRelativeTo(null);
    this.setVisible(true);
  }

  // Si il existe un fichier de sauvegarde, on peut charger
  // Fonction pour voir si un fichier charger est disponible et faire apparaitre
  // ou non le bouton charger
  public boolean RememberMeExist() {
    File f = new File("mail.txt");
    if (f.exists() && !f.isDirectory()) {
      return true;
    } else {
      return false;
    }
  }

  // Lire le mail de l'utilisateur
  public void ReadMymail() {
    try {
      this.mailData = new String(Files.readAllBytes(Paths.get("mail.txt")));
    } catch (IOException e) {
      e.printStackTrace();
      JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
    }
  }

}
