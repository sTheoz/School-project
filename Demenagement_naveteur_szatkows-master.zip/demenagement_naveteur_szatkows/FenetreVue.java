import javax.swing.*;
import java.awt.*;
import java.io.*;

/**
 * La classe <code>FenetreVue</code> est le tout début du projet. L'utilisateur
 * voit cette vue en premier et peut naviguer de fenêtre en fenêtre grâce à
 * celle-ci
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class FenetreVue extends JFrame {

  private CardLayout gestionnaire;

  FenetreVue() {
    super("Lucas NAVETEUR & Théo SZATKOWSKI");
    // Création du CardLayout
    CardLayout gestio = new CardLayout();
    gestionnaire = gestio;
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(1080, 720);
    this.setMinimumSize(new Dimension(880, 520));
    this.setLocationRelativeTo(null);
    this.setLayout(gestionnaire);
    new BarreVue(this, gestionnaire);
    this.add(new CartonVue(this), "carton");
    this.add(new LogementsVue(this, gestionnaire), "liste");
    this.add(new InsertionMeubleVue(this), "declaration");
    this.add(new PlanPremiumVue(), "plan");
    voirInventaire();
    this.setVisible(true);
  }

  // Permet d'afficher la vue LogementVue
  public void voirInventaire() {
    gestionnaire.show(this.getContentPane(), "plan");
    gestionnaire.show(this.getContentPane(), "liste");
  }

  // Permet d'afficher la vue PlanPremiumVue
  public void updateFen() {
    this.add(new PlanPremiumVue(), "plan");
    this.add(new LogementsVue(this, gestionnaire), "liste");
    this.voirInventaire();
  }

  // Permet d'afficher la vue InsertionMeubleVue
  public void updateAddMeuble() {
    this.updateFen();
    gestionnaire.show(this.getContentPane(), "declaration");
  }

  // Permet d'afficher la vue InsertionCartonVue
  public void updateAddCarton() {
    this.updateFen();
    gestionnaire.show(this.getContentPane(), "carton");
  }

}
