import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.lang.Object;
import java.util.Arrays;

/**
 * La classe <code>MouseListenerController</code> permet de récupérer le meuble
 * afin de le dessiner plus tard
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class MouseListenerController implements MouseListener {
    private String contLabel;
    private JLabel label;
    private int j;
    private PlanPremiumVue vue;
    private Model model = new Model();
    private String[] longlarg = new String[2];
    private String piece;

    public MouseListenerController(JLabel label, PlanPremiumVue vue, String piece) {
        this.vue = vue;
        this.piece = piece;
        this.label = label;
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    // Permet de savoir quand on sélectionne un item dans la liste des meubles
    // Et récupère ses dimensions afin de plus tard le dessiner
    @Override
    public void mouseClicked(MouseEvent e) {
        vue.voirAncien().setOpaque(false);
        vue.voirAncien().updateUI();
        vue.voirAncien().setOpaque(false);
        label.setOpaque(true);
        vue.addNew(label, piece);
        vue.voirAncien().setBackground(Color.RED);
        vue.voirAncien().setOpaque(true);
        longlarg = model.getDimensionMeuble(model.ReadMymail(), (label.getText()).substring(3));
        vue.addDimension(Integer.parseInt(longlarg[0]), Integer.parseInt(longlarg[1]));
        this.label.updateUI();
    }
}