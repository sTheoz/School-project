import javax.swing.*;
import java.awt.event.*;
import java.nio.file.*;
import java.io.*;
import java.security.*;
import java.math.*;
import java.awt.Dimension;

/**
 * La classe <code>AccueilController</code> permet de réaliser différentes
 * actions lorsque l'utilisateur clique sur le bouton de connexion. Le début du
 * programme se fait ici, avec ce controlleur
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class AccueilController implements ActionListener {
  private int indicateur = 0;
  private JTextField mail;
  private JPasswordField password;
  private int connection = 0;
  private JFrame fen = new JFrame();
  private JCheckBox checkbox;

  // Définition de la classe, on récupère les champs rempli par l'utilisateur
  // (Login,Password) mais aussi le résultat de la Checkbox
  public AccueilController(int indicateur, JTextField mail, JPasswordField password, JFrame fen, JCheckBox checkbox) {
    this.indicateur = indicateur;
    this.mail = mail;
    this.password = password;
    this.fen = fen;
    this.checkbox = checkbox;
  }

  // Si l'utilisateur clique sur "Connexion" on réalise essaye de se connecter et
  // on analyse les résultats
  @Override
  public void actionPerformed(ActionEvent e) {
    if (this.indicateur == 1) {
      Model model = new Model();
      // On tente une connection à la base de donnée (Table D_Client) et on analyse le
      // résultat
      connection = model.Connection(this.mail.getText(), HashMe(String.valueOf(this.password.getPassword())));
      if (connection == 1) {
        if (this.checkbox.isSelected()) {
          // On écrit dans le fichier le mail de l'utilisateur
          WriteMymail(this.mail.getText());
        }
        // On ferme la fenêtre de login
        fen.dispose();
        // On réouvre la nouvelle fenêtre contenant les données de l'utilisateur
        new FenetreVue();
      } else {
        // L'utilisation de JOptionPane est, je trouve pratique. Ca permet aussi bien à
        // l'utilisateur et au programmeur de savoir ce qu'il c'est passé, le top est
        // d'y ajouter un System.err
        JOptionPane.showMessageDialog(null, "L'identifiant ou le mot de passe n'est pas correct", "Erreur de connexion",
            JOptionPane.ERROR_MESSAGE);
      }
    }
    // Lorsque l'on clique sur le bouton, on met à jour le JLabel
  }

  // Fonction permettant d'écrire le mail rentré dans le JTextField dans un
  // fichier appelé mail.txt en format UTF-8
  public boolean WriteMymail(String mail) {
    try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("mail.txt"), "utf-8"))) {
      writer.write(mail);
      writer.close();
      // FALSE = Rien n'a posé problème
      return false;
    } catch (IOException ex) {
      ex.printStackTrace();
      System.err.println("Erreur lors de l'écriture du fichier");
      // TRUE = Un problème à été detecté
      return true;
    }
  }

  // Fonction pour Hash le mot de passe de l'utilisateur et return le string de ce
  // hash
  public String HashMe(String password) {
    // On définit un Hash avec comme valeur une chaine NULL pour analyser la
    // possibilité de problèmes
    String hash = "NULL";
    try {
      // Etapes de hashage de mot de passe
      MessageDigest m = MessageDigest.getInstance("MD5");
      m.update(password.getBytes(), 0, password.length());
      hash = new BigInteger(1, m.digest()).toString(16);
      return hash;
    } catch (NoSuchAlgorithmException e) {
      System.err.println("L'algorithme rentré n'est pas bon !");
    }
    // Si NULL est retourné, le problème viens surement de l'étape de hashage
    return "NULL";
  }

}