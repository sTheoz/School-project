import java.awt.*;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 * La classe <code>Background</code> set à dessiner les meubles et redessiner le
 * plan de base
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class Background extends JPanel {
	public void paintComponent(Graphics g) {
		try {
			Image img = ImageIO.read(new File("win.png"));
			// On redessine le plan de base
			g.drawImage(img, 0, 0, this);
		} catch (IOException e) {
			System.err.println("Erreur" + e.getMessage());
		}

	}

}