import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/**
 * La classe <code>BarreController</code> est le controlleur du menu dans chaque
 * affichage du CardLayout en haut de la page, on peux navigeur entre les vues
 * grâce à ce controlleur et set les background de différente couleurs
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class BarreController implements ActionListener {
  private CardLayout gestio;
  private int item;
  private JFrame fen;
  private JMenuBar menu;
  private JMenuItem item2;
  private JMenuItem item3;
  private JMenuItem item4;

  public BarreController(int num, CardLayout gestionnaire, JFrame fenetre, JMenuItem item2, JMenuItem item3,
      JMenuItem item4) {
    this.item = num;
    this.gestio = gestionnaire;
    this.fen = fenetre;
    this.menu = menu;
    this.item2 = item2;
    this.item3 = item3;
    this.item4 = item4;
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if (item == 1) {
      // Si le choix est la liste des meubles et cartons (Donc LogementsVue)
      gestio.show(fen.getContentPane(), "liste");
      this.item2.setBackground(Color.red);
      this.item3.setBackground(Color.gray);
      this.item4.setBackground(Color.gray);
    }
    if (item == 2) {
      // Si le choix est la déclaration de valeur d'un meuble (Donc
      // InsertionMeubleVue)
      gestio.show(fen.getContentPane(), "declaration");
      this.item2.setBackground(Color.gray);
      this.item3.setBackground(Color.red);
      this.item4.setBackground(Color.gray);
    }
    // Si le choix est la déclaration de valeur d'un carton (Donc
    // InsertionCartonVue)
    if (item == 3) {
      gestio.show(fen.getContentPane(), "carton");
      this.item2.setBackground(Color.gray);
      this.item3.setBackground(Color.gray);
      this.item4.setBackground(Color.red);
    }
    // Si le choix est la vue du plan pour les utilisateurs premium (Donc
    // PlanPremiumVue)
    if (item == 4) {
      gestio.show(fen.getContentPane(), "plan");
    }
  }
}