import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.awt.event.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * La classe <code>CartonVue</code> est la fenêtre pour insérer un meuble/bien
 * C'est un formulaire afin d'insérer un meuble dans la base de donnée
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class CartonVue extends JPanel {

    private FenetreVue fen;

    public CartonVue(FenetreVue fenetre) {
        this.fen = fenetre;
        // On paramètre le layout de la fenêtre
        this.setLayout(new GridLayout(1, 1));
        JPanel main = new JPanel(new GridLayout(12, 2));
        JPanel marge = new JPanel(new GridLayout(1, 1));
        marge.setBorder(new EmptyBorder(40, 40, 40, 40));
        main.setBorder(BorderFactory.createLoweredBevelBorder());

        // -------------------- Création des différents meubles --------------------

        Model model = new Model();
        // Affichage dans liste déroulante des pièces que l'utilisateur possède
        JComboBox arrivee = new JComboBox();
        int piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Chambre");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Chambre " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Cuisine");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Cuisine " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Garage");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Garage " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Salle_Bain");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Salle_Bain " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Salle_Manger");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Salle_Manger " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Autre");
        for (int count = 1; count <= piecesArr; count++) {
            arrivee.addItem("Autre " + count);
        }
        // Affichage dans liste déroulante des pièces que l'utilisateur possède
        JComboBox depart = new JComboBox();
        int piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Chambre");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Chambre " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Cuisine");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Cuisine " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Garage");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Garage " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Salle_Bain");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Salle_Bain " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Salle_Manger");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Salle_Manger " + count);
        }
        piecesDep = model.getCountNumberOfPieces(model.ReadMymail(), 1, "Autre");
        for (int count = 1; count <= piecesDep; count++) {
            depart.addItem("Autre " + count);
        }
        // Les JTextField permettant de retrouver les informations
        JTextField description = new JTextField(50);
        JTextField prix = new JTextField(50);
        JTextField poids = new JTextField(50);
        JTextField largeur = new JTextField(50);
        JTextField longueur = new JTextField(50);
        JComboBox typeObjet = new JComboBox();
        // La liste des types d'objets
        typeObjet.addItem("Autre");
        typeObjet.addItem("Bijoux");
        typeObjet.addItem("Electroménager");
        typeObjet.addItem("Electronique");
        typeObjet.addItem("Equipement");
        typeObjet.addItem("Jouet");
        typeObjet.addItem("Livre");
        typeObjet.addItem("Machine");
        typeObjet.addItem("Mobilier");
        typeObjet.addItem("Vêtements");

        // On rajoute tout les JLabels paramétrés précèdement
        main.add(new JLabel("Description *"));
        main.add(new JLabel(" "));
        main.add(description);
        main.add(new JLabel(" "));
        main.add(new JLabel("Largeur *"));
        main.add(new JLabel("Longueur *"));
        main.add(largeur);
        main.add(longueur);
        main.add(new JLabel("Pièce de départ *"));
        main.add(new JLabel("Pièce d'arrivée *"));
        main.add(depart);
        main.add(arrivee);
        main.add(new JLabel("Type d'objet *"));
        main.add(new JLabel("Poids *"));
        main.add(typeObjet);
        main.add(poids);
        main.add(new JLabel(" "));
        // Ajout du bouton ajouter et listener dessus pour controler l'ajout à la BDD
        JPanel ajouter = new JPanel(new GridLayout(1, 3));
        JButton ajout = new JButton("Ajouter");
        ajout.addActionListener(
                new InsertionCartonController(fen, arrivee, depart, description, largeur, longueur, typeObjet, poids));
        ajouter.add(new JLabel(" "));
        ajouter.add(ajout);
        main.add(ajouter);
        marge.add(main);
        this.add(marge);

    }
}
