import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.filechooser.*;

/**
 * La classe <code>AddFileController</code> permet de controller les types de
 * fichiers et le contenu de ces même fichiers lorsque l'utilisateur veut
 * joindre une photo ou une facture du meuble rajouté via InsertionMeubleVue et
 * InsertionmeubleController
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class AddFileController implements ActionListener {
  // On récupère les données du bouton cliquer
  private JButton bout;
  // On récupère le chemin du fichier donné
  private String chemin;

  public AddFileController(JButton button, String chemin) {
    this.bout = button;
    this.chemin = chemin;
  }

  // Fonction paramétrant l'importation du fichier
  @Override
  public void actionPerformed(ActionEvent e) {
    JDialog choixFile = new JDialog();
    choixFile.setSize(500, 500);
    // Paramètre l'importation de fichier
    JFileChooser file = new JFileChooser();
    // On n'autorise que les fichiers avec les extensions définies ci-dessous
    FileFilter filefilter = new FileNameExtensionFilter("Images", "bmp", "gif", "jpg", "jpeg", "png", "pdf");
    // Utilise notre filtre d'extension comme actuel filtre
    file.setFileFilter(filefilter);
    // On ajoute le fichier
    choixFile.add(file);
    choixFile.setLocationRelativeTo(null);
    int status = file.showOpenDialog(null);
    choixFile.setVisible(true);
    // Si tout est OK on continue et on update l'affichage pour mettre le string du
    // chemin sur le bouton,sinon on ferme tout simplement la fenêtre
    if (status == JFileChooser.APPROVE_OPTION) {
      File selectedFile = file.getSelectedFile();
      bout.setText(selectedFile.getParent() + "/" + selectedFile.getName());
      bout.updateUI();
      choixFile.dispose();
    } else if (status == JFileChooser.CANCEL_OPTION) {
      choixFile.dispose();

    }

  }
}