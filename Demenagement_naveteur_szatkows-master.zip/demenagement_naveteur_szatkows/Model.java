import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
import java.nio.file.*;
import javax.imageio.*;

/**
 * La classe <code>Model</code> est la classe permettant de traiter avec la BDD
 * Insertion, Selection, Update, Suppression, tout se trouve ici pour pouvoir
 * faire ce que l'on veut avec les données de la BDD
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class Model {
	private Connection co;
	private String[][] tab_Logements;
	private String[][] tab_Meubles;
	private String[][] tab_Clients;
	private String[][] tab_Cartons;
	private int indice = 0;
	private int resultat = 0;
	private String[] piece_string;
	private boolean premium = false;

	public Model() {
		try {
			// javac *.java;java -cp "/export/documents/mariadb-client.jar:." Test
			Class.forName("org.mariadb.jdbc.Driver");
			try {
				this.co = DriverManager.getConnection("jdbc:mariadb://dwarves.arda/naveteur", "naveteur",
						"4uBbGAdJ0XATIPfa");
				try {
					PreparedStatement requete = co.prepareStatement("SELECT * FROM D_Clients");
					ResultSet res = requete.executeQuery();
					res.next();
				} catch (SQLException e) {
					System.err.println(e.getMessage());
					System.exit(3);
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.exit(2);
			}
		} catch (ClassNotFoundException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, "Vous n'avez pas ajouté mariadb à votre exécution", "Attention",
					JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}

	}

	// ----------------------------------------------------------------------------------------AFFICHAGE----------------------------------------------------------------------------------------

	// Permet d'obtenir TOUTES les informations sur un client avec son MAIL
	public String[][] getAllClientsWithMail(String mailArg) {
		int taille_tab = getCountUsersWithMail(mailArg);
		tab_Clients = new String[taille_tab][2];
		try {
			PreparedStatement statement = this.co.prepareStatement("SELECT * FROM D_Clients WHERE Mail=?");
			statement.setString(1, mailArg);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Clients[this.indice][0] = res2.getString("Mail");
				tab_Clients[this.indice][1] = res2.getString("Password");
			}
			return tab_Clients;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Clients;
	}

	// Permet de savoir si l'utilisateur est premium
	public boolean isPremium(String mailArg) {
		try {
			PreparedStatement statement = this.co.prepareStatement("SELECT isPremium FROM D_Clients WHERE Mail=?");
			statement.setString(1, mailArg);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				premium = res2.getBoolean("isPremium");
			}
			return premium;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return premium;
	}

	// Permet d'obtenir TOUTES les informations sur un client avec son MAIL
	public String[][] getAllLogementsWithIDClient(String mailArg) {
		int indice = 0;
		int taille_tab = getCountLogementsWithMail(mailArg);
		tab_Logements = new String[taille_tab][13];
		try {
			PreparedStatement statement = this.co.prepareStatement("SELECT * FROM D_Logements WHERE Mail=?");
			statement.setString(1, mailArg);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Logements[indice][0] = res2.getString("Mail");
				tab_Logements[indice][1] = res2.getString("Depart");
				tab_Logements[indice][2] = res2.getString("Ville");
				tab_Logements[indice][3] = res2.getString("Adresse");
				tab_Logements[indice][4] = res2.getString("Code_Postal");
				tab_Logements[indice][5] = res2.getString("Plan");
				tab_Logements[indice][6] = res2.getString("ID_Logement");
				tab_Logements[indice][7] = res2.getString("Chambre");
				tab_Logements[indice][8] = res2.getString("Cuisine");
				tab_Logements[indice][9] = res2.getString("Salle_Manger");
				tab_Logements[indice][10] = res2.getString("Garage");
				tab_Logements[indice][11] = res2.getString("Salle_Bain");
				tab_Logements[indice][12] = res2.getString("Autre");
				indice++;
			}
			return tab_Logements;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Logements;
	}

	// Permet d'obtenir tout les meubles avec le mail du client
	public String[][] getAllMeublesWithIDClient(String mailArg) {
		int indice = 0;
		int taille_tab = getCountMeublesWithMail(mailArg);
		tab_Meubles = new String[taille_tab][10];
		try {
			PreparedStatement statement = this.co.prepareStatement("SELECT * FROM D_Meubles WHERE Mail_Prop=?");
			statement.setString(1, mailArg);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Meubles[indice][0] = res2.getString("Nom");
				tab_Meubles[indice][1] = res2.getString("Prix");
				tab_Meubles[indice][2] = res2.getString("Largeur");
				tab_Meubles[indice][3] = res2.getString("Longueur");
				tab_Meubles[indice][4] = res2.getString("Piece_D");
				tab_Meubles[indice][5] = res2.getString("Piece_A");
				tab_Meubles[indice][6] = res2.getString("Description");
				tab_Meubles[indice][7] = res2.getString("Facture");
				tab_Meubles[indice][8] = res2.getString("Photo");
				tab_Meubles[indice][9] = res2.getString("Mail_Prop");
				indice++;
			}
			return tab_Meubles;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Meubles;
	}

	// Permet d'obtenir le compte des utilisateurs ayant le mail passé en argument
	public int getCountUsersWithMail(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Mail) AS count from D_Clients where Mail=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet d'obtenir le nom de la pièce d'arrivée ou est stocké un carton
	public String getPieceWithCarton(String nomCarton) {
		try {
			String piece2 = "NULL";
			PreparedStatement statement2 = this.co
					.prepareStatement("SELECT Piece_A from D_Cartons where Description=?");
			statement2.setString(1, nomCarton);
			ResultSet res3 = statement2.executeQuery();
			while (res3.next()) {
				piece2 = res3.getString("Piece_A");
			}
			return piece2;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return "NULL";
	}

	// Permet d'obtenir le compte des logements que possède un utilisateu
	public int getCountLogementsWithMail(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Mail) AS count from D_Logements where Mail=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet d'obtenir le compte des meubles que le client possède grâce à son mail
	public int getCountMeublesWithMail(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Mail_Prop) AS count from D_Meubles where Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet d'obtenir le compte des meubles que l'utilisateur possède sur son
	// logement d'arrivée
	public int getCountMeublesWithMailFromArrivee(String mail) {
		try {
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT count(Mail_Prop) AS count from D_Meubles where Mail_Prop=? AND Piece_A IS NOT NULL");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet d'obtenir le nombre de coord que l'utilisateur possède dans la table
	// du Plan
	public int getCountCoord(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Mail_Prop) AS count from D_Plan where Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Requête de test pour initier une connection
	public int Connection(String mail, String password) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Mail) AS count from D_Clients where Mail=? AND Password=?");
			statement.setString(1, mail);
			statement.setString(2, password);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet d'obtenir le nombre de meubles que possède l'utilisateur (Matériel car
	// reprit d'un ancien projet perso)
	public int getCountMyMateriel(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Nom) AS count from D_Meubles where Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// ---------------------------------PLAN------------------------------------
	// Donne les noms des pièces DISTINCT que possède X dans son logement d'arrivée
	public String[] getDistinctPiecesArrivee(String mail) {
		try {
			piece_string = new String[this.getCountDistinctPiecesArrivee(mail)];
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT DISTINCT Piece_A from D_Cartons where Piece_A in (SELECT Piece_A from D_Cartons where Mail_Prop=?) or Piece_A in (SELECT Piece_A from D_Meubles where Mail_Prop=?)");
			statement.setString(1, mail);
			statement.setString(2, mail);
			ResultSet res2 = statement.executeQuery();
			int count = 0;
			while (res2.next()) {
				piece_string[count] = res2.getString("Piece_A");
				count++;
			}
			return piece_string;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return piece_string;
	}

	// Obtenir tout les objets dans une pièce
	public String[] getObjectInPiece(String piece) {
		try {
			piece_string = new String[this.getCountObjectsInPiece(piece)];
			PreparedStatement statement = this.co.prepareStatement("SELECT NomObjet from D_Objets where Piece=?");
			statement.setString(1, piece);
			ResultSet res2 = statement.executeQuery();
			int count = 0;
			while (res2.next()) {
				piece_string[count] = res2.getString("NomObjet");
				count++;
			}
			return piece_string;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return piece_string;
	}

	// Obtenir distinctement toutes les pièces de départ
	public String[] getDistinctPiecesDepart(String mail) {
		try {
			piece_string = new String[this.getCountDistinctPiecesDepart(mail)];
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT DISTINCT Piece_D from D_Cartons where Piece_D in (SELECT Piece_D from D_Cartons where Mail_Prop=? and Piece_D IS NOT NULL) or Piece_D in (SELECT Piece_D from D_Meubles where Mail_Prop=? and Piece_D IS NOT NULL)");
			statement.setString(1, mail);
			statement.setString(2, mail);
			ResultSet res2 = statement.executeQuery();
			int count = 0;
			while (res2.next()) {
				piece_string[count] = res2.getString("Piece_D");
				count++;
			}
			return piece_string;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return piece_string;
	}

	// Donne le nombre de pièce que possède X dans son logement d'arrivée
	public int getCountDistinctPiecesArrivee(String mail) {
		try {
			int res = 0;
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT ID_Logement,Chambre,Cuisine,Salle_Manger,Garage,Salle_Bain,Autre from D_Logements where Mail=? AND Depart=0");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				res += res2.getInt("ID_Logement");
				res += res2.getInt("Chambre");
				res += res2.getInt("Cuisine");
				res += res2.getInt("Salle_Manger");
				res += res2.getInt("Garage");
				res += res2.getInt("Salle_Bain");
				res += res2.getInt("Autre");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 0;
	}

	// Donne le nombre de pièce que possède X dans son logement de départ
	public int getCountDistinctPiecesDepart(String mail) {
		try {
			int res = 0;
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT ID_Logement,Chambre,Cuisine,Salle_Manger,Garage,Salle_Bain,Autre from D_Logements where Mail=? AND Depart=1");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				res += res2.getInt("ID_Logement");
				res += res2.getInt("Chambre");
				res += res2.getInt("Cuisine");
				res += res2.getInt("Salle_Manger");
				res += res2.getInt("Garage");
				res += res2.getInt("Salle_Bain");
				res += res2.getInt("Autre");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 0;
	}

	// Donne le nombre de meuble par pièce(dep_arr) que possède X(mail) dans son
	// logement d'arrivée
	public int getCountMeubleByPieceDepart(String mail, String dep_arr) {
		try {
			int res = 0;
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT count(DISTINCT Nom) AS count from D_Meubles where Mail_Prop=? AND Piece_D=?");
			statement.setString(1, mail);
			statement.setString(2, dep_arr);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				res = res2.getInt("count");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 0;
	}

	// Permet d'obtenir le compte des meubles que l'utilisateur possède dans une
	// pièce d'arrivée
	public int getCountMeubleByPieceArrivee(String mail, String dep_arr) {
		try {
			int res = 0;
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT count(DISTINCT Nom) AS count from D_Meubles where Mail_Prop=? AND Piece_A=?");
			statement.setString(1, mail);
			statement.setString(2, dep_arr);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				res = res2.getInt("count");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 0;
	}

	// PlanPremiumVue : Afficher tous les meubles ayant un lien avec X pièce
	// d'arrivée
	public String[][] getAllMeublesWithPiece_A(String mail, String Piece) {
		int indice = 0;
		int taille_tab = getCountMeubleByPieceArrivee(mail, Piece);
		tab_Meubles = new String[taille_tab][10];
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT * FROM D_Meubles WHERE Mail_Prop=? AND Piece_A=?");
			statement.setString(1, mail);
			statement.setString(2, Piece);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Meubles[indice][0] = res2.getString("Nom");
				tab_Meubles[indice][1] = res2.getString("Prix");
				tab_Meubles[indice][2] = res2.getString("Largeur");
				tab_Meubles[indice][3] = res2.getString("Longueur");
				tab_Meubles[indice][4] = res2.getString("Piece_D");
				tab_Meubles[indice][5] = res2.getString("Piece_A");
				tab_Meubles[indice][6] = res2.getString("Description");
				tab_Meubles[indice][7] = res2.getString("Facture");
				tab_Meubles[indice][8] = res2.getString("Photo");
				tab_Meubles[indice][9] = res2.getString("Mail_Prop");
				indice++;
			}
			return tab_Meubles;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Meubles;
	}

	// PlanPremiumVue : Afficher tous les meubles ayant un lien avec X pièce de
	// départ
	public String[][] getAllMeublesWithPiece_D(String mail, String Piece) {
		int indice = 0;
		int taille_tab = getCountMeubleByPieceDepart(mail, Piece);
		tab_Meubles = new String[taille_tab][10];

		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT * FROM D_Meubles WHERE Mail_Prop=? AND Piece_D=?");
			statement.setString(1, mail);
			statement.setString(2, Piece);

			ResultSet res2 = statement.executeQuery();
			try {
				while (res2.next()) {
					tab_Meubles[indice][0] = res2.getString("Nom");
					tab_Meubles[indice][1] = res2.getString("Prix");
					tab_Meubles[indice][2] = res2.getString("Largeur");
					tab_Meubles[indice][3] = res2.getString("Longueur");
					tab_Meubles[indice][4] = res2.getString("Piece_D");
					tab_Meubles[indice][5] = res2.getString("Piece_A");
					tab_Meubles[indice][6] = res2.getString("Description");
					tab_Meubles[indice][7] = res2.getString("Facture");
					tab_Meubles[indice][8] = res2.getString("Photo");
					tab_Meubles[indice][9] = res2.getString("Mail_Prop");
					indice++;
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				JOptionPane.showMessageDialog(null, "Deux meubles ont le même nom dans la base de donnée !",
						"Nous avions prévu cela... mais trop tard", JOptionPane.ERROR_MESSAGE);
			}

			return tab_Meubles;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Meubles;
	}

	// Permet d'obtenir toutes les coordonées d'un client pour dessiner le plan
	public String[][] getAllCoord(String mail) {
		int indice = 0;
		int taille_tab = getCountCoord(mail);
		String[][] tab_Coords = new String[taille_tab][10];
		try {
			PreparedStatement statement = this.co.prepareStatement("SELECT * FROM D_Plan WHERE Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Coords[indice][0] = res2.getString("Nom");
				tab_Coords[indice][1] = res2.getString("CoordX");
				tab_Coords[indice][2] = res2.getString("CoordY");
				tab_Coords[indice][3] = res2.getString("Largeur");
				tab_Coords[indice][4] = res2.getString("Longueur");
				indice++;
			}
			return tab_Coords;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Coords;
	}

	// ----------------------------------------------------------------------------------------INSERTION----------------------------------------------------------------------------------------
	// InsertionMeubleVue : Insertion du matériel dans la BDD
	public int Insertion_Meuble(String Nom, int Prix, int Largeur, int hauteur, String Piece_D, String Piece_A,
			String Description, String Facture, String Photo, String Mail_Prop) {
		try {
			PreparedStatement statement = this.co.prepareStatement(
					"INSERT INTO D_Meubles(Nom,Prix,Largeur,Longueur,Piece_D,Piece_A,Description,Facture,Photo,Mail_Prop) VALUES(?,?,?,?,?,?,?,?,?,?)");
			statement.setString(1, Nom);
			statement.setInt(2, Prix);
			statement.setInt(3, Largeur);
			statement.setInt(4, hauteur);
			statement.setString(5, Piece_D);
			statement.setString(6, Piece_A);
			statement.setString(7, Description);
			statement.setString(8, Facture);
			statement.setString(9, Photo);
			statement.setString(10, Mail_Prop);
			statement.executeUpdate();
			// ou : statement.execute();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			return 0;
		}
		return 1;
	}

	// ATTENTION, IL FAUT FERMER LES SESSIONS LORS DES MODIFICATIONS
	public String ReadMymail() {
		try {
			String mailData = new String(Files.readAllBytes(Paths.get("mail.txt")));
			return mailData;
		} catch (IOException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return "NULL";
	}

	// InsertionMeubleVue : Insertion du matériel dans la BDD
	public int Insertion_Carton(int Largeur, int hauteur, String Piece_D, String Piece_A, String Description,
			String typeObjet, int poids, String Mail_Prop) {
		try {
			PreparedStatement statement = this.co.prepareStatement(
					"INSERT INTO D_Cartons(Description,Largeur,Longueur,Poids,Piece_D,Piece_A,TypeObjet,Mail_Prop) VALUES(?,?,?,?,?,?,?,?)");
			statement.setString(1, Description);
			statement.setInt(2, Largeur);
			statement.setInt(3, hauteur);
			statement.setInt(4, poids);
			statement.setString(5, Piece_D);
			statement.setString(6, Piece_A);
			statement.setString(7, typeObjet);
			statement.setString(8, Mail_Prop);
			statement.executeUpdate();
			// ou : statement.execute();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			return 0;
		}
		return 1;
	}
	// ATTENTION, IL FAUT FERMER LES SESSIONS LORS DES MODIFICATIONS

	// -----------------------------------------------------------------CARTONS---------------------------------------------------------------------------------

	public String[][] getAllCartonsWithIDClient(String mailArg) {
		int indice = 0;
		int taille_tab = getCountCartonsWithMail(mailArg);
		tab_Cartons = new String[taille_tab][8];
		try {
			PreparedStatement statement = this.co.prepareStatement("SELECT * FROM D_Cartons WHERE Mail_Prop=?");
			statement.setString(1, mailArg);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Cartons[indice][0] = res2.getString("Description");
				tab_Cartons[indice][1] = res2.getString("Largeur");
				tab_Cartons[indice][2] = res2.getString("Longueur");
				tab_Cartons[indice][3] = res2.getString("Poids");
				tab_Cartons[indice][4] = res2.getString("Piece_D");
				tab_Cartons[indice][5] = res2.getString("Piece_A");
				tab_Cartons[indice][6] = res2.getString("TypeObjet");
				tab_Cartons[indice][7] = res2.getString("Mail_Prop");
				indice++;
			}
			return tab_Cartons;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Cartons;
	}

	// PlanPremiumVue : Afficher tous les meubles ayant un lien avec X pièce
	// d'arrivée
	public String[][] getAllCartonsWithPiece_A(String mail, String Piece) {
		int indice = 0;
		int taille_tab = getCountCartonByPieceArrivee(mail, Piece);
		tab_Cartons = new String[taille_tab][8];
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT * FROM D_Cartons WHERE Mail_Prop=? AND Piece_A=?");
			statement.setString(1, mail);
			statement.setString(2, Piece);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Cartons[indice][0] = res2.getString("Description");
				tab_Cartons[indice][1] = res2.getString("Largeur");
				tab_Cartons[indice][2] = res2.getString("Longueur");
				tab_Cartons[indice][3] = res2.getString("Poids");
				tab_Cartons[indice][4] = res2.getString("Piece_D");
				tab_Cartons[indice][5] = res2.getString("Piece_A");
				tab_Cartons[indice][6] = res2.getString("TypeObjet");
				tab_Cartons[indice][7] = res2.getString("Mail_Prop");
				indice++;
			}
			return tab_Cartons;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Cartons;
	}

	// PlanPremiumVue : Afficher tous les meubles ayant un lien avec X pièce de
	// départ
	public String[][] getAllCartonsWithPiece_D(String mail, String piece) {
		int indice = 0;
		int taille_tab = getCountCartonsByPieceDepart(mail, piece);
		tab_Cartons = new String[taille_tab][8];
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT * FROM D_Cartons WHERE Mail_Prop=? AND Piece_D=?");
			statement.setString(1, mail);
			statement.setString(2, piece);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Cartons[indice][0] = res2.getString("Description");
				tab_Cartons[indice][1] = res2.getString("Largeur");
				tab_Cartons[indice][2] = res2.getString("Longueur");
				tab_Cartons[indice][3] = res2.getString("Poids");
				tab_Cartons[indice][4] = res2.getString("Piece_D");
				tab_Cartons[indice][5] = res2.getString("Piece_A");
				tab_Cartons[indice][6] = res2.getString("TypeObjet");
				tab_Cartons[indice][7] = res2.getString("Mail_Prop");
				indice++;
			}
			return tab_Cartons;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Cartons;
	}

	// Permet de compter le nombre de carton présent dans la pièce d'arrivée
	public int getCountCartonByPieceArrivee(String mail, String dep_arr) {
		try {
			int res = 0;
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT count(Description) AS count from D_Cartons where Mail_Prop=? AND Piece_A=?");
			statement.setString(1, mail);
			statement.setString(2, dep_arr);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				res = res2.getInt("count");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 0;
	}

	// Donne le nombre de meuble par pièce(dep_arr) que possède X(mail) dans son
	// logement d'arrivée
	public int getCountCartonsByPieceDepart(String mail, String dep_arr) {
		try {
			int res = 0;
			PreparedStatement statement = this.co.prepareStatement(
					"SELECT count(DISTINCT Description) AS count from D_Cartons where Mail_Prop=? AND Piece_D=?");
			statement.setString(1, mail);
			statement.setString(2, dep_arr);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				res = res2.getInt("count");
			}
			return res;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 0;
	}

	// Permet de compter le nombre de cartons de l'utilisateur
	public int getCountMyCartons(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Description) AS count from D_Cartons where Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet de compter le nombre de cartons de l'utilisateur seconde version ou on
	// compte le mail
	public int getCountCartonsWithMail(String mail) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Mail_Prop) AS count from D_Cartons where Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Compte le nombre d'objets dans la pièce
	public int getCountObjectsInPiece(String piece) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(NomObjet) AS count from D_Objets where Piece=?");
			statement.setString(1, piece);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Compte le nombre de pièces dans le logement de départ ou d'arrivée
	public int getCountNumberOfPieces(String mail, int depart, String nompiece) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT " + nompiece + " AS count from D_Logements where Mail=? AND Depart=?");
			statement.setString(1, mail);
			statement.setInt(2, depart);
			ResultSet res2 = statement.executeQuery();
			res2.next();
			resultat = Integer.parseInt(res2.getString("count"));
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Permet d'obtenir les dimension d'un meuble
	public String[] getDimensionMeuble(String mail, String nom) {
		try {
			piece_string = new String[2];
			PreparedStatement statement = this.co
					.prepareStatement("SELECT Largeur,Longueur from D_Meubles where Mail_Prop=? AND Nom=?");
			statement.setString(1, mail);
			statement.setString(2, nom);
			ResultSet res2 = statement.executeQuery();
			res2.next();
			piece_string[0] = res2.getString("Largeur");
			piece_string[1] = res2.getString("Longueur");
			return piece_string;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return piece_string;
	}

	// Compte le nombre de meubles dans le plan
	public int getCountMeublePlan(String mail, String nompiece) {
		int resultat = 0;
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT count(Nom) AS count from D_Plan where Mail_Prop=?");
			statement.setString(1, mail);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				resultat = res2.getInt("count");
			}
			return resultat;
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
		}
		return 1;
	}

	// Obtenir toutes les informations du plan
	public String[][] getAllFromPlan(String mail, String nom) {
		int indice = 0;
		int taille_tab = getCountMeublePlan(mail, nom);
		tab_Cartons = new String[taille_tab][6];
		try {
			PreparedStatement statement = this.co
					.prepareStatement("SELECT * FROM D_Cartons WHERE Mail_Prop=? AND Nom=?");
			statement.setString(1, mail);
			statement.setString(2, nom);
			ResultSet res2 = statement.executeQuery();
			while (res2.next()) {
				tab_Cartons[indice][0] = res2.getString("Nom");
				tab_Cartons[indice][1] = res2.getString("Mail_Prop");
				tab_Cartons[indice][2] = res2.getString("CoordX");
				tab_Cartons[indice][3] = res2.getString("CoordY");
				tab_Cartons[indice][4] = res2.getString("Longueur");
				tab_Cartons[indice][5] = res2.getString("Largeur");
				indice++;
			}
			return tab_Cartons;
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			System.exit(4);
		}
		// echec
		return tab_Cartons;
	}

	// Changer les informations d'une pièce
	public int updatePiece(String meuble, String mail, String nompiece) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("UPDATE D_Meubles set Piece_A=? where Mail_Prop=? AND Nom=?");
			statement.setString(1, nompiece);
			statement.setString(2, mail);
			statement.setString(3, meuble);
			ResultSet res2 = statement.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			return 0;
		}
		return 1;
	}

	// Changer les information d'un carton d'une pièce
	public int updatePieceCarton(String meuble, String mail, String nompiece) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("UPDATE D_Cartons set Piece_A=? where Mail_Prop=? AND Description=?");
			statement.setString(1, nompiece);
			statement.setString(2, mail);
			statement.setString(3, meuble);
			ResultSet res2 = statement.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			return 0;
		}
		return 1;
	}

	// Changer les coordonées d'un meuble du plan
	public int updateCoordPlan(String Nom, String Mail_Prop, int CoordX, int CoordY, int longueur, int largeur) {
		try {
			PreparedStatement statement = this.co
					.prepareStatement("UPDATE D_Plan set CoordX=?,CoordY=? where Nom=? AND Mail_Prop=?");
			statement.setInt(1, CoordX);
			statement.setInt(2, CoordY);
			statement.setString(3, Nom);
			statement.setString(4, Mail_Prop);
			statement.executeUpdate();
		} catch (SQLException e) {
			Insertion_MeublePlan(Nom, Mail_Prop, CoordX, CoordY, longueur, largeur);
		}
		return 1;
	}

	// Inserer les coordonées d'un meuble que l'on dessine
	public int Insertion_MeublePlan(String Nom, String Mail_Prop, int CoordX, int CoordY, int Longueur, int Largeur) {
		try {
			PreparedStatement statement = this.co.prepareStatement(
					"INSERT INTO D_Plan(Nom,Mail_Prop,CoordX,CoordY,Longueur,Largeur) VALUES(?,?,?,?,?,?)");
			statement.setString(1, Nom);
			statement.setString(2, Mail_Prop);
			statement.setInt(3, CoordX);
			statement.setInt(4, CoordY);
			statement.setInt(5, Longueur);
			statement.setInt(6, Largeur);
			statement.executeUpdate();
			// ou : statement.execute();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			JOptionPane.showMessageDialog(null, e.getMessage(), "Attention", JOptionPane.ERROR_MESSAGE);
			return 0;
		}
		return 1;
	}
}
