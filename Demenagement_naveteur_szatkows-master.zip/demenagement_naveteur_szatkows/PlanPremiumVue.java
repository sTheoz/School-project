import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.awt.event.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * La classe <code>PlanPremiumVue</code> est la fenetre d'affichage du plan du
 * logement d'arrivée pour les clients premium
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class PlanPremiumVue extends JPanel {
    private String url = "plan2.jpg";
    private String mail;
    private int i = 0, j = 0;
    private Model database = new Model();
    private String tab2[];
    private String tab3[][];
    private JLabel previousLabel = new JLabel();
    private String previousPiece = "";
    private int largeur;
    private int longueur;

    // Configuration de la vue
    public PlanPremiumVue() {
        this.setLayout(new GridLayout(1, 1));
        JPanel main = new JPanel(new GridBagLayout());
        JPanel marge = new JPanel(new GridLayout(1, 1));
        marge.setBorder(new EmptyBorder(40, 40, 40, 40));
        main.setBorder(BorderFactory.createLoweredBevelBorder());
        DessinerPlanVue plan = new DessinerPlanVue(url);
        DrawObjet objetDessin = new DrawObjet(this, plan);
        DessinerController objet = new DessinerController(objetDessin);

        plan.addMouseListener(objet);
        GridBagConstraints contrainte = new GridBagConstraints();
        contrainte.gridx = 0;
        contrainte.gridy = 0;
        contrainte.gridwidth = 1;
        contrainte.gridheight = 1;
        contrainte.fill = GridBagConstraints.BOTH;
        contrainte.weighty = 1.0;
        contrainte.weightx = 1.0;
        // On ajoute le plan + l'endroit où on dessinera (sur le plan)
        main.add(plan, contrainte);
        main.add(objetDessin, contrainte);
        // On ajoute le panel pour la liste des cartons et des meubles
        contrainte.gridx = 2;
        contrainte.gridwidth = 1;
        contrainte.gridheight = 2;
        contrainte.weighty = 0.0;
        contrainte.weightx = 0.20;
        JPanel liste = new JPanel(new GridLayout(database.getCountMyMateriel(database.ReadMymail())
                + database.getCountDistinctPiecesArrivee(database.ReadMymail()), 1));
        tab2 = database.getDistinctPiecesArrivee(database.ReadMymail());
        for (i = 0; i < tab2.length; i++) {
            if (tab2[i] != null) {
                liste.add(new JLabel(tab2[i]));
                tab3 = database.getAllMeublesWithPiece_A(database.ReadMymail(), tab2[i]);
                for (j = 0; j < tab3.length; j++) {
                    JLabel label = new JLabel("---" + tab3[j][0]);
                    label.addMouseListener(new MouseListenerController(label, this, tab2[i]));
                    liste.add(label);
                }
            }
        }
        liste.setBorder(BorderFactory.createLineBorder(Color.black));
        main.add(liste, contrainte);

        // SI IL N'Y A PAS DE CARTON DANS UN PIECE, JE N'AFFICHE PAS LA PIECE

        // Model database = new Model();
        JPanel ajouter = new JPanel();
        JButton planComplet = new JButton("Voir le plan complet");
        ajouter.add(planComplet);

        planComplet.addActionListener(new FullPlanController());
        // Listener
        contrainte.gridy = 1;
        contrainte.weightx = 0.00;
        main.add(ajouter, contrainte);
        marge.add(main);
        this.add(marge);

    }

    // Renvoie l'ancien JLabel sélectionné
    public JLabel voirAncien() {
        return previousLabel;
    }

    // Renvoie la pièce du meuble
    public String voirPiece() {
        return previousPiece;
    }

    // Remplace l'ancien JLabel et ajoute un nouveau JLabel (objet selectionné)
    public void addNew(JLabel lab, String piece) {
        this.previousLabel = lab;
        this.previousPiece = piece;
    }

    // Ajoute les dimensions du meuble selectionné
    public void addDimension(int x, int y) {
        this.largeur = x;
        this.longueur = y;
    }

    // Renvoie la largeur du meuble selectionné
    public int getLargeur() {
        return this.largeur;
    }

    // Renvoie la longueur du meuble selectionné
    public int getLongueur() {
        return this.longueur;
    }
}
