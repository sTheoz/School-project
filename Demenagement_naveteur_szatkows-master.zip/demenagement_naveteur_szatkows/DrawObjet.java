import javax.swing.*;
import java.awt.*;

/**
 * La classe <code>DrawObjet</code> permet de dessiner
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class DrawObjet extends JPanel {

    private int x = 0;
    private int y = 0;
    private Color color;
    private PlanPremiumVue meuble;
    private DessinerPlanVue plan;
    private int largeur;
    private int longueur;
    private int compteur = 0;
    private Model model = new Model();
    private int numPiece;

    // Initialisation de la vue PlanPremiumVue, de la vue DessinerPlanVue et de la
    // couleur
    public DrawObjet(PlanPremiumVue meuble, DessinerPlanVue plan) {
        super();
        this.color = new Color(20, 20, 20);
        this.meuble = meuble;
        this.plan = plan;
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics pinceau = g.create();
        if (meuble.voirAncien().getText() == "") {
            // Condition pour dire qu'il faut sélectionner un meuble
            if (compteur == 1) {
                JOptionPane.showMessageDialog(null, "Vous devez sélectionner un meuble dans la liste !",
                        "Pas de meuble sélectionné", JOptionPane.ERROR_MESSAGE);
            }
            compteur++;
        } else {
            compteur++;
            // Condition pour nettoyer le plan pour un clic sur deux
            if (compteur > 2) {
                plan.repaint();
                compteur = 1;
            } else {
                // Dessiner les contours de la pièce de l'objet
                pinceau.setColor(Color.RED);
                if (numPiece == 1)
                    pinceau.drawRect(41, 26, 226 - 41, 155 - 26);
                if (numPiece == 2)
                    pinceau.drawRect(41, 345, 226 - 41, 488 - 345);
                if (numPiece == 3)
                    pinceau.drawRect(472, 26, 656 - 472, 229 - 26);
                if (numPiece == 4)
                    pinceau.drawRect(472, 345, 657 - 472, 487 - 345);
                if (numPiece == 5)
                    pinceau.drawRect(232, 345, 467 - 232, 487 - 345);
                if (numPiece == 6)
                    pinceau.drawRect(472, 235, 657 - 472, 341 - 235);
                if (numPiece == 7)
                    pinceau.drawRect(41, 159, 466 - 41, 340 - 159);

                // Dessiner l'objet sélectionné
                largeur = meuble.getLargeur() / 3;
                longueur = meuble.getLongueur() / 3;
                pinceau.setColor(Color.ORANGE);
                pinceau.fillRect(x, y, largeur, longueur);
                pinceau.setColor(Color.BLACK);
                pinceau.drawString(meuble.voirAncien().getText().substring(3), x, y + longueur / 2);
                // Mise à jour des coordonnées des objets
                model.updateCoordPlan(meuble.voirAncien().getText().substring(3), model.ReadMymail(), x, y, longueur,
                        largeur);
                // model.Insertion_MeublePlan(meuble.voirAncien().getText().substring(3),model.ReadMymail(),x,y,longueur,largeur);
            }

        }
    }

    // Mise A Jour des coordonées X et Y de l'objet et redessine
    public void miseAJour(int x, int y) {
        String piece = meuble.voirPiece();
        largeur = meuble.getLargeur() / 3;
        longueur = meuble.getLongueur() / 3;
        this.x = x;
        this.y = y;
        // Limité l'objet à sa pièce
        if (piece.equals("Chambre 1")) {// 1
            numPiece = 1;
            if (this.x < 41)
                this.x = 41;
            if (this.x > 226 - this.largeur)
                this.x = 226 - this.largeur;
            if (this.y < 26)
                this.y = 26;
            if (this.y > 155 - this.longueur)
                this.y = 155 - this.longueur;
        }
        if (piece.equals("Chambre 2")) {// 2
            numPiece = 2;
            if (this.x < 41)
                this.x = 41;
            if (this.x > 226 - this.largeur)
                this.x = 226 - this.largeur;
            if (this.y < 345)
                this.y = 345;
            if (this.y > 488 - this.longueur)
                this.y = 488 - this.longueur;
        }
        if (piece.equals("Cuisine 1")) {// 3
            numPiece = 3;
            if (this.x < 472)
                this.x = 472;
            if (this.x > 656 - this.largeur)
                this.x = 656 - this.largeur;
            if (this.y < 26)
                this.y = 26;
            if (this.y > 229 - this.longueur)
                this.y = 229 - this.longueur;
        }
        if (piece.equals("Garage 1")) {// 4
            numPiece = 4;
            if (this.x < 472)
                this.x = 472;
            if (this.x > 657 - this.largeur)
                this.x = 657 - this.largeur;
            if (this.y < 345)
                this.y = 345;
            if (this.y > 487 - this.longueur)
                this.y = 487 - this.longueur;
        }
        if (piece.equals("Salle_Bain 1")) {// 5
            numPiece = 5;
            if (this.x < 232)
                this.x = 232;
            if (this.x > 467 - this.largeur)
                this.x = 467 - this.largeur;
            if (this.y < 345)
                this.y = 345;
            if (this.y > 487 - this.longueur)
                this.y = 487 - this.longueur;
        }
        if (piece.equals("Autre 1")) {// 6
            numPiece = 6;
            if (this.x < 472)
                this.x = 472;
            if (this.x > 657 - this.largeur)
                this.x = 657 - this.largeur;
            if (this.y < 235)
                this.y = 235;
            if (this.y > 341 - this.longueur)
                this.y = 341 - this.longueur;
        }
        if (piece.equals("Salle_Manger 1")) {// 7
            numPiece = 7;
            if (this.x < 41)
                this.x = 41;
            if (this.x > 466 - this.largeur)
                this.x = 466 - this.largeur;
            if (this.y < 159)
                this.y = 159;
            if (this.y > 340 - this.longueur)
                this.y = 340 - this.longueur;
        }
        this.repaint();
    }
}
