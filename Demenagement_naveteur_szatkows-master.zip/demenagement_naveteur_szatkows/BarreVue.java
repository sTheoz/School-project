import javax.swing.*;
import java.awt.*;

/**
 * La classe <code>BarreVue</code> est la vue de la barre grâce à laquelle on
 * peux naviguer entre les différentes cards du cardLayout
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class BarreVue extends JFrame {
        // La fenêtre et ses informations
        private JFrame fenetre;
        private CardLayout gestio;

        public BarreVue(JFrame fen, CardLayout gestio) {
                this.fenetre = fen;
                this.gestio = gestio;
                JMenuBar menu_bar1 = new JMenuBar();
                /* differents choix de chaque menu */
                JMenuItem listes = new JMenuItem("Vos logements");
                JMenuItem declaration = new JMenuItem("Déclaration de valeur pour meuble");
                JMenuItem carton = new JMenuItem("Insertion de carton");
                listes.setBackground(Color.red);
                declaration.setBackground(Color.gray);
                carton.setBackground(Color.gray);
                /* Ajout de composants aux conteneurs */
                menu_bar1.add(listes);
                menu_bar1.add(declaration);
                menu_bar1.add(carton);
                listes.addActionListener(new BarreController(1, gestio, fenetre, listes, declaration, carton));
                declaration.addActionListener(new BarreController(2, gestio, fenetre, listes, declaration, carton));
                carton.addActionListener(new BarreController(3, gestio, fenetre, listes, declaration, carton));
                /* Ajouter la bar du menu à la frame */
                fen.setJMenuBar(menu_bar1);
        }
}
