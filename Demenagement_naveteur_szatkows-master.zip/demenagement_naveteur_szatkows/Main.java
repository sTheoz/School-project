import javax.swing.*;
import java.awt.*;
import java.io.*;

/**
 * La classe <code>Main</code> est le tout début du projet Elle lance une
 * fenetre... c'est tout, c'est la classe de cette fenêtre nommée AccueilVue qui
 * se chargera du reste des opérations !
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */

public class Main {

  public static void main(String[] args) {
    // Lancons la fenêtre !
    AccueilVue fenetre = new AccueilVue();
  }
}