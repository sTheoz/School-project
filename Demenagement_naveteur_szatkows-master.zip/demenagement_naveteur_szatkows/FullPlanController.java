import java.awt.event.*;

/**
 * La classe <code>FullPlanController</code> permet de redraw le plan
 * complètement
 *
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class FullPlanController implements ActionListener {

  public FullPlanController() {
    super();
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    new PlanComplet();
  }

}