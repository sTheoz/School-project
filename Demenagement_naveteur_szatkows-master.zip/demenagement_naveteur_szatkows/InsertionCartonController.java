import javax.swing.*;
import java.awt.event.*;

/**
 * La classe <code>InsertionCartonController</code> permet d'insérer des cartons
 * dans la base de donnée.
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class InsertionCartonController implements ActionListener {
  // Fenêtre
  private FenetreVue fen;
  private JComboBox arrivee;
  private JComboBox depart;
  private JTextField description;
  private JTextField largeur;
  private JTextField longueur;
  private JComboBox typeObjet;
  private JTextField poids;
  private int connection = 0;

  // On obtient toutes les données des JTextField et autre
  public InsertionCartonController(FenetreVue fenetre, JComboBox arrivee, JComboBox depart, JTextField description,
      JTextField largeur, JTextField longueur, JComboBox typeObjet, JTextField poids) {
    fen = fenetre;
    this.largeur = largeur;
    this.longueur = longueur;
    this.depart = depart;
    this.arrivee = arrivee;
    this.description = description;
    this.typeObjet = typeObjet;
    this.poids = poids;
  }

  // Lorsque l'on clique sur ajouter, on effectue les opérations suivante
  @Override
  public void actionPerformed(ActionEvent e) {
    Model model = new Model();
    try {
      // On essaye d'insérer le carton dans la BDD
      connection = model.Insertion_Carton(Integer.parseInt(largeur.getText()), Integer.parseInt(longueur.getText()),
          depart.getSelectedItem().toString(), arrivee.getSelectedItem().toString(), this.description.getText(),
          typeObjet.getSelectedItem().toString(), Integer.parseInt(this.poids.getText()), model.ReadMymail());
      fen.updateAddCarton();
    } catch (NumberFormatException error) {
      // Si on a cette erreur, c'est que l'utilisateur n'a pas bien rempli les champs
      // (Champs vide ou champs censé être int étant String)
      JOptionPane.showMessageDialog(null, "Vous devez remplir les champs obligatoire notés par '*' !", "Attention",
          JOptionPane.ERROR_MESSAGE);
    }
    if (connection == 1) {
      // On préviens l'utilisateur que le carton à bien été rajouté
      JOptionPane.showMessageDialog(null, "Votre carton à bien été rajouté !", "Insertion de meuble",
          JOptionPane.INFORMATION_MESSAGE);
    }
  }
}