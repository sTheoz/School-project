import java.awt.*;
import javax.swing.*;
import java.io.File;

/**
 * La classe <code>ChangePieceVue</code> est une vue permettant à l'utilisateur
 * de changer un meuble de pièce d'arrivée avec une liste déroulante et un
 * bouton de validation
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class ChangePieceVue extends JDialog {

    private String meuble;
    private FenetreVue parent;
    private boolean bool;

    public ChangePieceVue(FenetreVue parent, String titre, boolean modal, String meuble, boolean bool) {
        super(parent, titre, modal);
        this.bool = bool;
        this.meuble = meuble;
        this.parent = parent;
        this.setSize(330, 150);
        this.setUndecorated(true);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addContenu();
        this.setVisible(true);
    }

    public void addContenu() {
        Model model = new Model();
        // Menu et layout
        JPanel panMenu;
        if (this.bool == false) {
            panMenu = new JPanel(new GridLayout(5, 2));
            //
            JComboBox objets = new JComboBox();
            String[] objetinpiece = model.getObjectInPiece(model.getPieceWithCarton(this.meuble).substring(0,
                    model.getPieceWithCarton(this.meuble).indexOf(" ")));
            for (int count = 0; count < model.getCountObjectsInPiece(model.getPieceWithCarton(this.meuble).substring(0,
                    model.getPieceWithCarton(this.meuble).indexOf(" "))); count++) {
                objets.addItem(objetinpiece[count]);
            }
            // Obtenir tous les items de la pièce
            // GetNumberOfItem in 1 pièce
            // ---getCountObjectsInPiece
            // GetItemsInPiece - getCountObjectsInPiece
            String nompiece = model.getPieceWithCarton(this.meuble);
            JButton addObject = new JButton("Ajouter l'objet au carton");
            panMenu.add(objets);
            panMenu.add(addObject);
            panMenu.setBorder(BorderFactory.createTitledBorder("Changement de pièce ou ajout d'objet ?"));
            addObject.addActionListener(new AddObjectToCartonControlleur(this, this.meuble));
        } else {
            panMenu = new JPanel(new GridLayout(3, 2));
            panMenu.setBorder(BorderFactory.createTitledBorder("Dans quelle pièce voulez-vous mettre l'objet ?"));
        }
        panMenu.setBackground(Color.white);
        // Liste déroulante des pièces possibles
        JComboBox pieces = new JComboBox();
        int piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Chambre");
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Autre");
        for (int count = 1; count <= piecesArr; count++) {
            pieces.addItem("Autre " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Chambre");
        for (int count = 1; count <= piecesArr; count++) {
            pieces.addItem("Chambre " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Cuisine");
        for (int count = 1; count <= piecesArr; count++) {
            pieces.addItem("Cuisine " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Garage");
        for (int count = 1; count <= piecesArr; count++) {
            pieces.addItem("Garage " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Salle_Bain");
        for (int count = 1; count <= piecesArr; count++) {
            pieces.addItem("Salle_Bain " + count);
        }
        piecesArr = model.getCountNumberOfPieces(model.ReadMymail(), 0, "Salle_Manger");
        for (int count = 1; count <= piecesArr; count++) {
            pieces.addItem("Salle_Manger " + count);
        }
        panMenu.add(pieces);
        // Bouton de validation
        JButton okBouton = new JButton("VALIDER");
        panMenu.add(okBouton);
        if(bool == false){
            JButton scan = new JButton("SCANNER");
            panMenu.add(scan);
            scan.addActionListener(new ChangePieceController(this, pieces, "I_AM_SCAN", bool));           
        }
        this.add(panMenu);
        
        okBouton.addActionListener(new ChangePieceController(this, pieces, meuble, bool));

    }

    public void updateFen() {
        // On ferme la fenêtre de changement pour réaffichier l'ancienne avec les
        // nouvelles informations
        this.dispose();
        parent.updateFen();
    }
}