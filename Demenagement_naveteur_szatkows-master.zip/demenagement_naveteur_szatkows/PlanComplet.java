import java.awt.*;
import javax.swing.*;
import java.io.File;

/**
 * La classe <code>PlanCompler</code> est une vue permettant à l'utilisateur de
 * voir tous ses meubles positionnés
 * 
 * @version 1.0
 * @author Lucas NAVETEUR / Théo SZATKOWSKI
 */
public class PlanComplet extends JDialog {

    /**
     * Les meubles se dessinent tous derrière le plan donc pour montrer que les
     * meubles se dessinent tous nous avons enlevé l'ajout du plan dans le panel
     */

    private String url = "plan2.jpg";
    private String tab[][];

    public PlanComplet() {
        super();
        this.setLayout(new GridLayout(1, 1));
        this.setSize(730, 550);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.addContenu();
        this.setVisible(true);
    }

    public void addContenu() {
        Model model = new Model();
        JPanel main = new JPanel(new GridBagLayout());

        GridBagConstraints contrainte = new GridBagConstraints();
        contrainte.gridx = 0;
        contrainte.gridy = 0;
        contrainte.gridwidth = 1;
        contrainte.gridheight = 1;
        contrainte.fill = GridBagConstraints.BOTH;
        contrainte.weighty = 1.0;
        contrainte.weightx = 1.0;

        DessinerPlanVue plan = new DessinerPlanVue(url);
        int number = model.getCountCoord(model.ReadMymail());
        tab = new String[number][4];
        tab = model.getAllCoord(model.ReadMymail());
        // main.add(plan,contrainte);
        for (int i = 0; i < number; i++) {
            // System.out.println(i+" oui :
            // "+tab[i][0]+Integer.parseInt(tab[i][1])+Integer.parseInt(tab[i][2])+Integer.parseInt(tab[i][3])+Integer.parseInt(tab[i][4]));
            DessinerObjet p = new DessinerObjet(tab[i][0], Integer.parseInt(tab[i][1]), Integer.parseInt(tab[i][2]),
                    Integer.parseInt(tab[i][3]), Integer.parseInt(tab[i][4]));
            main.add(p, contrainte);
        }
        this.add(main);

    }

    /*
     * public void visible(){ this.setVisible(true); for (int i = 0; i < number;
     * i++) {
     * //System.out.println(i+" oui : "+tab[i][0]+Integer.parseInt(tab[i][1])+
     * Integer.parseInt(tab[i][2])+Integer.parseInt(tab[i][3])+Integer.parseInt(tab[
     * i][4])); DessinerObjet p = new
     * DessinerObjet(tab[i][0],Integer.parseInt(tab[i][1]),Integer.parseInt(tab[i][2
     * ]),Integer.parseInt(tab[i][3]),Integer.parseInt(tab[i][4]));
     * panel.add(p,contrainte); } panel.updateUI(); }
     */
}