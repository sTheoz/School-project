# no-sql

## A faire avant de lancer :
sudo sysctl -w vm.max_map_count=262144
