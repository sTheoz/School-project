from neo4j import GraphDatabase

def inject_neo4j(df, data):
    pass