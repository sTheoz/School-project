import java.awt.*;
import java.io.*;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
*
* La classe Panneau permet d'afficher un fond d'écran et une image lors du menu
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Panneau extends JPanel{

		/**
		*Invoqué automatiquement lorsque l'on appel la classe
		*@param g le pinceau pour dessiner
		*/
	  public void paintComponent(Graphics g){
		    try {
		    	Image img = ImageIO.read(new File("Images/demineur.jpg"));
		    	Image img2 = ImageIO.read(new File("Images/fond.jpg"));		    	
		    	
		    	g.drawImage(img2, 0, 0, this);
		    	g.drawImage(img, this.getWidth()-350, this.getHeight()-200, this);		    	
		    }catch(IOException e) {
		    	System.err.println("Erreur" + e.getMessage());		    	
		    }
		    
	  }

}