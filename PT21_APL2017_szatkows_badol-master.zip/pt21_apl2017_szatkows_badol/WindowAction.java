import java.awt.event.*;
import java.io.*;

/**
*
* La classe WindowAction a pour but de sauvegarder la partie lorsque la fenêtre est fermée ou quand celle-ci est appelée
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class WindowAction implements WindowListener {
	private Fenetre fenetre;
	private int colonne;
	private int ligne;
	private Cases[] tableauB;
	private int[] tableauI;

/**
* Permet l'écoute de la fenêtre et initialisation des objets dont on a besoin
* @param fen La fênetre à désactiver
* @param tableauI Le tableau à sauvegarder 
* @param colonne Le nombre de colonnes de la grille
* @param ligne Le nombre de lignes de la grille
* @param tableauB Le tableau de Cases pour détecter si les cases sont ouvertes
*/

	public WindowAction(Fenetre fen, int[] tableauI, int colonne,int ligne, Cases[] tableauB) {
		super();
		this.colonne=colonne;
		this.ligne=ligne;
		this.fenetre=fen;
		this.tableauI=tableauI;
		this.tableauB=tableauB;
	}

	/**
	*Pas de réécriture
	*@param evenement WindowEvent invoqué
	*/
	public void windowActivated(WindowEvent evenement) {}      // premier plan
	/**
	*Pas de réécriture
	*@param evenement WindowEvent invoqué
	*/
	public void windowClosed(WindowEvent evenement) {}         // après fermeture
	/**
	*Permet de sauvegarder la grille
	*@param evenement WindowEvent invoqué
	*/
	public void windowClosing(WindowEvent evenement) {
		int compteur=0;
		try {
			File supprime = new File("save.dat");
			supprime.delete();
			FileOutputStream fichier = new FileOutputStream("save.dat");
			DataOutputStream flux = new DataOutputStream(fichier);
			flux.writeInt(colonne);
			flux.writeInt(ligne);
			int longueur= colonne*ligne;
			for(int i=0;i<longueur;i++){
				flux.writeInt(tableauI[i]);
				if(tableauI[i]==-1){
					compteur++;
					
				}
			}
			flux.writeInt(compteur);
			for(int i=0 ; i<longueur; i++){
				if(tableauB[i].detect() && tableauI[i]!=-1){
					flux.writeInt(1);
				}else{
					flux.writeInt(0);
				}
			}
			

			flux.close();
		} catch (FileNotFoundException e1) {
			System.err.println("Erreur pas de fichier");
		} catch (IOException e2) {
			System.err.println("Erreur pas de fichier");
		}
		fenetre.dispose();

	} // avant fermeture
	/**
	*Pas de réécriture
	*@param evenement WindowEvent invoqué
	*/
	public void windowDeactivated(WindowEvent evenement){}   // arrière-plan
	/**
	*Pas de réécriture
	*@param evenement WindowEvent invoqué
	*/
	public void windowDeiconified(WindowEvent evenement){}    // restauration
	/**
	*Pas de réécriture
	*@param evenement WindowEvent invoqué
	*/
	public void windowIconified(WindowEvent evenement){}      // minimisation
	/**
	*Pas de réécriture
	*@param evenement WindowEvent invoqué
	*/
	public void windowOpened(WindowEvent evenement){}         // après ouverture
}