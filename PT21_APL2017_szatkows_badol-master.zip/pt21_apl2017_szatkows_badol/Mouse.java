import java.awt.event.*;

/**
*
* La classe Mouse a pour but de détecter les clics droit ou les clics gauche
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Mouse implements MouseListener{

		private Cases cases;

	public Mouse(Cases caseNum){
		super();
		this.cases=caseNum;
	}	
		/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/
	public void mouseClicked(MouseEvent evenement){
	}

	/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/

	public void mouseExited(MouseEvent evenement){
	}

/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/
	public void mouseEntered(MouseEvent evenement){

	} 

	/**
		*Lorsque un bouton de la souris est pressé.
		*@param evenement MouseEvent invoqué
		*/	      
	public void mousePressed(MouseEvent evenement){
		int bouton = evenement.getButton();
		if(bouton == MouseEvent.BUTTON1){
			/*Bouton gauche*/
			cases.change();
		}else 
		if(bouton == MouseEvent.BUTTON3){
			/*Bouton droit*/
			cases.clicDroit();
		}
	} 

	/**
		*Pas de réécriture
		*@param evenement MouseEvent invoqué
		*/      
	public void mouseReleased(MouseEvent evenement){

	}
	}
