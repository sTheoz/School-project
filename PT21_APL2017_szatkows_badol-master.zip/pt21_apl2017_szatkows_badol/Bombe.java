
import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;

/**
*
* La classe Bombe correpond aux bombes du démineur
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Bombe extends JPanel implements Cases {

    private Color c=Color.GRAY;
    private JLabel num;
    private int droit;
    private Fenetre fenetre;
    private Demineur demineur;
    private boolean ouvert=false;


    public Bombe(Demineur demineur,String nom, Fenetre fenetre) {
        super();
        this.demineur=demineur;
        this.fenetre=fenetre;
	   Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
	   int height = (int)screen.getHeight();
        this.setPreferredSize(new Dimension(height/36,height/36));
        this.getBorder();
        this.setBorder(new javax.swing.border.BevelBorder(BevelBorder.RAISED));
        this.setLayout(new GridLayout(1,0));
        JLabel name = new JLabel("\uD83D\uDCA3");
        num=name;
        num.setForeground(Color.GRAY);
        this.setBackground(c);
        num.setVerticalAlignment(JLabel.CENTER);
        
        this.add(num);
}
 /**
 *
 *Decouvre la case
 */
    public void change(){
        if(droit == 0){
            this.removeAll();
            this.setBackground(Color.RED);
            this.num.setForeground(Color.BLACK);
            this.add(num);
            this.updateUI();
            ouvert=true;
            demineur.afficheBombe();
            new FinDePartie(fenetre,"Fin du game",true);
        }
    }
 /**
 *
 *Renvoie la valeur si la case est ouverte ou non
 */
    public boolean detect(){
        return ouvert;
    };
 /**
 *
 *Affiche une étoile, un '?' ou rien 
 *L'étoile bloque la découverte de la case
 */
    public void clicDroit(){
        droit++;
        droit=droit%3;
        if(droit == 0){
            this.removeAll();
            this.c=Color.GRAY;
            this.setBackground(c);
            this.updateUI();
        }else if (droit == 1){
           this.removeAll();
           JLabel etoile = new JLabel("\u2605",JLabel.CENTER);
           etoile.setForeground(Color.BLACK);
           this.add(etoile);
           this.updateUI();
           fenetre.decremente();
        }else{
            this.removeAll();
            JLabel interrogation = new JLabel("?",JLabel.CENTER);
            interrogation.setForeground(Color.BLACK);
            this.add(interrogation);
            this.updateUI();
            fenetre.incremente();
        }
    }
 /**
 *
 *Decouvre la case lors de la fin de partie
 */
    public void fond(){
        if(droit==1){
            this.removeAll();
            this.add(num);
            this.setBackground(Color.GREEN);
        }else if(droit==0 && detect()){
            this.removeAll();
            this.add(num);
            this.setBackground(Color.RED);
        }else{
            this.removeAll();
            this.add(num);
            this.setBackground(Color.WHITE);
        }
    }
}
