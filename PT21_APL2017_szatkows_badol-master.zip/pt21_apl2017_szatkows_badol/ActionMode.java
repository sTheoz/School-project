import java.awt.event.*;
import java.io.*;
/**
 * 
 * La classe 
 * @version 0.1
 * @author Théo Szatkowski Jérémie Badol
 */
public class ActionMode implements ActionListener{
	private Choix choix;
	private int rep;
	public ActionMode(Choix choix, int rep){
		super();
		this.choix=choix;
		this.rep=rep;
	}
 /**
 *
 *Initialise la partie avec les colonnes,lignes,bombes
 *@param arg0 ActionEvent invoqué automatiquement
 */
	public void actionPerformed(ActionEvent arg0){
		if(rep==0){
			choix.colonne =  Integer.parseInt(choix.bc.getText());
			choix.ligne =  Integer.parseInt(choix.bl.getText());
			choix.bombe = Integer.parseInt(choix.nbbombe.getText());
			choix.dispose();
			Fenetre f = new Fenetre(true);
			if(choix.bombe>=choix.ligne*choix.colonne){
		 		new FinDePartie(f,"Trop de bombes par rapport à la grille",true);
			}else if(choix.colonne<4 || choix.ligne<4 || choix.colonne>30 || choix.ligne>30){
				new FinDePartie(f,"Dimension comprise entre 4x4 et 30x30",true);
			}else{
		 		f.initialisation(choix.bombe,choix.ligne,choix.colonne);
		 		f.setVisible(true);
		 	}
		}else if(rep==1){
		 	choix.dispose();
		    Menu f = new Menu();
		  	f.setVisible(true);
		}		
	} 

}