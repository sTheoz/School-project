import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.File;

/**
*
* La classe Menu peut commencer une partie, continuer une partie si un fichier de sauvegarde existe
* et peut quitter l'application
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Menu extends JFrame {
	private int rep;
	private JButton commencer = new JButton("Commencer");
	private JButton continuer = new JButton("Continuer");
	private JButton quitter = new JButton("Quitter");
	
	public Menu() {
		this.setTitle("Menu");
		this.setSize(500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		Panneau image =  new Panneau();
		this.setContentPane(image);
		JPanel pane = new JPanel();
		
		GridLayout grille = new GridLayout(3,1);
		grille.setVgap(75);
		pane.setLayout(grille);
		

		
		pane.add(commencer);
      	File fichier = new File("save.dat");
      	if(fichier.exists()){
			pane.add(continuer);
        }
		pane.add(quitter);
		pane.setOpaque(false);
		this.add(pane);
		
		
		
		this.setVisible(true);
		commencer.addActionListener(new ActionCommencer(this,0));
		continuer.addActionListener(new ActionCommencer(this,2));
		quitter.addActionListener(new ActionCommencer(this,1));
	}
}
