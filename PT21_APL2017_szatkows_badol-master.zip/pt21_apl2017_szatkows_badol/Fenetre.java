import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;

/**
*
* La classe Fenetre est le coeur du demineur, elle lance la fenêtre du jeu 
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Fenetre extends JFrame{

	private int bombe=100; /*Nombre de bombre que le joueur veut dans sa grille*/
	private int colonne;
	private int ligne;
	private boolean reponse;
	private Compteur compteur;


/*Continuer ou commencer
Commencer = false 
Continuer = true*/
	public Fenetre(boolean reponse){
		super("Demineur");
		this.reponse=reponse;
		if(!reponse){
			
			try{
			FileInputStream fichier = new FileInputStream("save.dat");
			DataInputStream flux = new DataInputStream(fichier);
			colonne=flux.readInt();
			ligne=flux.readInt();
			jouer();
			}catch(FileNotFoundException e3){
				System.err.println("FileNotFoundException");
			}catch(IOException e2){
				System.err.println("IOException");
			}		
		}
	}

 /**
 *
 *Permet de lancer le jeu
 */
	public void jouer(){
		this.setLocation(0,0);
		this.setResizable(false);
		
		
		if(reponse){
			File sauvegarde = new File("save.dat");
			sauvegarde.delete();
		}
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int height = (int)screen.getHeight();      		
		JPanel demin = new JPanel(new GridLayout(ligne,colonne));
		Cases[] tableauB = new Cases[colonne*ligne];
		this.setLayout(new BorderLayout());
		JPanel panel = new JPanel(new GridLayout(2,1));
		JPanel sauvegarder = new JPanel();
		JButton sauv = new JButton("SAUVEGARDE ET QUITTER");
		sauvegarder.add(sauv);


		panel.add(sauvegarder);

		JPanel compteur = new JPanel();
		Compteur c = new Compteur(bombe,compteur);
		compteur.add(c);
		compteur.setBorder(new javax.swing.border.SoftBevelBorder(BevelBorder.LOWERED));
		panel.add(compteur);

		this.add(panel,BorderLayout.NORTH);
		this.compteur=c;
		
		new Demineur(ligne,colonne,tableauB,bombe,this,demin,sauv);
		this.add(demin,BorderLayout.SOUTH);
		pack();
		
	}
 /**
 *
 *Initialisation des paramètres colonne,ligne,bombe
 *@param nbrBombe Initialise le nombre de bombe
 *@param ligne Initialise le nombre de ligne
 *@param colonne Initialise le nombre de colonne
 */
	public void initialisation(int nbrBombe,int ligne, int colonne){
		this.ligne=ligne;
		this.colonne=colonne;
		this.bombe=nbrBombe;
		this.jouer();
	}
 /**
 *
 *Augmente le compteur de 1
 */
	public void incremente(){
		compteur.incremente();
	}
	 /**
 *
 *Diminue le compteur de 1
 */
	public void decremente(){
		compteur.decremente();
	}
/**
 *
 *Initialisation du compteur quand on reprend une partie
 *@param newbombe le nombre de bombe de l'ancienne partie
 */
	public void compteurInit(int newbombe){
		while(newbombe>bombe){
			bombe++;
			compteur.incremente();
		}
		while(newbombe<bombe){
			bombe--;
			compteur.decremente();
		}
	}
}
