import java.awt.event.*;

/**
*
* La classe SauveQuitter permet de lancer le protocole de sauvegarde qui se trouve dans WindowAction
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class SauveQuitter implements ActionListener{

	private Fenetre fenetre;
	private int colonne;
	private int ligne;
	private Cases[] tableauB;
	private int[] tableauI;

	/**
	*Permet le lancement de la sauvegarde
	*@param fene La fenêtre à désactiver
	*@param tableauI Le tableau à sauvegarder
	*@param colonne Le nombre de colonnes de la grille
	*@param ligne Le nombre de lignes de la grille
	*@param tableauB Le tableau de Cases pour savoir si les cases sont ouvertes
	*/
	public SauveQuitter(Fenetre fene,int[] tableauI, int colonne,int ligne, Cases[] tableauB){
	super();
	this.fenetre=fene;
	this.colonne=colonne;
	this.ligne=ligne;
	this.tableauI=tableauI;
	this.tableauB=tableauB;
		}
		/**
		*Invoqué automatiquement lorsque l'on clic sur le bouton
		*@param arg0 invoqué lors du clic sur le bouton
		*/
		public void actionPerformed(ActionEvent arg0) {        
	       WindowAction act = new WindowAction(fenetre,tableauI,colonne,ligne,tableauB);
	       act.windowClosing(new WindowEvent(fenetre,WindowEvent.WINDOW_CLOSING));
	      }	
	}