import javax.swing.*;
import java.util.Random;
import java.io.*;

/**
*
* La classe Demineur comprend le jeu en lui même et comprend toutes les données importantes du jeu
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Demineur{

	private Cases[] tableauB=null;
	private int reste;
	private int bombe;
	private int nbrBB=0; /*Nombre de bombe déposé sur la grille*/
	private Incremente incr;
	private int colonne;
	private int ligne;
	private int[] tableauI=null;
	private Fenetre fenetre;
	private JPanel demine;

	public Demineur(int ligne, int colonne, Cases[] tableauB,int bomb, Fenetre fenetre, JPanel demin, JButton sauv){
	super();
	this.demine=demin;
	this.fenetre=fenetre;
	this.ligne=ligne;
	this.colonne=colonne;
	this.tableauB=tableauB;
	this.bombe=bomb;
	
	
	int totCas=ligne*colonne;
	reste=totCas;
		tableauI=new int[totCas];
		try{
			/*Lire le fichier de sauvegarde*/
			FileInputStream fichier = new FileInputStream("save.dat");
			DataInputStream flux = new DataInputStream(fichier);
			colonne = flux.readInt();
			ligne= flux.readInt();
			totCas=ligne*colonne;
			reste=totCas;
			for(int i=0;i<totCas;i++){
				tableauI[i]=flux.readInt();
			}
			/*Remplir tableauB*/
			this.bombe=flux.readInt();
			fenetre.compteurInit(this.bombe);
			for(int i=0;i<totCas;i++){
				if(tableauI[i]!=-1){
					if(tableauI[i]==0){
					CasNor d = new CasNor(this,"",fenetre);
					this.demine.add(d);
					d.addMouseListener(new Mouse(d));
					tableauB[i]=d;

					}else{
					CasNor d = new CasNor(this,""+tableauI[i],fenetre);
					this.demine.add(d);
					d.addMouseListener(new Mouse(d));
					tableauB[i]=d;
				}
				}else{
					Bombe b = new Bombe(this,"Bombe",fenetre);
					this.demine.add(b);
					b.addMouseListener(new Mouse(b));
					tableauB[i]=b;
				}
			}

			for(int i = 0; i<totCas; i++){
				if(flux.readInt()==1 && tableauI[i]!=-1 && !tableauB[i].detect()){
					tableauB[i].change();
				}
			}
			try{
			fenetre.addWindowListener(new WindowAction(fenetre,tableauI,colonne,ligne,tableauB));
		}catch(NullPointerException e1){
			System.err.println("Je suis bug");
		}
		flux.close();
		}catch(FileNotFoundException e2){
		Incremente incre=new Incremente(tableauI,colonne);
		incr=incre;

		try{
			for(int i=0;nbrBB<bombe;i++){
				Random rand=new Random();
        		int tempo=rand.nextInt(totCas); /*Numéro aléatoire pour pouvoir mettre au hasard les bombes*/
        		if(tempo<bombe){ /*5 chance sur 25 ici pour avoir 5 bombes sur les 25 cases */
					if(tableauI[i]!=-1){						
						nbrBB=nbrBB+1;
						tableauI[i]=-1;


					/*Incrémentation des cases aux alentours*/
					/*Pour la première ligne*/
					if(i/colonne==0){
						if(i%colonne==colonne-1){/*Dernière colonne*/
							incr.pLDC(i);
						}
						else if(i%colonne==0){/*Première colonne*/
							incr.pLPC(i);
						}else{/*Entre les deux*/
							incr.pLA(i);
						}
					}else
					/*Dernière ligne*/
					if(i/colonne==ligne-1){
						if(i%colonne==colonne-1){/*Dernière colonne*/
							incr.dLDC(i);
						}
						else if(i%colonne==0){/*Première colonne*/
							incr.dLPC(i);
						}else{/*Entre les deux*/
							incr.dLA(i);
						}
					}else{
						if(i%colonne==colonne-1){/*Dernière colonne*/
							incr.aDC(i);
						}
						else if(i%colonne==0){/*Première colonne*/
							incr.aPC(i);
						}else{/*Entre les deux*/
							incr.aA(i);
						}
					}
				}
			}
				if(i==totCas-1){
					i=0;
				}
			}
			for(int i=0;i<totCas;i++){
				if(tableauI[i]!=-1){
					if(tableauI[i]==0){
						CasNor d = new CasNor(this,"",fenetre);
						this.demine.add(d);
						d.addMouseListener(new Mouse(d));
						tableauB[i]=d;
				}else{
					CasNor d = new CasNor(this,""+tableauI[i],fenetre);
					this.demine.add(d);
					d.addMouseListener(new Mouse(d));
					tableauB[i]=d;
				}
				}else{
					Bombe b = new Bombe(this,"Bombe",fenetre);
					this.demine.add(b);
					b.addMouseListener(new Mouse(b));
					tableauB[i]=b;
				}
			}			
			}catch(NoSuchMethodError e){
			System.err.println("NoSuchMethodError");	
		}catch(NullPointerException e1){
			System.err.println("nullPointerException");
		}
		try{
			fenetre.addWindowListener(new WindowAction(fenetre,tableauI,colonne,ligne,tableauB));
		}catch(NullPointerException e1){
			System.err.println("Je suis bug");
		}
	}catch(IOException e3){
			System.err.println("IOException");
		}
		sauv.addActionListener(new SauveQuitter(fenetre,tableauI,colonne,ligne,tableauB));
}
 /**
 *
 *Decouvre toute les cases autour d'une case vide
 *@param explose La case qui est appuyé
 */
			public void ouvrir(Cases explose){
				int i;
				if(reste == bombe){
					this.afficheBombe();
					new FinDePartie(fenetre,"Bravo vous avez gagne !",true);
				}else{
				for(i=0;tableauB[i]!=explose;i++){
					/*Je cherche ma case dans le tableau*/
				}


				if(tableauI[i]==0){
					if(i%colonne!=0){
					try{
						if(!tableauB[i-1].detect()){
							tableauB[i-1].change();
						}
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
			if(i%colonne!=colonne-1){
				try{
						if(!tableauB[i+1].detect()){
							tableauB[i+1].change();
						}
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
						try{
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
				if(i%colonne!=0){
				try{
						if(!tableauB[i-1+colonne].detect()){
							tableauB[i-1+colonne].change();
						}

						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
			if((i%colonne)!=(colonne-1)){
				try{
						if(!tableauB[i+1+colonne].detect()){
							tableauB[i+1+colonne].change();
						}
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
				if((i%colonne)!=0){
				try{
						if(!tableauB[i-1-colonne].detect()){
							tableauB[i-1-colonne].change();
						}
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
			if((i%colonne)!=(colonne-1)){
				try{
						if(!tableauB[i+1-colonne].detect()){
							tableauB[i+1-colonne].change();
						}
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
				try{
						if(!tableauB[i+colonne].detect()){
							tableauB[i+colonne].change();
						}
						}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
				try{
						if(!tableauB[i-colonne].detect()){
							tableauB[i-colonne].change();
						}
					}catch(ArrayIndexOutOfBoundsException e){/*Volontaire pour simplifier le code et ne pas faire beaucoup de conditions*/
				}
			}
		}
	}
 /**
 *
 *Diminue le reste de 1
 */
		public void decremente(){
		reste--;
	}
 /**
 *
 *Fonction de fin de partie qui découvre toute les cases
 */
  	public void afficheBombe(){

  		for(int i = 0; i<ligne*colonne;i++){
  			tableauB[i].fond();
  		}
   	

   }

}