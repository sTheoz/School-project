import java.awt.event.*;
import java.io.*;

/**
*
* La classe 
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class ActionFin implements ActionListener{

	private FinDePartie fin;

	public ActionFin(FinDePartie fin){
	super();
	this.fin=fin;
		}
 /**
 *
 *Recommencer une partie ou fermer toutes les fenêtres
 *@param arg0 ActionEvent invoqué automatiquement
 */
		public void actionPerformed(ActionEvent arg0) {        
	        fin.rep=fin.getReponse();
	        fin.setVisible(false);

	        File sauvegarde = new File("save.dat");
   			sauvegarde.delete();

	        if(fin.rep == 0){
	        	/*Fonction pour commencer la partie*/
	        	fin.mere.dispose();
	        	fin.dispose();
	        	Choix f = new Choix();
	        	f.setVisible(true);
	        }else if(fin.rep == 1){
	        	fin.mere.dispose();
	        	fin.dispose();
	        	/*Fermer toutes les fenêtres*/
	        }
	      }	
	}