import java.awt.event.*;
import java.io.*;
/**
 * 
 * La classe Mouse a pour but de détecter les clics droit ou les clics gauche
 * @version 0.1
 * @author Théo Szatkowski Jérémie Badol
 */

public class ActionCommencer implements ActionListener{
	private Menu menu;
	private int rep;

	public ActionCommencer(Menu menu, int rep){
		super();
		this.menu=menu;
		this.rep=rep;
	}		
	/**
   * Permet d'initialiser les variables ou de quitter l'application
   * @param arg0 ActionEvent invoqué automatiquement
   */   
	public void actionPerformed(ActionEvent arg0) {        
	    if(rep == 0){
	        menu.dispose();
	        Choix f = new Choix();
	        f.setVisible(true);
	    }else if(rep == 1){
	        menu.dispose();
	        	
	    }else if(rep==2){
	    	menu.dispose();
	    	File sauvegarde = new File("save.dat");
	        if(!sauvegarde.exists()){
	        	Choix f = new Choix();
	        	f.setVisible(true);
	        }else{
	        	Fenetre f = new Fenetre(false);
	        	f.setVisible(true);
	        }
	    }
	}
}
