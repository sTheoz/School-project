/**
*
* La classe Main permet de lancer l'application
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Main {
  public static void main(String[] args) {
  	new Menu();
 }
}