/**
*
* L'interface Cases est la classe principale qui comprend les cases normales et les bombes
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public interface Cases {

	 public void change();
	 public boolean detect();
	 public void clicDroit();
	 public void fond();
}