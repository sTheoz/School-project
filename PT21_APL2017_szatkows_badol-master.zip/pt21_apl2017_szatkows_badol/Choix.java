import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
*
* La classe Choix a pour but de choisir le nombre de ligne, le nombre de colonne et le nombre de bombes que l'on veut 
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Choix extends JFrame{
	public int colonne, ligne, bombe;
	JButton retour = new JButton("Retour");
	JTextField bc = new  JTextField();
	JTextField bl = new  JTextField();
	JTextField nbbombe = new  JTextField();

	public Choix() {
		this.setTitle("Choix");
		this.setSize(500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);	
		GridLayout place = new GridLayout(3,1);
		this.setLayout(place);
		JPanel panneau = new JPanel();
		GridLayout grille = new GridLayout(3,3);
		panneau.setLayout(grille);
		JLabel col = new JLabel();
		col.setText("   Colonne : ");
		panneau.add(col);
		
		JPanel pane = new JPanel();
		JPanel panneau2 = new JPanel();
		
		JLabel textehaut = new JLabel();
		textehaut.setText("Choisissez");
		this.add(textehaut);
		GridLayout gribouton = new GridLayout(1,2);
		panneau2.setLayout(gribouton);
		JButton ok = new JButton("Valider");
		
		bc.setPreferredSize(new Dimension(150, 30));
		panneau.add(bc);
		
		JLabel lig = new JLabel();
		lig.setText("   Ligne : ");
		panneau.add(lig);
		panneau.add(bl);
		
		JLabel bombes = new JLabel();
		bombes.setText("   Bombe : ");
		panneau.add(bombes);
		panneau.add(nbbombe);
		this.add(panneau);
		
		pane.add(ok);
		pane.add(retour);
		panneau2.add(pane);
		this.add(panneau2); 	
		this.setVisible(true);
		
		
		ok.addActionListener(new ActionMode(this,0));
		retour.addActionListener(new ActionMode(this,1));

	}	
}