import javax.swing.*;

/**
*
* La classe Compteur gère le nombre de bombes possible restantes (bombes - étoiles)
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class Compteur extends JLabel{

	private int bombe;
	private JPanel panel;

	public Compteur(int nbrBombe,JPanel panel){
	super("Bombes : "+nbrBombe);
	this.bombe=nbrBombe;
	this.panel=panel;
		}	
 /**
 *
 *Augmente le compteur de 1
 */
	public void incremente(){
		bombe++;
		panel.removeAll();
		JLabel l =new JLabel("Bombes : "+bombe);
		panel.add(l);
		panel.updateUI();
	}
 /**
 *
 *Diminue le compteur de 1
 */
	public void decremente(){
		bombe--;
		panel.removeAll();
		JLabel l =new JLabel("Bombes : "+bombe);
		panel.add(l);
		panel.updateUI();
	}
}