/**
*
* La classe Incremente permet d'incrémenter toutes les cases aux alentours d'une case
* et si la case adjacente n'est pas -1 (une bombe)
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/


public class Incremente {
	private int[] tab=null;
	private int colonne;

/**
* Tableau de int représentant les bombes, les nombres de bombes adjacentes et le nombre de colonne.
* @param tab le tableau de int
* @param colo le nombre de colonne
*/
  public Incremente(int [] tab, int colo){
  	this.tab=tab;
  	this.colonne=colo;
  }

/**
* Pour incrémenter si c'est la première ligne (pL) et la derniere colonne (DC)
* @param i case numéro i du tableau
*/
  public void pLDC(int i){
  	if(tab[i-1]++!=-1){
  		tab[i-1]++;
  	}
  	if(tab[i+colonne]!=-1){
		tab[i+colonne]++;
	}	
	if(tab[i+colonne-1]!=-1){
		tab[i+colonne-1]++;
	}
  }

/**
* Pour incrémenter si c'est la première ligne (pL) et la première colonne (PC)
* @param i case numéro i du tableau
*/
  public void pLPC(int i){
  	if(tab[i+1]!=-1)
  		tab[i+1]++;

	if(tab[i+colonne]!=-1)
		tab[i+colonne]++;

	if(tab[i+colonne+1]!=-1)
		tab[i+colonne+1]++;

  }

/**
* Pour incrémenter si c'est la première ligne (pL) et rien de particulier donc autre (A)
* @param i case numéro i du tableau
*/
  public void pLA(int i){
  	if(tab[i+1]!=-1)
  		tab[i+1]++;

	if(tab[i+colonne]!=-1)
		tab[i+colonne]++;

	if(tab[i+colonne+1]!=-1)
		tab[i+colonne+1]++;

	if(tab[i+colonne-1]!=-1)
		tab[i+colonne-1]++;

	if(tab[i-1]!=-1)
		tab[i-1]++;

  }

/**
* Pour incrémenter si c'est la dernière ligne (dL) et la derniere colonne (DC)
* @param i case numéro i du tableau
*/
  public void dLDC(int i){
  	if(tab[i-1]!=-1)
  		tab[i-1]++;

	if(tab[i-colonne]!=-1)
		tab[i-colonne]++;

	if(tab[i-colonne-1]!=-1)
		tab[i-colonne-1]++;

  }

  /**
* Pour incrémenter si c'est la dernière ligne (dL) et la première colonne (DC)
* @param i case numéro i du tableau
*/
  public void dLPC(int i){
  	if(tab[i+1]!=-1)
  		tab[i+1]++;

	if(tab[i-colonne]!=-1)
		tab[i-colonne]++;

	if(tab[i-colonne+1]!=-1)
		tab[i-colonne+1]++;

  }

/**
* Pour incrémenter si c'est la dernière ligne (dL) et rien de particulier donc autre (A)
* @param i case numéro i du tableau
*/
  public void dLA(int i){
  	if(tab[i+1]!=-1)
  		tab[i+1]++;

	if(tab[i-colonne]!=-1)
		tab[i-colonne]++;

	if(tab[i-colonne+1]!=-1)
		tab[i-colonne+1]++;

	if(tab[i-colonne-1]!=-1)
		tab[i-colonne-1]++;

	if(tab[i-1]!=-1)
		tab[i-1]++;

  }

/**
* Pour incrémenter si c'est pas une ligne particulière (a) et la dernière colonne (DC)
* @param i case numéro i du tableau
*/
  public void aDC(int i){
  	if(tab[i-1]!=-1)
  		tab[i-1]++; /*A gauche*/

	if(tab[i-colonne]!=-1)
		tab[i-colonne]++;/*Au dessus*/

	if(tab[i+colonne]!=-1)
		tab[i+colonne]++;/*En dessous*/

	if(tab[i-colonne-1]!=-1)
		tab[i-colonne-1]++;/*Au dessus à gauche*/

	if(tab[i+colonne-1]!=-1)
		tab[i+colonne-1]++;/*En dessous à gauche*/

  }

  /**
* Pour incrémenter si c'est pas une ligne particulière (a) et la première colonne (PC)
* @param i case numéro i du tableau
*/
  public void aPC(int i){
  	if(tab[i+1]!=-1)
  		tab[i+1]++; /*A droite*/

	if(tab[i-colonne]!=-1)
		tab[i-colonne]++;/*Au dessus*/

	if(tab[i+colonne]!=-1)
		tab[i+colonne]++;/*En dessous*/

	if(tab[i-colonne+1]!=-1)
		tab[i-colonne+1]++;/*Au dessus à droite*/

	if(tab[i+colonne+1]!=-1)
		tab[i+colonne+1]++;/*En dessous à droite*/

  }

/**
* Pour incrémenter si c'est pas une ligne particulière (a) et pas une colonne particulière (A)
* @param i case numéro i du tableau
*/
  public void aA(int i){
  	if(tab[i+1]!=-1)
  		tab[i+1]++; /*A droite*/

  	if(tab[i-1]!=-1)
  		tab[i-1]++; /*A gauche*/

	if(tab[i-colonne]!=-1)
		tab[i-colonne]++;/*Au dessus*/

	if(tab[i+colonne]!=-1)
		tab[i+colonne]++;/*En dessous*/

	if(tab[i-colonne-1]!=-1)
		tab[i-colonne-1]++;/*Au dessus à gauche*/

	if(tab[i+colonne-1]!=-1)
		tab[i+colonne-1]++;/*En dessous à gauche*/

	if(tab[i-colonne+1]!=-1)
		tab[i-colonne+1]++;/*Au dessus à droite*/

	if(tab[i+colonne+1]!=-1)
		tab[i+colonne+1]++;/*En dessous à droite*/

  }

}