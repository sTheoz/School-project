import java.awt.*;
import javax.swing.*;
import java.io.File;

/**
*
* La classe FinDePartie a pour but de montrer un message à l'utilisateur et
* qui lui permet de soit relancer la partie ou de quitter l'application
* @version 0.1
* @author Théo Szatkowski Jérémie Badol
*/

public class FinDePartie extends JDialog{

	public int rep;
	public JFrame mere;
	public JRadioButton recommence;
	public JRadioButton quitte;



	public FinDePartie(JFrame parent, String titre, boolean modal){

	super(parent,titre,modal);

	File sauvegarde = new File("save.dat");
   	sauvegarde.delete();

    this.setSize(400, 200);

    this.setLocationRelativeTo(null);

    this.setResizable(false);

    this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    
    this.addContenu();	
    mere=parent;
    try{
    	Thread.sleep(500);
    }catch(InterruptedException e){
    	System.err.println("N'a pas attendu pour afficher l'écran de fin");
    }
    this.setVisible(true);

	}
 /**
 *
 *Ajoute le choix entre recommencer et quitter à la fenêtre
 */
	public void addContenu(){
	    JPanel panMenu = new JPanel(new GridLayout(2,2));
	    panMenu.setBackground(Color.white);
	    panMenu.setBorder(BorderFactory.createTitledBorder("Que voulez-vous faire ?"));
	    panMenu.setPreferredSize(new Dimension(440, 60));
	    recommence = new JRadioButton("Recommencer");
	    recommence.setSelected(true);
	    quitte = new JRadioButton("Quitter");
	    ButtonGroup bg = new ButtonGroup();
	    bg.add(recommence);
	    bg.add(quitte);
	    panMenu.add(recommence);
	    panMenu.add(quitte);
	    JButton okBouton = new JButton("OK");
	    panMenu.add(okBouton);
	    this.add(panMenu);

		
	    okBouton.addActionListener(new ActionFin(this));

	}


 /**
 *
 *Renvoie la valeur si recommencer ou quitter est selectionné
 *@return 0=recommencer et 1 = quitter
 */
      public int getReponse(){
        return (recommence.isSelected()) ? 0 : 
               (quitte.isSelected()) ? 1 : 
                0;  
      }

}