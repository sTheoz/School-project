<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_sondage extends CI_Model {
	public function __construct(){
	$this->load->database();
	}

	public function create_createur($data){
		return	$this->db->insert('createur', $data);	
	}

	public function create_sondage($data){
		return	$this->db->insert('sondage', $data);	
	}

	public function create_date($data){
		return	$this->db->insert('heure', $data);	
	}

	public function add_participant($data){
		return	$this->db->insert('participe', $data);	
	}

	public function select_createur($login,$password){
		$this->db->select('mdp');
		$this->db->from('createur');
		$this->db->where('login',$login);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE){
			if(password_verify($password,$resultat[0]->mdp)) return true;
		return false;
		}else{
			return false;
		}
	}
	public function cloture($cle){
		$this->db->set('ouvert',false);
		$this->db->where('cle',$cle);
		$this->db->update('sondage');		
	}

	public function test_unique($cle){
		$this->db->select('cle');
		$this->db->from('sondage');
		$this->db->where('cle',$cle);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return false;
		return true;
	}

	public function test_uniqueID($id){
		$this->db->select('id');
		$this->db->from('heure');
		$this->db->where('id',$id);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return false;
		return true;
	}

	public function select_all_sondage($user){
		$this->db->select('titre,lieu,cle,ouvert');
		$this->db->from('sondage');
		$this->db->where('createur',$user);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}

	public function select_sondage($cle){
		$this->db->select('titre,lieu,descriptif,ouvert,createur');
		$this->db->from('sondage');
		$this->db->where('cle',$cle);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}




	public function recupere_nom($id){
		$this->db->select('prenom,nom,id');
		$this->db->from('participe');
		$this->db->where('id',$id);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}

	public function select_date($cle){

		$this->db->select('jour,heure,min,duree,id');
		$this->db->from('heure');
		$this->db->where('cle',$cle);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}

	public function select_proprietaire($cle){
		$this->db->select('createur');
		$this->db->from('sondage');
		$this->db->where('cle',$cle);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}

	public function select_participe($cle){
		$this->db->select('id,prenom,nom');
		$this->db->from('heure');
		$this->db->join('participe','id');
		$this->db->where('cle',$cle);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}
		public function test_participe($id, $prenom, $nom){
		$this->db->select('id');
		$this->db->from('participe');
		$this->db->where('id',$id);
		$this->db->where('prenom',$prenom);
		$this->db->where('nom',$nom);
		$query= $this->db->get();
		$resultat=$query->result_array();

		if($resultat!=FALSE)return true;
		return false;
	}

	public function confirm_date($id,$nom,$prenom){
		$this->db->select();
		$this->db->from('participe');
		$this->db->where('id',$id);
		$this->db->where('nom',$nom);
		$this->db->where('prenom',$prenom);
		$query= $this->db->get();
		$resultat=$query->result();
		if($resultat!=FALSE)return $resultat;
		return false;
	}
}