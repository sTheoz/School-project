<div class="cadre">
		<?php echo validation_errors(); ?>
		<?php echo form_open('sondage/entrer_cle',array()); ?>
		<fieldset>
			<legend>Accéder à un sondage</legend>
			<!-- Text input-->
			<table>
				<div>
					<tr>
						<td><label  for="cle">Entrer une clef</label></td>
						<td><input  id="cle" name="cle" placeholder="cle" required type="text"></td>
					</tr>
				</div>
			</table>
				<!-- Button -->
				<div class="_mts">
					<button id="envoyer" name="envoyer">Envoyer clef</button>
				</div>
			


			<a href=<?php echo site_url('/sondage/profil')?>>Retour</a>
		</fieldset>
	</form>

</div>