<div class="cadre">
	
	<fieldset>
		<legend>Profil</legend>
			<div class="logtitre">
				<?php 
					$loginrecup = $this->session->userdata('login');
					echo "Bonjour vous êtes connecté $loginrecup!";

				?>
			</div>
			<div class="alert-box -success">
					
					 <br>
					<a href= <?php echo site_url('sondage/create_sondage/1') ?> id="create_sondage" name="create_sondage">Créer un sondage</a>
					<a href=<?php echo site_url('sondage/entrer_cle') ?> id="entrer_cle" name="entrer_cle">Accéder à un sondage</a>
					<a href=<?php echo site_url('sondage/deconnexion') ?> id="deconnexion" name="deconnexion">Se déconnecter</a>
				</div>
				<?php

				$this->table->set_heading(array('Titre', 'Lieu', 'cle','ouvert'));

				$template = array(
					'table_open' => '<table class="sondages">'
				);
				?>
				<div class="tableau">
				<?php
				$this->table->set_template($template);
				$sondages = $this->model_sondage->select_all_sondage($loginrecup);
				if($sondages != false){
					foreach ($sondages as $sondage){
						if($sondage->ouvert == true){
							$this->table->add_row(
						$sondage->titre,
						$sondage->lieu,
						$sondage->cle,
						"oui",
						 "<a class='bouton' href=".site_url('sondage/cloture_sondage/'.$sondage->cle)."><img src=".base_url()."/assets/img/croixRouge.png height='30' ></a> ",
						 "<a class='accede' href=".site_url('sondage/res_sondage/'.$sondage->cle).">Voir résultat</a> "
						);
						}else{
							$this->table->add_row(
						$sondage->titre,
						$sondage->lieu,
						$sondage->cle,
						"non",
						 "<a class='bouton' href=".site_url('sondage/cloture_sondage/'.$sondage->cle)."><img src=".base_url()."/assets/img/croixRouge.png height='30' ></a> ",
						 "<a class='accede' href=".site_url('sondage/res_sondage/'.$sondage->cle).">Voir résultat</a> "
						);
						}
					
					}
					echo $this->table->generate();
				}
				?>
		
		</div>
	</fieldset>
</div>