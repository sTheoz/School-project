<!-- A mettre le descriptif, le lieu et le titre en haut de la page pour epxliquer le but du sondage et il peut en dessous ajouter une date qu'il veut-->
<div class="cadre">
	<div>
		<fieldset>
			<?php
				$cle=$this->uri->segment(3);
				$resultat = $this->model_sondage->select_sondage($cle);
				if($resultat == false){
					echo "<h2> Ce sondage n'existe pas !</h2>";
				}else{
					echo form_open('sondage/ajoute_participe',array() );
					echo validation_errors();
					$lieu= $resultat[0]->lieu;
					$titre= $resultat[0]->titre;
					$descriptif= $resultat[0]->descriptif;
					$ouvert= $resultat[0]->ouvert;
					$createur= $resultat[0]->createur;
					
					if($ouvert==1){
						?>
						<table>
							<tr>
								<td>Créateur :</td><td> <?php echo $createur ?></td>
							</tr>
							<tr>
								<td>Titre : </td><td><?php echo $titre ?></td>
							</tr>
							<tr>
								<td>Lieu :</td><td> <?php echo $lieu ?></td>
							</tr>
							<tr>
								<td>Descriptif :</td><td> <?php echo $descriptif ?></td>
							</tr>
						</table>
						<table>
					<?php 
						$dates = $this->model_sondage->select_date($cle);
						if($dates != false){
						foreach ($dates as $date){
							?>
							<tr>
								<td>
									<input id="checkBox" type="checkbox" name="choix[]" value=<?php echo $date->id ?> >
								</td>
								<td>
										<label for="checkbox">
											<?php
												echo 
												$date->jour.", ".
												$date->heure.":".
												$date->min.",Durée: ".
												$date->duree;

											?>
										</label>
								</td>
								
							</tr>
							
					<?php
					}
					?>
					<tr>
						<td><label>Prénom : </label></td>
						<td><input type="text" required name="prenom" placeholder="Jean"></td>
					</tr>
					<tr>
						<td><label>Nom : </label></td>
						<td><input type="text" required name="nom" placeholder="Dumoulin"></td>
					</tr>
					<?php
				}
				?>	
				</table>
				<?php		
				}else{
					echo "<h2> CE SONDAGE EST FERMÉ</h2>";
				}
				}	
			?>
			<br>
			<div class="_mts">
				<button id="envoyer" name="envoyer" formaction=<?php echo site_url('sondage/ajoute_participe') ?> >Confirmer</button>
			</div>
			<a href=<?php echo site_url('sondage/profil') ?>>Retour</a>
			</fieldset>
		</form>
	</div>
</div>
