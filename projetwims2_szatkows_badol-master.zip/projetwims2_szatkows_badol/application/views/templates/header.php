<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8" />
		<title>Dit Dle</title>
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<link rel="stylesheet" href="/resources/demos/style.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		 <script>
			$( function() {
			  $( ".calendrier" ).datepicker({ dateFormat: 'dd/mm/yy' }).val();
			} );
		</script>
		<?php echo link_tag('assets/css/style.css');?>
		
	</head>
	<body>
	<img src="/~szatkows/Doodle/assets/img/Dit_Dle.png" alt="Logo_Dit_Dle" class="logo" id="logo" height="100">
