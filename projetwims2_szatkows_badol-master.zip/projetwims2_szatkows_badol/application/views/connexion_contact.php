<div class="cadre">
	<div>
		<?php echo validation_errors(); ?>
		<?php echo form_open('sondage/connexion',array()); ?>
		<fieldset>
			<legend>Connexion</legend>
			<!-- Text input-->
			<div>
				<table>
				<tr>
					<td><label  for="login">Login </label></td>
					<td><input value="<?=set_value('login')?>" id="login" name="login" placeholder="Login"  required type="text"></td>
				</tr>

			<!-- Password input-->
				<tr>
					<td><label  for="mdp">Mot de passe </label></td>
					<td><input id="mdp" name="mdp" placeholder="Mot de passe"  required type="password"></td>
				</tr>
			</table>
		</div>
			<!-- Button -->
			<div class="_mts">
				<button id="envoyer" name="envoyer">Se connecter </button>
			</div>
		</form>
			<br>
			<a href=<?php echo site_url('sondage/create')?>>S'inscrire</a>
			<table>
					<?php echo form_open('sondage/entrer_cle',array()); ?>
					<tr>
						<td><label>OU</label></td>
					</tr>
					<tr>
						<td><label  for="cle">Entrer une clef pour accéder à un sondage</label></td>
					</tr>
					<tr>
						<td><input  id="cle" name="cle" placeholder="cle" required type="text"></td>
					</tr>

				<!-- Button -->
				<div class="_mts">
					<tr>
						<td><button id="envoyer" name="envoyer">Envoyer clef</button></td>
					</tr>
				</div>
			</table>
		</fieldset>
	</form>
</div>
</div>