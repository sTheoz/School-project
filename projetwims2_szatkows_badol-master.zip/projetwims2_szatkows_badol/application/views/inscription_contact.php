<div class="cadre">
	<div>
		<?php echo validation_errors(); ?>
		<?php echo form_open('sondage/create',array()); ?>
		<fieldset>
			<legend>Inscription</legend>
			<!-- Text input-->
			<table>
				<tr>
					<td><label  for="login">Login </label></td>
					<td><input value="<?=set_value('login')?>" id="login" name="login" placeholder="Login"  required type="text"></td>
				</tr>

				<!-- Password input-->
				<tr>
					<td><label  for="mdp">Mot de passe</label></td>
					<td><input  id="mdp" name="mdp" placeholder="Mot de passe"  required type="password"></td>
				</tr>

				<!-- Password input-->
				<tr>
						<td><label  for="mdpconfirm">Confirmation du mot de passe</label></td>
						<td><input  id="mdpconfirm" name="mdpconfirm" placeholder="Mot de passe"  required type="password"></td>
					</tr>

				<!-- Text input-->
				<tr>
						<td><label  for="nom">Nom</label></td>
						<td><input value="<?=set_value('nom')?>" id="nom" name="nom" placeholder="Nom"  required type="text"></td>
					</tr>


				<!-- Text input-->
				
					<tr>
						<td><label  for="prenom">Prénom</label></td>
						<td><input value="<?=set_value('prenom')?>" id="prenom" name="prenom" placeholder="Prénom"  required type="text"></td>
					</tr>

				<!-- Email input-->
				
					<tr>
						<td><label  for="email">Email</label></td>
						<td><input value="<?=set_value('email')?>" id="email" name="email" placeholder="Adresse Mail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required type="email"></td>
					</tr>

				<!-- Button -->
				<div class="_mts">
					<tr>
						<td><button id="envoyer" name="envoyer">Créer</button></td>
					</tr>
				</div>
			</table>
			<br>
			<a href=<?php echo site_url('sondage/connexion')?>>Se connecter</a>
		</fieldset>
	</form>
</div>
</div>