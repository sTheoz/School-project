<div class="cadre">
	<div>
		<?php echo validation_errors(); ?>
		<?php echo form_open('sondage/create_sondage',array()); ?>
		<fieldset>
			<legend>Création d'un sondage</legend>
			<table>
				
				<!-- Text input-->
					<tr>
						<td><label  for="titre">Titre : </label></td>
						<td><input  id="titre" value="<?=set_value('titre')?>" name="titre" placeholder="Ex: Soirée cinéma"  required type="text"></td>
					</tr>
			

				<!-- Text input-->
				
					<tr>
						<td><label  for="lieu">Lieu : </label></td>
						<td><input value="<?=set_value('lieu')?>" id="lieu" name="lieu" placeholder="Ex: Provins"  required type="text"></td>
					</tr>


				<!-- Text input-->
				
					<tr>
						<td><label  for="descriptif">Descriptif : </label></td>
						<td><input value="<?=set_value('descriptif')?>" id="descriptif" name="descriptif" placeholder="Ex : Resto puis cinéma entre amis"  required type="text"></td>
					</tr>
				
				
				


				<?php 
				$i = $this->uri->segment(3);
				for($j=0;$j<$i;$j++){
					echo "
				
						<tr>
							<td><label>Date</label></td>
							<td><input class='calendrier' id='date_$j' name='Date$j' required pattern='([0-3]?[0-9]/[01]?[0-9]/[2][0][1-9][0-9])' value=".set_value('Date'.$j)."></td>
						</tr>
						<tr>
							<td><label>Heure :</label></td>
							<td><input class='heure' id='heure_$j' name='heure_$j' pattern='([01]?[0-9]|2[0-3])' required type='text' value=".set_value('heure_'.$j)."></td>
						</tr>
						<tr>
							<td><label>Min :</label></td>
							<td><input class='heure' id='min_$j' name='min_$j' pattern ='([0-5]?[0-9])' required type='text' value=".set_value('min_'.$j)."></td>
						</tr>
						<tr>
							<td><label>Duree ~ :</label></td>
							<td><input class='heure' id='duree$j' name='duree$j' required type='text' value=".set_value('duree'.$j)."></td>
						</tr>
						<tr> <td> </td> </tr>
						
				
					";
				}
				?>
				
				</table>
				<!-- Button -->
				<div class="_mts">
					<button id="envoyer" name="envoyer" formaction=<?php echo site_url('sondage/create_sondage/'.$i.'/1') ?>>Créer</button>
					<button class="bouton<?=$i?>" type="submit" formnovalidate 
						formaction=<?php $i=$i+1;echo site_url('sondage/create_sondage/'.$i.'/0') ?>>Ajouter une date</button>
						<button class="bouton<?=$i?>" type="submit" formnovalidate 
						formaction=<?php $i=$i-2;echo site_url('sondage/create_sondage/'.$i.'/0') ?>>Enlever une date</button>
				</div>
			
			<br>
			<a href=<?php echo site_url('sondage/profil') ?>>Retour</a>
		</fieldset>
	</form>
</div>
</div>
