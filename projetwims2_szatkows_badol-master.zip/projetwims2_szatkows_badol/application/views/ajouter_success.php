<div class="cadre">
	<fieldset>
		<legend>Inscription réussie</legend>
			<div class="alert-box -success">
				<?=$nom?> <?=$prenom?> Vous êtes bien inscrit !
				<a href=<?php echo site_url('/sondage/connexion')?>>Se connecter</a>
			</div>
	</fieldset>
</div>
