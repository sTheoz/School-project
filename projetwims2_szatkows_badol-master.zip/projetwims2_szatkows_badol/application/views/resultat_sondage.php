<div class="cadre">
	
		<fieldset>
			<?php
				$loginrecup = $this->session->userdata('login');

				$cle=$this->uri->segment(3);
				$tous=$this->model_sondage->select_date($cle);

				
				$creaRes = $this->model_sondage->select_proprietaire($cle);
				if($creaRes[0]->createur != $loginrecup){
					redirect('sondage/profil');
				}
				
				
				$i=0;
				$j=0;
				$sizetous = count($tous);
				$sizetous = 90 / $sizetous;
			
				


				if($tous!==false){
					echo '<table><tr>';
					echo "<td class='date'> </td>";
					foreach ($tous as $tout){
					
						//Affiche les div des heures
						echo "<td class='date'>";
						echo $tout->jour." à "; echo $tout->heure."h"; echo $tout->min." Durée~: "; echo $tout->duree;
						echo '</td>';				


						$id[$i]=$tout->id;
						$i=$i+1;
						$noms = $this->model_sondage->recupere_nom($tout->id);
						
						if($noms != false){
										
							foreach ($noms as $nom) {
								$pnom=$nom->nom;
								$ppnom=$nom->prenom;
								$key=$nom->id;
								$valide=1;
								for($k=0;$k<$j;$k++){
									if($pnom== $participantsn[$k] && $ppnom== $participantsp[$k]){
										$valide=0;
									}
								}
								if($valide){
									$participantsn[$j]=$pnom;
									$participantsp[$j]=$ppnom;
									$clep[$j]=$key;
									$j=$j+1;
								}
							}
						

						}

					}
							
				}
				echo "</tr>";
				//k vaut nombre participant
				//i vaut nombre de clés

				
						if (isset($k)) {
							for($p=0;$p<$k;$p++){
								echo "<tr class='grille_part'>";
								echo "<td></td>";
								echo "<tr><td class='participant'>".$participantsp[$p]." ".$participantsn[$p]."</td>";
								echo "<br/>";
								
								for($nombreid=0;$nombreid<$i;$nombreid++){
									$idp=$id[$nombreid];
									//$idp = clé pour 1 date
								
									if($this->model_sondage->test_participe($idp, $participantsp[$p], $participantsn[$p]) ) {
										echo "<td class='tableauV'>✓</td>";
									}else{
										echo "<td class='tableauR'>✖</td>";
									}
									
								}
								
								echo "</tr>";
							}
						}
						echo "</table>";
						?>





					
					
			<br>
			<a href=<?php echo site_url('sondage/profil') ?>>Retour</a>
			</fieldset>
		</div>
		</form>
	
</div>