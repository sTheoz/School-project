<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sondage extends CI_Controller {


	public function create(){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->model('model_sondage');

			$this->form_validation->set_rules('login', 'Login', 'required|is_unique[createur.login]');
			$this->form_validation->set_rules('mdp', 'Mot de passe', 'required|trim');
			$this->form_validation->set_rules('nom', 'Nom', 'required|trim');
			$this->form_validation->set_rules('prenom', 'Prénom', 'required|trim');
			$this->form_validation->set_rules('email', 'Email', 'valid_email|is_unique[createur.email]');


			$this->form_validation->set_message('is_unique', '{field} est déjà présent dans la base.');

			if ($this->form_validation->run() === FALSE){
				$this->load->view('templates/header');
				$this->load->view('inscription_contact');
				$this->load->view('templates/footer');

			}else{
				$login = $this->input->post('login');
				$mdp = $this->input->post('mdp');
				$mdpc = $this->input->post('mdpconfirm');
				if($mdp != $mdpc){
					$this->load->view('templates/header');
					$this->load->view('inscription_contact');
					$this->load->view('templates/footer');
				}else{
					$nom = $this->input->post('nom');
					$nom = filter_input(INPUT_POST, 'nom',FILTER_SANITIZE_STRING);

					$prenom = $this->input->post('prenom');
					$prenom = filter_input(INPUT_POST, 'prenom',FILTER_SANITIZE_STRING);

					$email = $this->input->post('email');
					$email = filter_input(INPUT_POST, 'email',FILTER_SANITIZE_EMAIL);

					$mdp = filter_input(INPUT_POST, 'mdp',FILTER_SANITIZE_STRING);
					$mdp=password_hash($mdp,PASSWORD_DEFAULT);
					

					$data=array(
						'login'=>$login,
						'mdp'=>$mdp,
						'nom'=>$nom,
						'prenom'=>$prenom,
						'email'=>$email
					);

					if	($this->model_sondage->create_createur($data)){
						$this->load->view('templates/header');
						$this->load->view('ajouter_success', $data);
						$this->load->view('templates/footer');
					}
				}
			}
		}

		public function connexion(){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->model('model_sondage');

			/*if ($this->form_validation->run() === FALSE){
				$this->load->view('templates/header');
				$this->load->view('connexion_contact');
				$this->load->view('templates/footer');

			}else{*/
					$login = $this->input->post('login');
						$mdp = $this->input->post('mdp');
						$donnee=array(
							'login'=>$login,
							'mdp'=>$mdp,
						);
						if	($this->model_sondage->select_createur($login,$mdp)){
							$this->session->set_userdata('login',$login);
							redirect('sondage/profil');
					}else{
						$this->load->view('templates/header');
						$this->load->view('connexion_contact');
						$this->load->view('templates/footer');
					}
						}

		public function deconnexion(){
			$this->load->library('session');
			$this->session->sess_destroy();
			redirect('/sondage/connexion');

		}

		public function profil(){
			$loginrecup = $this->session->userdata('login');
			if(!isset($loginrecup)){
				redirect('sondage/connexion');
			}else{
				$this->load->view('templates/header');
				$this->load->library('table');
				$this->load->view('profil');
				$this->load->view('templates/footer');
			}
			

		}

		public function create_sondage(){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->model('model_sondage');
			$this->load->helper('string');
			
			$this->form_validation->set_rules('titre', 'Titre', 'required|trim');
			$this->form_validation->set_rules('lieu', 'Lieu', 'required|trim');
			$this->form_validation->set_rules('descriptif', 'Descriptif', 'required');

			if ($this->form_validation->run() === FALSE){
				$this->load->view('templates/header');
				$this->load->view('creersondage');
				$this->load->view('templates/footer');
			}else{
			$nbrDate=$this->uri->segment(3);
			$titre=$this->input->post('titre');
			$titre = filter_input(INPUT_POST, 'titre',FILTER_SANITIZE_STRING);

			$lieu=$this->input->post('lieu');
			$lieu = filter_input(INPUT_POST, 'lieu',FILTER_SANITIZE_STRING);

			$descriptif=$this->input->post('descriptif');
			$descriptif = filter_input(INPUT_POST, 'descriptif',FILTER_SANITIZE_STRING);

			$valider=$this->uri->segment(4);
			if( $valider == 1 ){
				$cle=random_string('alnum',32);
				while(!($this->model_sondage->test_unique($cle) ) ){
				$cle=random_string('alnum',32);
			}
				$loginrecup = $this->session->userdata('login');
				$donnee=array(
					'titre'=>$titre,
					'lieu'=>$lieu,
					'descriptif'=>$descriptif,
					'cle'=>$cle,
					'ouvert'=>true,
					'createur'=>$loginrecup
				);

				if($this->model_sondage->create_sondage($donnee) != false){
					for($nbr=0 ; $nbr<$nbrDate; $nbr++){
						$date=$this->input->post('Date'.$nbr);
						$date = filter_input(INPUT_POST, 'Date'.$nbr,FILTER_SANITIZE_STRING);


						$heure=$this->input->post('heure_'.$nbr);
						$heure = filter_input(INPUT_POST, 'heure_'.$nbr,FILTER_SANITIZE_STRING);


						$min=$this->input->post('min_'.$nbr);
						$min = filter_input(INPUT_POST, 'min_'.$nbr,FILTER_SANITIZE_STRING);


						$duree=$this->input->post('duree'.$nbr);
						$duree = filter_input(INPUT_POST, 'duree'.$nbr,FILTER_SANITIZE_STRING);


						$id=random_string('alpha',25);
						while(!($this->model_sondage->test_uniqueID($id) ) ){
							$id=random_string('alpha',25);
						}
						$bigdata=array(
							'cle'=>$cle,
							'jour'=>$date,
							'heure'=>$heure,
							'min'=>$min,
							'duree'=>$duree,
							'createur'=>$loginrecup,
							'id'=>$id
							);						
						$this->model_sondage->create_date($bigdata);
					}
					redirect('sondage/profil');
				}
			}else{
				$this->load->view('templates/header');
				$this->load->view('creersondage');
				$this->load->view('templates/footer');
			}		
		}
	}

		public function create_date(){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->model('model_sondage');

			$prefs = array(
					'template' => array(
        			'table_open'           => '<table class="calendar">',
        			'cal_cell_start'       => '<td class="day">',
        			'cal_cell_start_today' => '<td class="today">'),
					'show_next_prev' => TRUE,
					'show_other_days' => TRUE
				);

			$this->load->library('calendar', $prefs);

			$this->load->view('templates/header');
			$this->load->view('ajouter_date');
			$this->load->view('templates/footer');
		}


		 public function cloture_sondage(){
			$this->load->helpers('form');
			$this->load->library('table');
			$this->load->model('model_sondage');
			$cle=$this->uri->segment(3);
			$this->model_sondage->cloture($cle);
			redirect('sondage/profil');

		}
		public function entrer_cle($cle=''){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->load->model('model_sondage');
			$cle=$this->uri->segment(3);
			if(isset($cle)){
				$this->load->view('templates/header');
				$this->load->view('ajouter_date');
				$this->load->view('templates/footer');

			}else{
				$this->load->view('templates/header');
				$this->load->view('entrer_sondage');
				$this->load->view('templates/footer');
				$cle = $this->input->post('cle');
				if(isset($cle))redirect("sondage/entrer_cle/".$cle);
			}
		}
		public function res_sondage($cle=''){
			$this->load->view('templates/header');
			$this->load->view('resultat_sondage');
			$this->load->view('templates/footer');
		}



		public function ajoute_participe(){
			foreach ($_POST['choix'] as $idHeure) {
				$prenom = $_POST['prenom'];
				$prenom = filter_input(INPUT_POST, 'prenom',FILTER_SANITIZE_STRING);

				$nom = $_POST['nom'];
				$nom = filter_input(INPUT_POST, 'nom',FILTER_SANITIZE_STRING);

				$data=array(
					'id'=>$idHeure,
					'prenom'=>$prenom,
					'nom'=>$nom
				);
				$this->model_sondage->add_participant($data);			
			}
			redirect('sondage/profil');
		}


		public function index(){
		$this->load->helpers('form');
		$this->load->model('model_sondage');
		$this->load->library('table');
		$this->load->view('templates/header');
		$this->load->view('connexion_contact');
		$this->load->view('templates/footer');
	}
}
