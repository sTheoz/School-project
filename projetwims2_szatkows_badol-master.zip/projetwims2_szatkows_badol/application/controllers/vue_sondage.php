<div grid>
	<div column="+3 3">
		<?php echo validation_errors(); ?>
		<?php echo form_open('sondage/create_sondage',array()); ?>
		<fieldset>
			<legend>Création d'un sondage</legend>

			<!-- Text input-->
			<div>
				<label  for="titre">Titre</label>
				<input  id="titre" name="titre" placeholder="Ex: Soirée cinéma"  required type="text">
			</div>

			<!-- Text input-->
			<div>
				<label  for="lieu">Lieu</label>
				<input value="<?=set_value('lieu')?>" id="lieu" name="lieu" placeholder="Ex: Provins"  required type="text">
			</div>


			<!-- Text input-->
			<div>
				<label  for="descriptif">Descriptif</label>
				<input value="<?=set_value('descriptif')?>" id="descriptif" name="descriptif" placeholder="Ex : Resto puis cinéma entre amis"  required type="text">
			</div>

			<!-- Button -->
			<div class="_mts">
				<button id="envoyer" name="envoyer">Créer</button>
			</div>
			<br>
			<a href=<?php echo site_url('sondage/') ?>>Retour</a>
		</fieldset>
	</form>
</div>
</div>